"""SPAR MCP server.

Exposes the pipeline itself to any MCP host: tools for reading and writing
``spar/`` artifacts, prompts that mirror the slash commands, and every artifact
as a readable resource.

Pure standard library, newline-delimited JSON-RPC 2.0 over stdio. ``stderr`` is
silenced so stray output can never corrupt the stream.

Two host modes:

* **Claude Code** (``CLAUDE_CODE_SESSION_ID`` set) -- prompts return the full agent
  prompt with frontmatter stripped.
* **Generic host** -- prompts return short, staged instructions that pause between
  stages, and every response is capped, because some hosts fail on large frames.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

from . import __version__
from .cli import (
    ARTIFACT_ORDER,
    TEMPLATES_SRC,
    _confined,
    append_decision,
    find_spar_root,
    infer_phase,
    portfolio,
    scan_spar,
    write_manifest,
)

PROTOCOL_VERSION = "2025-06-18"
GENERIC_CAP = 3000

LOOP = "Run `spar next --json` before each stage and do what it says; stop only at a gate, a choice, blocked or done."

PROMPT_STAGES = {
    "init": [
        "Run `spar init \"<brief>\"` to create spar/ and save the brief.",
        "Draft spar/tenets.md, standards.md and references.md in one pass from the brief, the repo's docs "
        "and org sources (org_search). Mark every item DRAFT. Do not interview.",
        "Stop at the approve-tenets gate with a short table of the tenets: "
        "`spar gate approve approve-tenets` or request changes with a note.",
    ],
    "explore": [
        LOOP,
        "Roadmap: one deliverable or a sequence of MVPs (record a single deliverable with `spar mvp single`).",
        "Write spar/specs/<NNN-slug>/spec.md from the brief (spar/briefs/pending.md if none was given).",
        "Ask every NEEDS CLARIFICATION question together, each with a recommendation; write answers into spec.md.",
        "Stop at the approve-spec gate.",
    ],
    "design": [
        LOOP,
        "Research, then plan.md, data-model.md and contracts/, with the tenets check before and after.",
        "Diagrams in the project's tools (spar/config.json) and a STRIDE threat model when the spec handles "
        "personal data, auth, money or external input.",
        "tasks.md: ordered, parallel-safe tasks with checkpoints; then the cross-artifact check.",
        "Stop at the approve-plan gate.",
    ],
    "build": [
        LOOP,
        "Build the next phase of tasks: tests first, then code, then the per-change review.",
        "Run the project's tests and the app locally. Stop at the checkpoint gate.",
    ],
    "deliver": [
        LOOP,
        "Run the real suite: unit, integration, end-to-end and acceptance; record test-report.md.",
        "Build the spec -> task -> code -> test matrix in verification.md with an explicit PASS or FAIL.",
    ],
    "adopt": [
        "Run `spar init`. Scan the repo read-only and propose feature boundaries.",
        "Draft the engineering principles from observed practice (Known Violations appendix), every item DRAFT.",
        "Stop at the approve-tenets gate.",
    ],
    "fix": [
        "Reproduce the bug, then write a test that fails for exactly this reason.",
        "Fix the cause within the engineering principles; the suite passes and `spar verify-guard` proves the test.",
        "Write spar/fixes/<NNN-slug>.md and stop at the approve-fix gate.",
    ],
    "reconcile": [
        LOOP,
        "Compare spec and plan with the code; append [CONVERGE] tasks for every real gap.",
        "Stop at the reopened approve-plan gate.",
    ],
    "sync": [
        LOOP,
        "Update spec.md, plan.md and tasks.md to match code changed outside SPAR. Touch no code.",
        "Stop at the reopened gate.",
    ],
    "status": [
        "Run `spar status` and `spar next --json`; report each feature's phase and the one next command.",
    ],
}

PROMPT_DESCRIPTIONS = {
    "init": "Start a project: set up spar/, draft the engineering principles, keep the brief",
    "explore": "Discover: roadmap and spec, questions in one sitting",
    "design": "Design: plan, diagrams, threat model, tasks and a cross-check",
    "build": "Build: tests first, then code, per phase",
    "deliver": "Deliver: the four test pillars, traced to the spec",
    "adopt": "Bring an existing codebase into SPAR",
    "fix": "Fix a bug with a failing test and a regression guard",
    "reconcile": "Line the specs up with the code",
    "sync": "Update the specs after outside code changes",
    "status": "Where is every feature, and what runs next",
}


def claude_mode() -> bool:
    return bool(os.environ.get("CLAUDE_CODE_SESSION_ID"))


def strip_frontmatter(text: str) -> str:
    if text.startswith("---"):
        end = text.find("\n---", 3)
        if end != -1:
            nl = text.find("\n", end + 1)
            return text[nl + 1 :].lstrip() if nl != -1 else ""
    return text


def agent_prompt(name: str) -> str | None:
    from .cli import AGENTS_SRC

    for candidate in (f"spar-{name}.md", f"spar-{name.replace('-', '')}.md"):
        p = AGENTS_SRC / candidate
        if p.is_file():
            return strip_frontmatter(p.read_text(encoding="utf-8"))
    return None


def cap(text: str) -> str:
    if claude_mode() or len(text) <= GENERIC_CAP:
        return text
    return text[: GENERIC_CAP - 60] + "\n\n[truncated by SPAR for host frame limits]"


# --------------------------------------------------------------------------- #
# Tools
# --------------------------------------------------------------------------- #

TOOLS = [
    {
        "name": "spar_status",
        "description": "Phase, task completion and verification state for every feature in spar/.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "spar_list",
        "description": "Enumerate every feature and its artifact set as structured JSON.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "spar_read",
        "description": "Read one artifact under spar/ (path relative to the spar root).",
        "inputSchema": {
            "type": "object",
            "properties": {"path": {"type": "string", "description": "e.g. specs/001-auth/spec.md"}},
            "required": ["path"],
        },
    },
    {
        "name": "spar_write",
        "description": "Write one artifact under spar/. Refuses any path escaping the spar root.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "content": {"type": "string"},
            },
            "required": ["path", "content"],
        },
    },
    {
        "name": "spar_template",
        "description": "Fetch a SPAR artifact template by name, e.g. spec, plan, tasks, threat-model.",
        "inputSchema": {
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        },
    },
    {
        "name": "spar_drawio",
        "description": (
            "Write a correctly laid-out draw.io diagram from a short description instead of hand-written XML. "
            "kind=sequence: {title, participants[], messages[{from,to,label,reply?}], notes[{over[],after,label}]}. "
            "kind=er: {title, entities[{name, fields[]}], relations[{from,to,label,many:'to'|'from'}]}. "
            "kind=flow: {title, direction:'right'|'down', nodes[{id,label,shape:'box|db|person|cloud|queue|decision|note',group?}], edges[{from,to,label,dashed?}]}. "
            "kind=context-map: {title, contexts[{name, type:'core|supporting|generic', aggregates[]}], relations[{upstream, downstream, pattern:'OHS/PL|ACL|Conformist|Customer-Supplier|Partnership|Shared Kernel', label}]}. "
            "kind=aggregate: {title, root{name, fields[], methods[]}, entities[{name, fields[]}], values[{name, fields[]}], events[], invariants[]}. "
            "path is relative to the project, e.g. spar/specs/001-x/diagrams/sequence-us1.drawio."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {"kind": {"type": "string", "enum": ["sequence", "er", "flow", "context-map", "aggregate"]},
                           "spec": {"type": "object"}, "path": {"type": "string"}},
            "required": ["kind", "spec", "path"],
        },
    },
    {
        "name": "spar_metrics",
        "description": "Delivery analytics: completion, checkpoints, findings, portfolio roll-up.",
        "inputSchema": {
            "type": "object",
            "properties": {"feature": {"type": "string"}},
        },
    },
    {
        "name": "spar_decision",
        "description": (
            "Append a hash-chained decision record (gate verdict, approval, control finding). "
            "This is the audit trail an auditor reads later."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "subject": {"type": "string", "description": "agent or human id"},
                "action": {"type": "string", "description": "e.g. gate.evaluate, artifact.approve"},
                "name": {"type": "string"},
                "resource": {"type": "string", "description": "artifact path or id"},
                "verdict": {
                    "type": "string",
                    "enum": ["pass", "blocked", "approved", "changes-requested"],
                },
                "feature": {"type": "string"},
                "phase": {"type": "string"},
                "explanation": {"type": "string"},
            },
            "required": ["subject", "action", "name", "resource", "verdict"],
        },
    },
    {
        "name": "spar_check",
        "description": (
            "Run SPAR's deterministic checks: artifact structure (spec/plan/tasks), the project's "
            "declared tests/lint/typecheck, or the verification verdict against its own rows. "
            "Returns stable finding codes with the owning agent, so defects can be routed, not described."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "feature": {"type": "string", "description": "feature id; default: the latest"},
                "scope": {"type": "string", "enum": ["artifacts", "project", "verification", "all"]},
                "for_agent": {"type": "boolean", "description": "return a markdown fix brief instead of JSON"},
            },
        },
    },
    {
        "name": "spar_next",
        "description": (
            "The one deterministic next action for a feature: run a command, run a check, fix a "
            "failed check, wait on a human gate, blocked, or done. Read-only; derived from disk, "
            "the decision ledger and the last check results."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {"feature": {"type": "string", "description": "feature id; default: the latest"}},
        },
    },
]


def tool_call(name: str, args: dict) -> str:
    root = find_spar_root()
    if name == "spar_drawio":
        from . import drawio
        rel = str(args.get("path", "")).strip()
        project = (root.parent if root else Path.cwd())
        target = (project / rel).resolve()
        if not rel.endswith(".drawio") or ".." in Path(rel).parts or not str(target).startswith(str(project.resolve())):
            return json.dumps({"error": "path must be a .drawio file inside the project"})
        try:
            drawio.write(args.get("kind", ""), args.get("spec") or {}, target)
        except (ValueError, KeyError, TypeError) as exc:
            return json.dumps({"error": f"could not build the diagram: {exc}"})
        return json.dumps({"written": rel})

    if name == "spar_template":
        tname = args.get("name", "").strip()
        if not tname or "/" in tname or ".." in tname:
            return json.dumps({"error": "invalid template name"})
        for candidate in (f"{tname}-template.md", f"{tname}.md", tname):
            p = TEMPLATES_SRC / candidate
            if p.is_file() and _confined(TEMPLATES_SRC, p):
                return p.read_text(encoding="utf-8")
        available = sorted(p.stem.replace("-template", "") for p in TEMPLATES_SRC.glob("*.md"))
        return json.dumps({"error": f"unknown template: {tname}", "available": available})

    if root is None:
        return json.dumps(
            {
                "error": "no spar/ directory found",
                "fix": "run /spar.init \"<what you want to build>\" (or `spar init` in a terminal)",
            }
        )

    if name == "spar_status":
        scan = scan_spar(root)
        return json.dumps(
            {
                "project": scan["project"],
                "governance": scan["governance"],
                "features": [
                    {
                        "id": f["id"],
                        "phase": f["phase"],
                        "risk_tier": f["risk_tier"],
                        "tasks": f"{f['tasks_done']}/{f['tasks_total']}",
                        "completion": f["task_completion"],
                        "verification": f["verification"]["status"],
                    }
                    for f in scan["features"]
                ],
                "portfolio": portfolio(scan),
            },
            indent=2,
        )

    if name == "spar_list":
        scan = scan_spar(root)
        return json.dumps(scan, indent=2)

    if name == "spar_metrics":
        scan = scan_spar(root)
        feats = scan["features"]
        if args.get("feature"):
            feats = [f for f in feats if f["id"] == args["feature"]]
        return json.dumps(
            {"features": feats, "portfolio": portfolio({"features": feats})}, indent=2
        )

    if name == "spar_read":
        rel = args.get("path", "")
        target = root / rel
        if not _confined(root, target):
            return json.dumps({"error": "path escapes the spar/ root"})
        if not target.is_file():
            return json.dumps({"error": f"not found: {rel}"})
        return target.read_text(encoding="utf-8", errors="replace")

    if name == "spar_write":
        rel = args.get("path", "")
        target = root / rel
        if ".." in rel or Path(rel).is_absolute():
            return json.dumps({"error": "path escapes the spar/ root"})
        target.parent.mkdir(parents=True, exist_ok=True)
        if not _confined(root, target.parent):
            return json.dumps({"error": "path escapes the spar/ root"})
        target.write_text(args.get("content", ""), encoding="utf-8")
        try:
            write_manifest(root)
        except Exception:
            pass
        return json.dumps({"written": rel, "bytes": len(args.get("content", ""))})

    if name == "spar_check":
        from . import checks as _checks

        feature = args.get("feature") or None
        scope = args.get("scope") or "all"
        if not feature:
            from .next import latest_feature

            feature = latest_feature(root)
        if feature and not (root / "specs" / feature).is_dir():
            return json.dumps({"error": f"unknown feature: {feature}"})
        if scope not in ("artifacts", "project", "verification", "all"):
            return json.dumps({"error": f"unknown scope: {scope}"})
        result = _checks.run(root, feature, scope)
        if args.get("for_agent"):
            return _checks.for_agent(result)
        return json.dumps(result, indent=2)

    if name == "spar_next":
        from .next import compute_next

        feature = args.get("feature") or None
        if feature and not (root / "specs" / feature).is_dir():
            return json.dumps({"error": f"unknown feature: {feature}"})
        return json.dumps(compute_next(root.parent, root, feature), indent=2)

    if name == "spar_decision":
        rec = append_decision(
            root,
            subject={
                # Agents record their own findings; a human decision never comes through this tool.
                "kind": "agent",
                "id": args.get("subject", "unknown"),
                "assurance": "asserted",
            },
            action={"kind": args.get("action", "artifact.approve"), "name": args.get("name", "")},
            resource={"type": "artifact", "id": args.get("resource", ""), "version": ""},
            context={
                "feature_id": args.get("feature", ""),
                "phase": args.get("phase", ""),
            },
            verdict=args.get("verdict", "pass"),
            explanation=args.get("explanation", ""),
        )
        return json.dumps({"seq": rec["seq"], "hash": rec["hash"][:16], "verdict": rec["verdict"]})

    return json.dumps({"error": f"unknown tool: {name}"})


# --------------------------------------------------------------------------- #
# Resources
# --------------------------------------------------------------------------- #


def list_resources() -> list[dict]:
    root = find_spar_root()
    if root is None:
        return []
    out = []
    for p in sorted(root.rglob("*.md")):
        try:
            rel = p.relative_to(root)
        except ValueError:
            continue
        out.append(
            {
                "uri": f"spar://{rel.as_posix()}",
                "name": rel.as_posix(),
                "mimeType": "text/markdown",
            }
        )
    return out


def read_resource(uri: str) -> tuple[str, str] | None:
    root = find_spar_root()
    if root is None or not uri.startswith("spar://"):
        return None
    rel = uri[len("spar://") :]
    target = root / rel
    if not _confined(root, target) or not target.is_file():
        return None
    return target.read_text(encoding="utf-8", errors="replace"), "text/markdown"


# --------------------------------------------------------------------------- #
# Prompts
# --------------------------------------------------------------------------- #


def get_prompt(name: str, args: dict) -> str:
    stages = PROMPT_STAGES.get(name)
    if stages is None:
        return f"Unknown SPAR prompt: {name}"
    extra = " ".join(f"{k}={v}" for k, v in (args or {}).items() if v)

    if claude_mode():
        # Claude Code has the full playbooks: the command plus the shared phase loop.
        data = Path(__file__).resolve().parent / "data"
        cmd = data / "commands" / f"spar.{name}.md"
        if cmd.is_file():
            head = f"# SPAR /{name}\n\n" + (f"Arguments: {extra}\n\n" if extra else "")
            loop = data / "steps" / "phase-loop.md"
            body = strip_frontmatter(cmd.read_text(encoding="utf-8"))
            if loop.is_file():
                body += "\n\n" + strip_frontmatter(loop.read_text(encoding="utf-8"))
            return head + body

    lines = [f"# SPAR /{name} — {PROMPT_DESCRIPTIONS.get(name, '')}", ""]
    if extra:
        lines.append(f"Arguments: {extra}")
        lines.append("")
    lines.append("Work these stages in order without pausing between them; stop only where a stage says to.")
    lines.append("")
    for i, stage in enumerate(stages, start=1):
        lines.append(f"{i}. {stage}")
    lines.append("")
    lines.append(
        "Ground every claim about this organisation in the SPAR gateway (org_search / org_fetch) "
        "and cite it. Write artifacts under spar/ only."
    )
    return cap("\n".join(lines))


# --------------------------------------------------------------------------- #
# JSON-RPC loop
# --------------------------------------------------------------------------- #


def serve() -> int:
    # Debug output must never reach stdout; silence stderr entirely.
    try:
        sys.stderr = open(os.devnull, "w")  # noqa: SIM115
    except OSError:
        pass

    def reply(msg_id, result=None, error=None) -> None:
        out: dict = {"jsonrpc": "2.0", "id": msg_id}
        if error is not None:
            out["error"] = error
        else:
            out["result"] = result
        sys.stdout.write(json.dumps(out) + "\n")
        sys.stdout.flush()

    for raw in sys.stdin:
        raw = raw.strip()
        if not raw:
            continue
        try:
            msg = json.loads(raw)
        except json.JSONDecodeError:
            continue

        method = msg.get("method")
        msg_id = msg.get("id")
        params = msg.get("params") or {}

        if method == "initialize":
            reply(
                msg_id,
                {
                    "protocolVersion": PROTOCOL_VERSION,
                    "capabilities": {"tools": {}, "prompts": {}, "resources": {}},
                    "serverInfo": {"name": "spar", "version": __version__},
                    "instructions": (
                        "SPAR pipeline server. Artifacts live under spar/. Use spar_status to "
                        "orient, spar_next to learn the one next action, spar_template before writing "
                        "any artifact, spar_check to verify what was written, and spar_decision to "
                        "record every gate verdict and approval."
                    ),
                },
            )
            continue

        if method in ("notifications/initialized", "notifications/cancelled"):
            continue

        if method == "ping":
            reply(msg_id, {})
            continue

        if method == "tools/list":
            reply(msg_id, {"tools": TOOLS})
            continue

        if method == "tools/call":
            try:
                text = tool_call(params.get("name", ""), params.get("arguments") or {})
            except Exception as exc:
                text = json.dumps({"error": f"{type(exc).__name__}: {exc}"})
            reply(msg_id, {"content": [{"type": "text", "text": cap(text)}]})
            continue

        if method == "prompts/list":
            reply(
                msg_id,
                {
                    "prompts": [
                        {
                            "name": n,
                            "description": PROMPT_DESCRIPTIONS.get(n, ""),
                            "arguments": [
                                {"name": "args", "description": "free-form arguments", "required": False}
                            ],
                        }
                        for n in PROMPT_STAGES
                    ]
                },
            )
            continue

        if method == "prompts/get":
            name = params.get("name", "")
            text = get_prompt(name, params.get("arguments") or {})
            reply(
                msg_id,
                {
                    "description": PROMPT_DESCRIPTIONS.get(name, ""),
                    "messages": [
                        {"role": "user", "content": {"type": "text", "text": text}}
                    ],
                },
            )
            continue

        if method == "resources/list":
            reply(msg_id, {"resources": list_resources()})
            continue

        if method == "resources/read":
            uri = params.get("uri", "")
            got = read_resource(uri)
            if got is None:
                reply(msg_id, error={"code": -32602, "message": f"cannot read {uri}"})
            else:
                text, mime = got
                reply(
                    msg_id,
                    {"contents": [{"uri": uri, "mimeType": mime, "text": cap(text)}]},
                )
            continue

        if msg_id is not None:
            reply(msg_id, error={"code": -32601, "message": f"method not found: {method}"})

    return 0


if __name__ == "__main__":
    sys.exit(serve())
