"""Organisation credential store, held on the gateway host.

The point of this module is that a developer never handles a credential. An
administrator sets each connector's credential once, on the machine that runs
the gateway; every developer reaches it through the gateway and supplies
nothing.

Three ways to hold a credential, in the order they are consulted:

1. **A secret-manager command.** The preferred form. The stored value is an
   argv list; the gateway runs it and takes stdout. Nothing sensitive is at
   rest here at all -- ``["vault","kv","get","-field=token","secret/github"]``
   or ``["az","keyvault","secret","show","--query","value","-o","tsv", ...]``.
2. **A literal value** in ``credentials.json``, mode 0600, in the gateway's
   config directory. Convenient, and honestly labelled: this is a protected
   file on one host, not a KMS. Anyone with root on the gateway host, or the
   ability to read that file, has the credential.
3. **The gateway process's own environment**, so a single developer running
   everything locally still works with nothing configured.

Read paths are deliberately asymmetric: a value can be written and used, and
its *presence* can be reported, but no function here returns a value to any
caller other than the code that injects it into an upstream call.
"""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

CREDENTIALS_FILE = "credentials.json"
# A secret-manager command is trusted input (an admin wrote it) but it is still
# run without a shell, and it is never allowed to hang the gateway.
COMMAND_TIMEOUT = 10.0


def config_dir() -> Path:
    """Where host-level state lives -- the same directory the registry, policy
    and extra connectors come from, so relocating one relocates all of them."""
    from .cli import host_config_dir

    return host_config_dir()


def credentials_path() -> Path:
    return config_dir() / CREDENTIALS_FILE


def _read() -> dict:
    p = credentials_path()
    if not p.is_file():
        return {}
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _write(data: dict) -> Path:
    p = credentials_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    # Create with the right mode from the start; never widen an existing file.
    fd = os.open(str(p), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, sort_keys=True)
        fh.write("\n")
    os.chmod(p, 0o600)
    return p


def set_secret(connector: str, var: str, value: str) -> Path:
    """Store a literal credential value for one connector's variable."""
    data = _read()
    data.setdefault(connector, {})[var] = {"kind": "literal", "value": value}
    return _write(data)


def set_command(connector: str, var: str, argv: list[str]) -> Path:
    """Store a secret-manager command whose stdout is the credential."""
    if not argv or not all(isinstance(a, str) and a for a in argv):
        raise ValueError("a secret command must be a non-empty list of strings")
    data = _read()
    data.setdefault(connector, {})[var] = {"kind": "command", "argv": list(argv)}
    return _write(data)


def clear_secret(connector: str, var: str) -> bool:
    data = _read()
    entry = data.get(connector) or {}
    if var not in entry:
        return False
    del entry[var]
    if not entry:
        data.pop(connector, None)
    _write(data)
    return True


def resolve(connector: str, var: str) -> str | None:
    """The credential value, or None. The only function that returns one.

    Callers are the gateway's upstream spawn and header paths. Nothing that
    serves a browser may call this.
    """
    entry = (_read().get(connector) or {}).get(var)
    if isinstance(entry, dict):
        if entry.get("kind") == "literal":
            val = entry.get("value")
            if isinstance(val, str) and val:
                return val
        elif entry.get("kind") == "command":
            argv = entry.get("argv") or []
            try:
                out = subprocess.run(
                    argv,
                    capture_output=True,
                    text=True,
                    timeout=COMMAND_TIMEOUT,
                    check=False,
                )
            except (OSError, subprocess.SubprocessError):
                return None
            if out.returncode == 0:
                val = out.stdout.strip()
                return val or None
            return None
    # Fall back to this host's environment so a solo developer needs no setup.
    val = os.environ.get(var)
    return val or None


def state(connector: str, var: str) -> dict:
    """How this credential is held, and whether it resolves -- never its value."""
    entry = (_read().get(connector) or {}).get(var)
    if isinstance(entry, dict) and entry.get("kind") == "command":
        argv = entry.get("argv") or []
        return {
            "var": var,
            "source": "command",
            "command": " ".join(argv),
            "present": resolve(connector, var) is not None,
        }
    if isinstance(entry, dict) and entry.get("kind") == "literal":
        return {"var": var, "source": "vault", "present": bool(entry.get("value"))}
    if os.environ.get(var):
        return {"var": var, "source": "environment", "present": True}
    return {"var": var, "source": "", "present": False}


def summary() -> dict:
    """Presence per connector, for the admin UI. Values never appear."""
    data = _read()
    out = {}
    for connector, entry in data.items():
        if not isinstance(entry, dict):
            continue
        out[connector] = [state(connector, var) for var in sorted(entry)]
    return out
