"""SPAR MCP gateway.

One MCP server that the host registers once, fronting every org connector the
team has configured. Agents address systems by **role** (docs, issues, scm, ci,
db, catalog, security) rather than by hostname, so identical prompts work in any
organisation.

What the gateway adds over registering each upstream server directly:

* **Unified namespace** -- ``org_search`` / ``org_fetch`` route by role, and every
  upstream tool is also reachable as ``<alias>__<tool>``.
* **Citations** -- every result carries connector, id, url and retrieved_at so the
  agent can cite a source instead of asserting "the docs say X".
* **Policy** -- read-only connectors refuse mutating tools; database connectors are
  schema-first and refuse queries unless the registry opts in. Denials are recorded
  in the hash-chained decision ledger, which makes this a design-time policy
  enforcement point.
* **Caching** -- identical read calls inside a TTL are served from disk, which cuts
  both latency and tokens.

Standard library only. Upstream stdio servers are spoken to over pipes; upstream
HTTP servers over ``urllib``.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

from . import __version__
from .vault import resolve as vault_resolve


def org_enabled_entry(conn: dict) -> bool:
    """Whether the organisation has enabled this connector at all."""
    return conn.get("availability") != "not-enabled-by-org"


def access_scopes(subject: dict | None):
    """Connector ids this caller may reach, or None for everything enabled."""
    from . import access

    if subject is None:
        return None          # local mode: one developer, one machine, no scoping
    return access.scopes_for(subject)
from .cli import (
    append_decision,
    connector_endpoint,
    find_spar_root,
    load_catalog,
    load_gateway_policy,
    load_project_selection,
    load_registry,
    missing_config,
    now_iso,
    resolve_connectors,
)

PROTOCOL_VERSION = "2025-06-18"
CACHE_TTL_SECONDS = int(os.environ.get("SPAR_GATEWAY_CACHE_TTL", "900"))
UPSTREAM_TIMEOUT = float(os.environ.get("SPAR_GATEWAY_TIMEOUT", "45"))
MAX_RESULT_CHARS = int(os.environ.get("SPAR_GATEWAY_MAX_CHARS", "24000"))

# Tool-name heuristics used to route role-addressed calls onto whatever the
# upstream server happens to call its search / fetch operations.
SEARCH_HINTS = ("search", "query", "find", "lookup", "grep")
FETCH_HINTS = ("get", "read", "fetch", "show", "content", "page", "file")
SCHEMA_HINTS = ("schema", "describe", "tables", "columns", "introspect", "metadata")
MUTATING_HINTS = (
    "create",
    "update",
    "delete",
    "write",
    "put",
    "post",
    "patch",
    "insert",
    "drop",
    "alter",
    "merge",
    "push",
    "comment",
    "transition",
    "execute",
    "run",
)


def log(msg: str) -> None:
    """Diagnostics go to stderr; stdout is the JSON-RPC stream and must stay clean."""
    if os.environ.get("SPAR_GATEWAY_DEBUG"):
        sys.stderr.write(f"[spar-gateway] {msg}\n")
        sys.stderr.flush()


# --------------------------------------------------------------------------- #
# Upstream transports
# --------------------------------------------------------------------------- #


class Upstream:
    """A lazily-connected upstream MCP server."""

    def __init__(self, conn: dict):
        self.conn = conn
        self.id = conn.get("alias") or conn["id"]
        self.role = conn.get("role", "docs")
        self.readonly = bool(conn.get("readonly", True))
        self.allow_query = bool((conn.get("config_values") or {}).get("allow_query", False))
        # Only the spawn path resolves secrets; everything else sees $VAR_NAME.
        self.transport, self.endpoint = connector_endpoint(conn, resolve_secrets=True)
        self.display_endpoint = connector_endpoint(conn)[1]
        self._tools: list[dict] | None = None
        # Exactly which secret strings this gateway handed to this upstream, so
        # they can be scrubbed back out if the upstream reflects one.
        self._injected: dict[str, str] = {}
        self._proc: subprocess.Popen | None = None
        self._next_id = 0
        self._lock = threading.Lock()
        self._error: str | None = None

    # -- framing ---------------------------------------------------------- #

    def _rpc_id(self) -> int:
        self._next_id += 1
        return self._next_id

    @staticmethod
    def signature_of(conn: dict) -> str:
        """What would have to change for this upstream to need rebuilding."""
        return json.dumps(
            {
                "id": conn.get("id"),
                "transport": conn.get("transport"),
                "command": conn.get("command"),
                "url_template": conn.get("url_template"),
                "values": conn.get("config_values") or {},
            },
            sort_keys=True,
            default=str,
        )

    def signature(self) -> str:
        return Upstream.signature_of(self.conn)

    def close(self) -> None:
        """Stop a spawned upstream. Credentials held for scrubbing go with it."""
        self._injected = {}
        proc = self._proc
        self._proc = None
        if proc and proc.poll() is None:
            try:
                proc.terminate()
                proc.wait(timeout=3)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass

    # -- credentials ------------------------------------------------------ #

    def _secret(self, var: str) -> str | None:
        """Resolve a credential once and remember it for scrubbing.

        Remembering avoids re-running a secret-manager command on every call,
        and gives ``scrub`` the exact strings to look for. It is held only in
        this process's memory and is never logged or serialised.
        """
        if var in self._injected:
            return self._injected[var]
        secret = vault_resolve(self.conn.get("id", ""), var)
        if secret:
            self._injected[var] = secret
        return secret

    def scrub(self, text: str) -> tuple[str, int]:
        """Remove any credential this gateway gave this upstream from a response.

        An upstream that echoes its own auth header -- a debug endpoint, a
        verbose error, a badly written server -- would otherwise hand the
        organisation's credential to every developer who queries it. The gateway
        is the only party that knows the value, so it is the only party that can
        guarantee this. Exact-string matching, so there are no false positives.
        """
        hits = 0
        for var, value in self._injected.items():
            if value and value in text:
                hits += text.count(value)
                text = text.replace(value, f"[credential ${var} withheld by AEGIS]")
        return text, hits

    def _headers(self) -> dict[str, str]:
        # MCP's Streamable HTTP transport requires a client to accept both a JSON
        # body and an SSE stream, because the server chooses which to return per
        # request. Offering only JSON is rejected outright by servers that follow
        # the spec -- GitHub's answers 400 to an otherwise valid initialize.
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
        }
        values = self.conn.get("config_values") or {}
        token_env = values.get("token_env")
        if isinstance(token_env, str) and token_env:
            # The organisation set this once, on this host. A developer's own
            # environment is never consulted -- they never had the credential.
            secret = self._secret(token_env)
            if secret:
                scheme = values.get("auth_scheme") or self.conn.get("auth_scheme") or "Bearer"
                headers["Authorization"] = f"{scheme} {secret}"
        extra = values.get("headers")
        if isinstance(extra, dict):
            for k, v in extra.items():
                headers[str(k)] = str(v)
        return headers

    def _http_call(self, method: str, params: dict) -> dict:
        body = json.dumps(
            {"jsonrpc": "2.0", "id": self._rpc_id(), "method": method, "params": params}
        ).encode("utf-8")
        req = urllib.request.Request(str(self.endpoint), data=body, headers=self._headers())
        with urllib.request.urlopen(req, timeout=UPSTREAM_TIMEOUT) as resp:
            ctype = resp.headers.get("Content-Type", "")
            raw = resp.read().decode("utf-8", errors="replace")
        if "text/event-stream" in ctype:
            # Minimal SSE: take the last complete `data:` payload.
            payloads = [
                line[5:].strip()
                for line in raw.splitlines()
                if line.startswith("data:") and line[5:].strip()
            ]
            raw = payloads[-1] if payloads else "{}"
        return json.loads(raw or "{}")

    def _ensure_proc(self) -> subprocess.Popen:
        if self._proc and self._proc.poll() is None:
            return self._proc
        argv = list(self.endpoint) if isinstance(self.endpoint, list) else [str(self.endpoint)]
        env = dict(os.environ)
        values = self.conn.get("config_values") or {}
        for key, val in values.items():
            if key.endswith("_env") and isinstance(val, str) and val:
                secret = self._secret(val)
                if secret:
                    env[val] = secret
        log(f"spawning {self.id}: {' '.join(argv)}")
        self._proc = subprocess.Popen(
            argv,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            bufsize=1,
            env=env,
        )
        self._stdio_call("initialize", {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {},
            "clientInfo": {"name": "spar-gateway", "version": __version__},
        }, initialising=True)
        self._notify("notifications/initialized")
        return self._proc

    def _notify(self, method: str) -> None:
        if not self._proc or not self._proc.stdin:
            return
        try:
            self._proc.stdin.write(json.dumps({"jsonrpc": "2.0", "method": method}) + "\n")
            self._proc.stdin.flush()
        except (BrokenPipeError, OSError):
            pass

    def _stdio_call(self, method: str, params: dict, initialising: bool = False) -> dict:
        proc = self._proc if initialising else self._ensure_proc()
        if proc is None or proc.stdin is None or proc.stdout is None:
            raise RuntimeError("upstream process unavailable")
        rpc_id = self._rpc_id()
        proc.stdin.write(
            json.dumps({"jsonrpc": "2.0", "id": rpc_id, "method": method, "params": params}) + "\n"
        )
        proc.stdin.flush()
        deadline = time.time() + UPSTREAM_TIMEOUT
        while time.time() < deadline:
            line = proc.stdout.readline()
            if not line:
                raise RuntimeError("upstream closed the stream")
            line = line.strip()
            if not line:
                continue
            try:
                msg = json.loads(line)
            except json.JSONDecodeError:
                continue
            if msg.get("id") == rpc_id:
                return msg
        raise TimeoutError(f"upstream {self.id} timed out after {UPSTREAM_TIMEOUT}s")

    def call(self, method: str, params: dict) -> dict:
        with self._lock:
            if self.transport == "http":
                return self._http_call(method, params)
            return self._stdio_call(method, params)

    # -- capability discovery --------------------------------------------- #

    def tools(self) -> list[dict]:
        if self._tools is not None:
            return self._tools
        try:
            resp = self.call("tools/list", {})
            self._tools = (resp.get("result") or {}).get("tools") or []
            log(f"{self.id}: {len(self._tools)} upstream tools")
        except Exception as exc:  # upstream may be down; degrade, never crash
            self._error = f"{type(exc).__name__}: {exc}"
            self._tools = []
            log(f"{self.id}: tools/list failed -- {self._error}")
        return self._tools

    def pick_tool(self, hints: tuple[str, ...]) -> str | None:
        names = [t.get("name", "") for t in self.tools()]
        for hint in hints:
            for name in names:
                if hint in name.lower():
                    return name
        return None

    @property
    def error(self) -> str | None:
        return self._error


# --------------------------------------------------------------------------- #
# Policy
# --------------------------------------------------------------------------- #


def is_mutating(tool_name: str) -> bool:
    low = tool_name.lower()
    return any(h in low for h in MUTATING_HINTS)


class Policy:
    """Connector-level policy enforced on every upstream call.

    Agent-level restriction is enforced separately by each agent's ``tools:``
    frontmatter allow-list in the host -- the MCP protocol does not carry a caller
    identity, so the gateway does not pretend to know one. What the gateway *can*
    enforce is: read-only posture, schema-first databases, globally denied tools
    (secret values), and redaction of anything credential-shaped in a response.
    """

    def __init__(self, spar_root: Path | None):
        self.spar_root = spar_root
        self.rules = load_gateway_policy(spar_root)
        self.deny_tools = {str(t).lower() for t in self.rules.get("deny_tools", [])}
        self.redactors = []
        for pat in self.rules.get("redact_patterns", []) or []:
            try:
                self.redactors.append(re.compile(pat))
            except re.error:
                log(f"ignoring invalid redact pattern: {pat}")

    def _connector_rule(self, connector: str, key: str, default=None):
        per = (self.rules.get("connectors") or {}).get(connector) or {}
        if key in per:
            return per[key]
        return default

    def check(self, up: Upstream, tool_name: str) -> tuple[bool, str]:
        low = tool_name.lower()

        # 1. Globally denied tools -- secret values must never reach an agent.
        for denied in self.deny_tools:
            if denied in low:
                return False, (
                    f"tool '{tool_name}' is denied by gateway policy (deny_tools). SPAR is "
                    f"designed to know that a secret exists, never what its value is."
                )

        # 2. Read-only posture, overridable per connector in gateway-policy.yaml.
        readonly = self._connector_rule(up.id, "readonly", up.readonly)
        if readonly and is_mutating(tool_name):
            return False, (
                f"connector '{up.id}' is read-only; '{tool_name}' looks mutating. Set "
                f"readonly: false for this connector in your org registry or gateway policy."
            )

        # 3. Schema-first databases.
        role_rules = (self.rules.get("roles") or {}).get(up.role) or {}
        schema_only = role_rules.get("schema_only", up.role == "db")
        if schema_only and up.role == "db" and not up.allow_query:
            if not any(h in low for h in SCHEMA_HINTS):
                return False, (
                    f"database connector '{up.id}' is schema-first: only introspection is "
                    f"permitted. Set allow_query: true in your org registry to enable "
                    f"'{tool_name}'."
                )
        return True, ""

    def redact(self, text: str) -> tuple[str, int]:
        """Mask anything credential-shaped before an agent ever sees it."""
        count = 0
        for rx in self.redactors:
            text, n = rx.subn("[REDACTED BY SPAR GATEWAY]", text)
            count += n
        return text, count

    def max_chars(self, up: Upstream) -> int:
        per = self._connector_rule(up.id, "max_result_chars")
        if per:
            return int(per)
        return int((self.rules.get("default") or {}).get("max_result_chars", MAX_RESULT_CHARS))

    def record_denial(self, up: Upstream, tool_name: str, reason: str) -> None:
        if not self.spar_root:
            return
        try:
            append_decision(
                self.spar_root,
                subject={"kind": "agent", "id": "spar-gateway", "assurance": "asserted"},
                action={"kind": "tool.invoke", "name": f"{up.id}__{tool_name}"},
                resource={"type": "connector", "id": up.id, "version": up.role},
                context={"feature_id": "", "phase": "context", "role": up.role},
                verdict="blocked",
                explanation=reason,
            )
        except Exception as exc:  # never let auditing break a call path
            log(f"could not record denial: {exc}")


# --------------------------------------------------------------------------- #
# Cache & call log
# --------------------------------------------------------------------------- #


class Cache:
    def __init__(self, spar_root: Path | None, ttl: int | None = None):
        # Policy `default.cache_ttl_seconds` wins; the env var is the fallback.
        self.ttl = int(ttl) if ttl else CACHE_TTL_SECONDS
        self.dir = (spar_root / "cache" / "gateway") if spar_root else None
        if self.dir:
            try:
                self.dir.mkdir(parents=True, exist_ok=True)
            except OSError:
                self.dir = None
        self.mem: dict[str, tuple[float, Any]] = {}

    @staticmethod
    def key(connector: str, tool: str, args: dict) -> str:
        blob = json.dumps([connector, tool, args], sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:32]

    def get(self, key: str):
        hit = self.mem.get(key)
        if hit and time.time() - hit[0] < self.ttl:
            return hit[1]
        if not self.dir:
            return None
        path = self.dir / f"{key}.json"
        if not path.is_file():
            return None
        try:
            if time.time() - path.stat().st_mtime > self.ttl:
                return None
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        self.mem[key] = (time.time(), data)
        return data

    def put(self, key: str, value) -> None:
        self.mem[key] = (time.time(), value)
        if not self.dir:
            return
        try:
            (self.dir / f"{key}.json").write_text(
                json.dumps(value, separators=(",", ":")), encoding="utf-8"
            )
        except (OSError, TypeError):
            pass


def log_call(spar_root: Path | None, entry: dict) -> None:
    if not spar_root:
        return
    try:
        with (spar_root / "gateway-log.jsonl").open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry, separators=(",", ":")) + "\n")
    except OSError:
        pass


# --------------------------------------------------------------------------- #
# Gateway
# --------------------------------------------------------------------------- #


class Gateway:
    """The org's connectors, shared, with everything caller-specific per request.

    One process holds the upstream connections, so a spawned server and its cache
    are shared by everyone rather than duplicated per developer. Everything that
    differs between callers -- which project they are in, which policy applies,
    which connectors they may reach -- is resolved on each request and kept in
    thread-local state, because a hosted gateway serves many people at once.
    """

    def __init__(self):
        self.upstreams: dict[str, Upstream] = {}
        self.unconfigured: list[dict] = []
        self.excluded: list[dict] = []
        self.registry: dict = {}
        self.registry_path = None
        self.tried: list = []
        self._sig = None
        self._rlock = threading.Lock()
        self._local = threading.local()
        self.host_root = find_spar_root()
        _ttl = None
        try:
            _ttl = (load_gateway_policy(self.host_root).get("default") or {}).get("cache_ttl_seconds")
        except Exception:  # policy problems are reported elsewhere; the cache just falls back
            _ttl = None
        self.cache = Cache(self.host_root, _ttl)
        self.load_registry_if_changed()

    # -- registry, reloaded when it changes ------------------------------- #

    def load_registry_if_changed(self) -> bool:
        """Pick up registry edits without a restart.

        Upstreams whose configuration is unchanged are kept, so a running server
        and its warm connection survive an unrelated edit; only what actually
        changed is torn down.
        """
        registry, rpath, tried = load_registry(None)
        sig = json.dumps(registry, sort_keys=True, default=str)
        with self._rlock:
            if sig == self._sig:
                return False
            self._sig = sig
            self.registry, self.registry_path, self.tried = registry, rpath, tried
            keep: dict[str, Upstream] = {}
            self.unconfigured = []
            self.excluded = []
            # Org tier only. The project tier and the caller's own scope are
            # applied per request, since they differ per caller.
            for conn in resolve_connectors(registry, selection=None, include_disabled=True):
                label = conn.get("alias") or conn["id"]
                if not org_enabled_entry(conn):
                    self.excluded.append({"id": label, "reason": "not-enabled-by-org"})
                    continue
                miss = missing_config(conn)
                if miss:
                    self.unconfigured.append({"id": label, "missing": miss})
                    continue
                prev = self.upstreams.get(label)
                if prev is not None and prev.signature() == Upstream.signature_of(conn):
                    keep[label] = prev
                else:
                    if prev is not None:
                        prev.close()
                    keep[label] = Upstream(conn)
            for label, up in self.upstreams.items():
                if label not in keep:
                    up.close()
            self.upstreams = keep
        return True

    # -- per-request context --------------------------------------------- #

    def begin(self, subject: dict | None, project_root: Path | None) -> dict:
        """Resolve who is calling, from where, and what that permits.

        Called once per request. The project root comes from the caller, so a
        developer's own ``spar/`` decides their connector selection and policy --
        not whichever directory the gateway process happens to sit in.
        """
        self.load_registry_if_changed()
        L = self._local
        L.subject = subject
        L.spar_root = project_root
        L.policy = Policy(project_root)
        L.selection = load_project_selection(project_root)
        L.scope = access_scopes(subject)
        L.excluded_for_caller = []
        allowed = {}
        for label, up in self.upstreams.items():
            cid = up.conn.get("id", label)
            if L.selection is not None and label not in L.selection and cid not in L.selection:
                L.excluded_for_caller.append({"id": label, "reason": "not-selected-for-project"})
                continue
            if L.scope is not None and label not in L.scope and cid not in L.scope:
                L.excluded_for_caller.append({"id": label, "reason": "not-in-your-access-scope"})
                continue
            allowed[label] = up
        L.allowed = allowed
        return {"allowed": sorted(allowed), "excluded": L.excluded_for_caller}

    @property
    def policy(self) -> "Policy":
        return getattr(self._local, "policy", None) or Policy(self.host_root)

    @property
    def spar_root(self):
        return getattr(self._local, "spar_root", None) or self.host_root

    @property
    def selection(self):
        return getattr(self._local, "selection", None)

    @property
    def reachable(self) -> dict:
        """The upstreams this caller may use. Everything else is invisible."""
        got = getattr(self._local, "allowed", None)
        return self.upstreams if got is None else got

    # -- helpers ---------------------------------------------------------- #

    def by_role(self, role: str) -> list[Upstream]:
        return [u for u in self.reachable.values() if u.role == role]

    def targets(self, role: str | None, connector: str | None) -> list[Upstream]:
        if connector:
            up = self.reachable.get(connector)
            return [up] if up else []
        if role:
            return self.by_role(role)
        return list(self.reachable.values())

    def who(self) -> dict:
        """Log fields naming the developer this call is on behalf of. Empty in
        local mode, where the developer is the only person on the machine."""
        s = getattr(self._local, "subject", None)
        return {"subject": s["label"], "subject_id": s["id"]} if s else {}

    def invoke(self, up: Upstream, tool_name: str, arguments: dict) -> dict:
        allowed, reason = self.policy.check(up, tool_name)
        if not allowed:
            self.policy.record_denial(up, tool_name, reason)
            log_call(
                self.spar_root,
                {
                    "at": now_iso(),
                    "connector": up.id,
                    "tool": tool_name,
                    **self.who(),
                    "verdict": "blocked",
                    "reason": reason,
                },
            )
            return {"error": reason, "verdict": "blocked"}

        ck = Cache.key(up.id, tool_name, arguments)
        cached = self.cache.get(ck)
        if cached is not None:
            log_call(
                self.spar_root,
                {"at": now_iso(), "connector": up.id, "tool": tool_name,
                    **self.who(), "verdict": "cache-hit"},
            )
            return cached

        started = time.time()
        try:
            resp = up.call("tools/call", {"name": tool_name, "arguments": arguments})
        except Exception as exc:
            # An exception message can carry the request that caused it, headers
            # included, so it is scrubbed on the same terms as a response.
            detail, _ = up.scrub(f"{type(exc).__name__}: {exc}")
            err = {"error": detail, "connector": up.id, "tool": tool_name}
            log_call(
                self.spar_root,
                {"at": now_iso(), "connector": up.id, "tool": tool_name,
                    **self.who(), "verdict": "error",
                 "reason": err["error"]},
            )
            return err

        payload = resp.get("result", resp)
        text = self._flatten(payload)
        # Credential scrubbing runs before policy redaction and is not
        # configurable: no policy may permit a credential back out.
        text, reflected = up.scrub(text)
        text, redacted = self.policy.redact(text)
        cap = self.policy.max_chars(up)
        truncated = len(text) > cap
        if truncated:
            text = text[:cap] + f"\n\n[truncated by SPAR gateway at {cap} chars]"
        result = {
            "connector": up.id,
            "role": up.role,
            "tool": tool_name,
            "redacted_spans": redacted,
            "credential_reflected": reflected,
            "truncated": truncated,
            "citation": {
                "connector": up.id,
                "role": up.role,
                "tool": tool_name,
                "endpoint": up.display_endpoint if isinstance(up.display_endpoint, str) else "stdio",
                "retrieved_at": now_iso(),
            },
            "content": text,
        }
        self.cache.put(ck, result)
        log_call(
            self.spar_root,
            {
                "at": now_iso(),
                "connector": up.id,
                "tool": tool_name,
                    **self.who(),
                "verdict": "ok",
                "ms": int((time.time() - started) * 1000),
                "chars": len(text),
                "redacted": redacted,
                **({"credential_reflected": reflected} if reflected else {}),
            },
        )
        if reflected:
            log(f"{up.id} reflected its own credential {reflected}x -- withheld")
        return result

    @staticmethod
    def _flatten(payload: Any) -> str:
        """Reduce an MCP tool result to text an agent can read."""
        if payload is None:
            return ""
        if isinstance(payload, str):
            return payload
        if isinstance(payload, dict):
            content = payload.get("content")
            if isinstance(content, list):
                parts = []
                for block in content:
                    if isinstance(block, dict):
                        if block.get("type") == "text":
                            parts.append(block.get("text", ""))
                        elif "text" in block:
                            parts.append(str(block["text"]))
                        else:
                            parts.append(json.dumps(block, indent=2)[:2000])
                    else:
                        parts.append(str(block))
                return "\n\n".join(p for p in parts if p)
            if "text" in payload:
                return str(payload["text"])
        try:
            return json.dumps(payload, indent=2)
        except (TypeError, ValueError):
            return str(payload)

    # -- tool surface ----------------------------------------------------- #

    def tool_list(self) -> list[dict]:
        tools: list[dict] = [
            {
                "name": "org_connectors",
                "description": (
                    "List the organisation systems SPAR can reach, with their role "
                    "(docs, issues, scm, ci, db, catalog, security) and status. Call this "
                    "first to learn what grounding is available before proposing a design."
                ),
                "inputSchema": {"type": "object", "properties": {}},
            },
            {
                "name": "org_search",
                "description": (
                    "Search organisation systems by role and return results with citations. "
                    "Use this BEFORE the open web for anything about how this organisation "
                    "builds software. role: docs | issues | scm | ci | catalog | security | memory."
                ),
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "What to look for"},
                        "role": {
                            "type": "string",
                            "description": "Which class of system to search",
                            "enum": ["docs", "issues", "scm", "ci", "db", "catalog", "security", "observability", "memory"],
                        },
                        "connector": {
                            "type": "string",
                            "description": "Optional: target one connector id instead of a role",
                        },
                        "limit": {"type": "integer", "description": "Max results per connector"},
                    },
                    "required": ["query"],
                },
            },
            {
                "name": "org_fetch",
                "description": (
                    "Fetch one document, page, file or issue by id/path/url from a connector, "
                    "returning its content plus a citation."
                ),
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string", "description": "Page id, file path, issue key or URL"},
                        "role": {"type": "string"},
                        "connector": {"type": "string"},
                    },
                    "required": ["id"],
                },
            },
            {
                "name": "org_db_schema",
                "description": (
                    "Introspect a database connector: tables, columns, types, keys. "
                    "Schema-first by design -- arbitrary SQL requires allow_query in the registry."
                ),
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "connector": {"type": "string"},
                        "object": {"type": "string", "description": "Optional table or schema name"},
                    },
                },
            },
            {
                "name": "org_call",
                "description": (
                    "Escape hatch: call a specific upstream tool by connector and tool name. "
                    "Use org_connectors to discover available tool names."
                ),
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "connector": {"type": "string"},
                        "tool": {"type": "string"},
                        "arguments": {"type": "object"},
                    },
                    "required": ["connector", "tool"],
                },
            },
        ]
        return tools

    def handle_tool(self, name: str, args: dict, subject: dict | None = None) -> str:
        self._local.subject = subject
        if name == "org_connectors":
            return json.dumps(self.describe(), indent=2)

        if name == "org_search":
            query = args.get("query", "")
            role = args.get("role")
            connector = args.get("connector")
            limit = args.get("limit") or 5
            ups = self.targets(role, connector)
            if not ups:
                return json.dumps(
                    {
                        "results": [],
                        "note": self._no_target_note(role, connector),
                    },
                    indent=2,
                )
            results = []
            for up in ups:
                tool = up.pick_tool(SEARCH_HINTS)
                if not tool:
                    results.append(
                        {"connector": up.id, "error": up.error or "no search-like tool exposed"}
                    )
                    continue
                payload = self._search_args(up, tool, query, limit)
                results.append(self.invoke(up, tool, payload))
            return json.dumps({"query": query, "results": results}, indent=2)

        if name == "org_fetch":
            ident = args.get("id", "")
            ups = self.targets(args.get("role"), args.get("connector"))
            if not ups:
                return json.dumps({"note": self._no_target_note(args.get("role"), args.get("connector"))})
            out = []
            for up in ups:
                tool = up.pick_tool(FETCH_HINTS)
                if not tool:
                    out.append({"connector": up.id, "error": up.error or "no fetch-like tool exposed"})
                    continue
                out.append(self.invoke(up, tool, self._fetch_args(up, tool, ident)))
                if out and not out[-1].get("error"):
                    break  # first success wins
            return json.dumps({"id": ident, "results": out}, indent=2)

        if name == "org_db_schema":
            ups = self.targets("db", args.get("connector"))
            if not ups:
                return json.dumps({"note": "no database connector configured"})
            out = []
            for up in ups:
                tool = up.pick_tool(SCHEMA_HINTS)
                if not tool:
                    out.append({"connector": up.id, "error": up.error or "no schema tool exposed"})
                    continue
                payload = {}
                if args.get("object"):
                    payload = {"table": args["object"]}
                out.append(self.invoke(up, tool, payload))
            return json.dumps({"results": out}, indent=2)

        if name == "org_call":
            up = self.reachable.get(args.get("connector", ""))
            if not up:
                return json.dumps({"error": f"unknown connector: {args.get('connector')}"})
            return json.dumps(
                self.invoke(up, args.get("tool", ""), args.get("arguments") or {}), indent=2
            )

        # Namespaced passthrough: <alias>__<tool>
        if "__" in name:
            alias, _, tool = name.partition("__")
            up = self.reachable.get(alias)
            if up:
                return json.dumps(self.invoke(up, tool, args), indent=2)

        return json.dumps({"error": f"unknown tool: {name}"})

    def _no_target_note(self, role: str | None, connector: str | None) -> str:
        want = connector or role or "?"

        # If the target exists but was excluded by a tier, say which one -- an agent
        # should tell the user "your organisation has not enabled that" rather than
        # concluding the information does not exist.
        for e in list(self.excluded) + list(getattr(self._local, "excluded_for_caller", []) or []):
            if e["id"] == want:
                if e["reason"] == "not-enabled-by-org":
                    return (
                        f"'{want}' is not enabled by your organisation, so it cannot be reached. "
                        f"Record this as a grounding gap; do not substitute a guess. An "
                        f"administrator can enable it in the control plane."
                    )
                if e["reason"] == "not-in-your-access-scope":
                    return (
                        f"'{want}' exists but is outside the access granted to you. Record the "
                        f"gap; do not substitute a guess. An administrator controls this."
                    )
                return (
                    f"'{want}' is enabled by your organisation but not selected for this project. "
                    f"Record the gap, and tell the user they can add it in Connections."
                )

        if not self.reachable:
            if self.registry is None:
                return (
                    "No org connectors are configured, so there is no internal grounding "
                    "available. Say so explicitly rather than guessing, and fall back to the "
                    "open web only for genuinely public information."
                )
            if self.excluded:
                return (
                    "No connector is active for this project. "
                    f"{len(self.excluded)} are excluded: "
                    + "; ".join(f"{e['id']} ({e['reason']})" for e in self.excluded[:6])
                    + ". Record this as a grounding gap."
                )
            return (
                "An org registry exists but no connector is usable. Run `spar connectors test` "
                f"to diagnose. Unconfigured: {self.unconfigured}"
            )

        available = sorted({u.role for u in self.reachable.values()})
        note = f"No connector matches '{want}'. Available roles: {', '.join(available)}."
        if self.excluded:
            note += f" {len(self.excluded)} connector(s) are excluded by org or project settings."
        return note

    @staticmethod
    def _search_args(up: Upstream, tool: str, query: str, limit: int) -> dict:
        """Build arguments for an upstream search tool from its declared schema."""
        schema = {}
        for t in up.tools():
            if t.get("name") == tool:
                schema = (t.get("inputSchema") or {}).get("properties") or {}
                break
        args: dict[str, Any] = {}
        for key in ("query", "q", "text", "search", "searchQuery", "cql", "jql", "keyword"):
            if key in schema:
                args[key] = query
                break
        if not args:
            args["query"] = query
        for key in ("limit", "maxResults", "max_results", "count", "top"):
            if key in schema:
                args[key] = limit
                break
        return args

    @staticmethod
    def _fetch_args(up: Upstream, tool: str, ident: str) -> dict:
        schema = {}
        for t in up.tools():
            if t.get("name") == tool:
                schema = (t.get("inputSchema") or {}).get("properties") or {}
                break
        for key in ("id", "pageId", "page_id", "path", "file_path", "key", "issueKey", "url", "uri"):
            if key in schema:
                return {key: ident}
        return {"id": ident}

    def describe(self) -> dict:
        conns = []
        for up in self.reachable.values():
            tool_names = [t.get("name") for t in up.tools()]
            conns.append(
                {
                    "id": up.id,
                    "role": up.role,
                    "transport": up.transport,
                    "readonly": up.readonly,
                    "allow_query": up.allow_query,
                    "reachable": up.error is None,
                    "error": up.error,
                    "tools": tool_names[:40],
                }
            )
        # Both tiers of exclusion, org-wide and caller-specific. An agent that is
        # merely not shown a connector will invent an answer; one that is told the
        # connector exists but is out of reach can say so instead.
        excluded = []
        seen = set()
        for e in list(self.excluded) + list(getattr(self._local, "excluded_for_caller", []) or []):
            if e["id"] in seen:
                continue
            seen.add(e["id"])
            why = {
                "not-enabled-by-org": "your organisation has not enabled this connector",
                "not-selected-for-project": "not selected for this project",
                "not-in-your-access-scope": "outside the access granted to you",
            }.get(e["reason"], e["reason"])
            excluded.append({"id": e["id"], "reason": e["reason"], "explanation": why})
        return {
            "gateway": f"spar-gateway {__version__}",
            "registry": str(self.registry_path) if self.registry_path else None,
            "spar_root": str(self.spar_root) if self.spar_root else None,
            "connectors": conns,
            "unconfigured": self.unconfigured,
            "excluded": excluded,
            "project_selection": sorted(self.selection) if self.selection is not None else None,
            "roles_available": sorted({u.role for u in self.reachable.values()}),
            "guidance": (
                "Search org systems by role before the open web. Cite every claim with the "
                "citation block returned alongside each result. If a role is unavailable, say "
                "so in the artifact instead of guessing."
            ),
        }


# --------------------------------------------------------------------------- #
# JSON-RPC loop
# --------------------------------------------------------------------------- #


# --------------------------------------------------------------------------- #
# Protocol dispatch, shared by both transports
#
# One function answers a JSON-RPC frame, so the stdio shim a developer's editor
# launches and the hosted HTTP service behave identically. `subject` is the
# authenticated developer on the HTTP path and None on the local one.
# --------------------------------------------------------------------------- #

INSTRUCTIONS = (
    "SPAR org gateway. Use org_connectors to see what internal systems are "
    "reachable, then org_search / org_fetch by role (docs, issues, scm, ci, "
    "db, catalog, security) BEFORE consulting the open web. Every result "
    "carries a citation -- cite it. Never assert what internal docs say "
    "without a citation."
)


def dispatch(gw: "Gateway", msg: dict, subject: dict | None = None) -> dict | None:
    """Answer one frame. Returns the reply, or None for a notification."""
    method = msg.get("method")
    msg_id = msg.get("id")
    params = msg.get("params") or {}

    def ok(result):
        return {"jsonrpc": "2.0", "id": msg_id, "result": result}

    if method == "initialize":
        return ok(
            {
                "protocolVersion": PROTOCOL_VERSION,
                "capabilities": {"tools": {}},
                "serverInfo": {"name": "spar-gateway", "version": __version__},
                "instructions": INSTRUCTIONS,
            }
        )
    if method in ("notifications/initialized", "notifications/cancelled"):
        return None
    if method == "ping":
        return ok({})
    if method == "tools/list":
        return ok({"tools": gw.tool_list()})
    if method == "tools/call":
        name = params.get("name", "")
        args = params.get("arguments") or {}
        try:
            text = gw.handle_tool(name, args, subject=subject)
            return ok({"content": [{"type": "text", "text": text}]})
        except Exception as exc:  # never die on a bad call
            return ok(
                {
                    "content": [
                        {
                            "type": "text",
                            "text": json.dumps({"error": f"{type(exc).__name__}: {exc}"}),
                        }
                    ],
                    "isError": True,
                }
            )
    if method in ("resources/list", "prompts/list"):
        key = "resources" if method.startswith("resources") else "prompts"
        return ok({key: []})
    if msg_id is not None:
        return {
            "jsonrpc": "2.0",
            "id": msg_id,
            "error": {"code": -32601, "message": f"method not found: {method}"},
        }
    return None


def serve_gateway() -> int:
    """Local stdio mode.

    If this host is configured to use a hosted gateway, every frame is forwarded
    there instead: the developer's machine holds no registry, spawns no upstream
    and has no credential. Otherwise it runs the gateway itself, which is the
    solo path.
    """
    from .remote import remote_config, serve_proxy

    cfg = remote_config()
    if cfg:
        return serve_proxy(cfg)

    gw = Gateway()
    gw.begin(None, find_spar_root())
    log(
        f"ready: {len(gw.reachable)} connector(s), registry={gw.registry_path}, "
        f"root={gw.spar_root}"
    )
    for raw in sys.stdin:
        raw = raw.strip()
        if not raw:
            continue
        try:
            msg = json.loads(raw)
        except json.JSONDecodeError:
            continue
        gw.begin(None, find_spar_root())
        reply = dispatch(gw, msg)
        if reply is not None:
            sys.stdout.write(json.dumps(reply) + "\n")
            sys.stdout.flush()
    return 0


# --------------------------------------------------------------------------- #
# Hosted mode
# --------------------------------------------------------------------------- #

MAX_FRAME = 1 << 20


def serve_gateway_http(port: int, bind: str, verbose: bool) -> int:
    """Run the gateway as a service every developer's editor connects to.

    The credentials, the upstream processes, the cache and the log all live here
    on this one host. A developer presents only their own access token, which an
    administrator issued once; they never see or hold a system credential.
    """
    import http.server
    import signal
    import socketserver

    from . import access
    from .cli import bad, dim, info, ok as ok_line, warn

    gw = Gateway()
    ok_line(f"gateway ready: {len(gw.upstreams)} connector(s) enabled")
    info(f"registry {gw.registry_path or 'none found'}")
    if gw.unconfigured:
        warn(f"{len(gw.unconfigured)} connector(s) missing connection details")
    if not access.enrollment_state()["set"] and not access.anyone_enrolled():
        warn("nobody can connect yet -- open enrollment in AEGIS Control, then run")
        warn(f"  spar login http://{bind}:{port} --enroll <token>   on each developer machine")
    if bind not in ("127.0.0.1", "localhost", "::1"):
        warn(f"binding {bind} -- reachable off this host. Terminate TLS in front of it.")

    class H(http.server.BaseHTTPRequestHandler):
        server_version = f"spar-gateway/{__version__}"
        protocol_version = "HTTP/1.1"

        def log_message(self, fmt, *a):
            if verbose:
                sys.stderr.write(f"  {dim(fmt % a)}\n")

        def _send(self, code: int, body: bytes, ctype: str = "application/json"):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def _json(self, obj, code: int = 200):
            self._send(code, json.dumps(obj).encode("utf-8"))

        def _subject(self):
            """Who is calling. Returns (subject, refusal-reason).

            An identity header is only believed when it arrives from a peer named
            as a trusted proxy. Anywhere else it is forgeable, so it is ignored
            entirely and the machine key decides -- that ordering is the whole
            security property of terminating OIDC at a proxy.
            """
            cfg = access.get_config()
            peers = cfg["proxy_peers"]
            if peers:
                peer = self.client_address[0] if self.client_address else ""
                if peer in peers or "*" in peers:
                    email = (self.headers.get(cfg["proxy_user_header"]) or "").strip()
                    if email:
                        raw = (self.headers.get(cfg["proxy_groups_header"]) or "")
                        groups = [
                            g.strip()
                            for g in raw.replace(";", ",").replace("|", ",").split(",")
                            if g.strip()
                        ]
                        who = access.identify_person(email, groups)
                        if who:
                            return who, ""
                        # The proxy authenticated them and an administrator has
                        # revoked them here. Falling through to a machine key
                        # would make that revocation bypassable.
                        return None, f"{email} has been revoked on this gateway"
            auth = self.headers.get("Authorization", "")
            if not auth.lower().startswith("bearer "):
                return None, "no access token was presented"
            token = auth[7:].strip()
            who = access.authenticate(token)
            if who:
                return who, ""
            state = access.token_state(token)
            return None, {
                "expired": "this machine's access token has expired -- run spar login again",
                "revoked": "this machine's access token was revoked -- ask an administrator",
                "unknown": "that access token is not known to this gateway",
            }.get(state, "access token refused")

        def _project_root(self):
            """The caller's project, so their own selection and policy apply."""
            raw = (self.headers.get("X-Aegis-Project") or "").strip()
            if not raw:
                return gw.host_root
            try:
                root = Path(raw).expanduser()
            except (OSError, ValueError):
                return gw.host_root
            from spar.cli import workspace_in
            return workspace_in(root)

        def do_GET(self):  # noqa: N802
            if self.path == "/health":
                # Deliberately says nothing about who may connect or what is
                # configured -- it exists for a load balancer, not a scanner.
                return self._json({"ok": True, "service": "spar-gateway"})
            if self.path == "/enroll":
                return self._json({"error": "POST an enrollment token here"}, 405)
            return self._json({"error": "not found"}, 404)

        def do_POST(self):  # noqa: N802
            length = int(self.headers.get("Content-Length") or 0)
            if length > MAX_FRAME:
                return self._json({"error": "frame too large"}, 413)
            raw = self.rfile.read(length) if length else b"{}"

            if self.path == "/enroll":
                try:
                    body = json.loads(raw.decode("utf-8") or "{}")
                except ValueError:
                    return self._json({"error": "body must be JSON"}, 400)
                res = access.enroll(str(body.get("enroll") or ""), str(body.get("label") or ""))
                if "error" in res:
                    return self._json(res, 403)
                return self._json(res)

            if self.path not in ("/mcp", "/"):
                return self._json({"error": "not found"}, 404)

            subject, why = self._subject()
            if not subject:
                self.send_response(401)
                self.send_header("WWW-Authenticate", 'Bearer realm="spar-gateway"')
                hint = " Run: spar login <url> --enroll <token>" if why.startswith("no access") else ""
                body = json.dumps({"error": why + hint}).encode("utf-8")
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                try:
                    self.wfile.write(body)
                except (BrokenPipeError, ConnectionResetError):
                    pass
                return

            try:
                msg = json.loads(raw.decode("utf-8") or "{}")
            except ValueError:
                return self._json(
                    {"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "parse error"}}
                )
            gw.begin(subject, self._project_root())
            reply = dispatch(gw, msg, subject=subject)
            if reply is None:
                return self._send(204, b"", "application/json")
            return self._json(reply)

    class Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
        daemon_threads = True
        allow_reuse_address = True

    try:
        httpd = Server((bind, port), H)
    except OSError as exc:
        bad(f"cannot bind {bind}:{port}: {exc}")
        return 1

    def stop(_signum, _frame):
        threading.Thread(target=httpd.shutdown, daemon=True).start()

    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGTERM, stop)
    ok_line(f"listening on http://{bind}:{port}/mcp")
    sys.stdout.flush()
    try:
        httpd.serve_forever()
    finally:
        httpd.server_close()
        ok_line("gateway stopped")
    return 0


if __name__ == "__main__":
    sys.exit(serve_gateway())
