"""Deterministic checks on SPAR artifacts and on the project they describe.

This is the harness's feedback layer. Nothing here asks a model anything: it
reads files, runs the commands `spar/checks.yaml` names, and reports findings
with stable codes so a defect can be routed to the agent that owns the file and
fixed, rather than described in prose and hoped about.

Three scopes:

- ``artifacts``     spec.md, plan.md, tasks.md — structure, placeholders,
                    parallel-safety, traceability.
- ``project``       the commands in `spar/checks.yaml` (tests, lint, typecheck,
                    pack-supplied scans), run for real.
- ``verification``  verification.md — a PASS verdict that its own rows refute.

Every run is cached at `spar/specs/<feature>/.checks.json` with the artifact
version it was computed against, so `spar next` can tell a fresh result from a
stale one without re-running anything.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import time
from pathlib import Path

from .cli import now_iso, parse_simple_yaml

SCHEMA = "spar.check/v1"
CACHE_SCHEMA = "spar.checks-cache/v1"

SCOPES = ("artifacts", "project", "verification")

# The files whose content a scope's result depends on. A cached result is fresh
# while the version of these files is unchanged.
SCOPE_FILES = {
    "artifacts": ["spec.md", "plan.md", "tasks.md"],
    "project": ["tasks.md", "build-log.md"],
    "verification": ["verification.md"],
}

# The files a human gate approves. `spar gate` records this version on the
# ledger entry and reports the gate stale when it no longer matches.
GATE_FILES = {
    "approve-spec": ["spec.md"],
    "approve-plan": ["plan.md", "tasks.md"],
    "checkpoint": ["build-log.md"],
    # The person's OK to push and deploy what was verified.
    "approve-release": ["verification.md"],
}

# The analyzer reads plan and tasks; its verdict is about that pair.
ANALYZE_FILES = ["plan.md", "tasks.md"]

OWNER = {
    "spec.md": "specifier",
    "plan.md": "architect",
    "tasks.md": "task-planner",
    "verification.md": "verifier",
    "roadmap.md": "roadmapper",
    "project": "task-executor",
}

# Sections the templates make mandatory. Matched as `## <name>` prefixes,
# case-insensitively, so a heading with a suffix still counts.
SPEC_SECTIONS = (
    "Problem",
    "Outcome",
    "Grounding",
    "Scope",
    "User stories",
    "Non-Functional Requirements",
    "Open questions",
)
PLAN_SECTIONS = (
    "Approach",
    "Platform",
    "Architecture",
    "Presentation",
    "Tenets gate compliance",
    "Standards coverage",
)
SECURITY_NFRS = tuple(f"NFR-S{i}" for i in range(1, 9))

# What may stand behind a platform choice. A language, a cloud and an
# orchestrator are not design details that fall out of the architecture — they
# are commitments someone has to staff, pay for and operate for years, so the
# only honest sources are governance that a human already ratified, a decision
# recorded against this feature, or an open question. Anything else is the
# architect deciding on the organisation's behalf and calling it a design.
PLATFORM_SOURCE_RE = re.compile(r"T-\d+|S-\d+|decision\s*#\s*\d+|NEEDS CLARIFICATION\[", re.I)
DECISION_SEQ_RE = re.compile(r"decision\s*#\s*\d+", re.I)

DEFAULT_TIMEOUT = 600
TAIL_LINES = 60


# --------------------------------------------------------------------------- #
# Versions
# --------------------------------------------------------------------------- #


CHECKBOX_STATE_RE = re.compile(r"^(\s*[-*]\s*)\[(?: |x|X)\]")


def normalise_tasks(text: str) -> str:
    """tasks.md reduced to what the design approval is actually about.

    The design gate approves *scope*: which phases, which tasks, which files each
    touches and what depends on what. The build then works in this file — it
    checks tasks off, fills the traceability Code column, corrects a definition
    of done it found to be wrong, adds a note. Those edits are progress, not a
    change of design, and reopening the gate for them sent every low-risk build
    back to a human for a sentence of wording. So the version an approval or an
    analyzer verdict is bound to keeps only: `## ` section and phase headings,
    `### T###` task headings (with their `[P]`/`[US]` tags), `**Files.**` and
    `**Depends on.**` lines. Everything else is reviewed at the checkpoint.
    """
    # Fixes the end-to-end test sent back ("## Delivery fixes") are work found while
    # proving the design, not a change to it: they never reopen the design gate.
    cut = text.find("\n## Delivery fixes")
    if cut >= 0:
        text = text[:cut]
    keep = []
    for raw in text.splitlines():
        line = raw.strip()
        if line.startswith("## ") or line.startswith("### "):
            keep.append(line)
        elif line.startswith("**Files.**") or line.startswith("**Depends on.**") or line.startswith("- **Files.**") or line.startswith("- **Depends on.**"):
            keep.append(line.lstrip("- "))
    return "\n".join(keep) + "\n"


NORMALISE = {"tasks.md": normalise_tasks}


def artifact_version(feature_dir: Path, names: list[str], raw: bool = False) -> str:
    """One definition, shared with `spar gate` and `spar next`.

    sha256 over "<name>:<sha256 of bytes>\\n" per file in the order given; a
    missing file contributes "<name>:-\\n". Pinned by a test vector in
    tests/harness-check.sh so any other implementation can prove it agrees.

    Unless *raw* is set, tasks.md is hashed through `normalise_tasks` so the
    build's own bookkeeping does not reopen the design gate; the project scope
    passes raw=True because there the bookkeeping is exactly what changed.
    """
    h = hashlib.sha256()
    for name in names:
        p = feature_dir / name
        if p.is_file():
            data = p.read_bytes()
            norm = None if raw else NORMALISE.get(name)
            if norm is not None:
                data = norm(data.decode("utf-8", "replace")).encode("utf-8")
            digest = hashlib.sha256(data).hexdigest()
        else:
            digest = "-"
        h.update(f"{name}:{digest}\n".encode("utf-8"))
    return h.hexdigest()


# --------------------------------------------------------------------------- #
# Cache
# --------------------------------------------------------------------------- #


def cache_path(spar_root: Path, feature: str | None) -> Path:
    if feature:
        return spar_root / "specs" / feature / ".checks.json"
    return spar_root / ".checks.json"


def read_cache(spar_root: Path, feature: str | None) -> dict:
    p = cache_path(spar_root, feature)
    if not p.is_file():
        return {"schema": CACHE_SCHEMA, "scopes": {}, "analyze_attempted_for": None}
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {"schema": CACHE_SCHEMA, "scopes": {}, "analyze_attempted_for": None}
    data.setdefault("schema", CACHE_SCHEMA)
    data.setdefault("scopes", {})
    data.setdefault("analyze_attempted_for", None)
    return data


def write_cache(spar_root: Path, feature: str | None, cache: dict) -> None:
    p = cache_path(spar_root, feature)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(cache, indent=2) + "\n", encoding="utf-8")
    except OSError:
        pass


def note_analyze_attempt(spar_root: Path, feature: str) -> str:
    """Record that the analyzer was run against the current plan+tasks.

    `spar next` uses this to tell "analyze has not run" from "analyze ran and
    wrote no verdict", so a silent analyzer is reported rather than re-run for
    ever.
    """
    version = artifact_version(spar_root / "specs" / feature, ANALYZE_FILES)
    cache = read_cache(spar_root, feature)
    cache["analyze_attempted_for"] = version
    cache["analyze_attempted_at"] = now_iso()
    write_cache(spar_root, feature, cache)
    return version


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #

COMMENT_RE = re.compile(r"<!--.*?-->", re.S)
PLACEHOLDER_RE = re.compile(r"\{\{.*?\}\}")
HEADING_RE = re.compile(r"^(#{2,3})\s+(.*)$")
TASK_HEADING_RE = re.compile(r"^###\s+(T\d{3})\b(.*)$")
CHECKBOX_RE = re.compile(r"^\s*[-*]\s*\[( |x|X)\]\s*(T\d{3})\b")
FIELD_RE = re.compile(r"^\s*-\s*\*\*([A-Za-z ]+)\.\*\*\s*(.*)$")
BACKTICK_RE = re.compile(r"`([^`]+)`")
ROW_RE = re.compile(r"^\s*\|(.+)\|\s*$")
STORY_RE = re.compile(r"^###\s+US(\d+)\b(.*)$")


def _finding(code: str, severity: str, line: int | None, message: str, owner: str) -> dict:
    return {"code": code, "severity": severity, "line": line, "message": message, "owner": owner}


def _strip_comments(text: str) -> str:
    """Blank out HTML guidance comments while keeping line numbers stable."""

    def blank(m: re.Match) -> str:
        return "\n" * m.group(0).count("\n")

    return COMMENT_RE.sub(blank, text)


def _sections(lines: list[str]) -> dict[str, int]:
    """`## heading` -> line number (1-based), lower-cased."""
    out = {}
    for i, line in enumerate(lines, start=1):
        if line.startswith("## "):
            out[line[3:].strip().lower()] = i
    return out


def _has_section(sections: dict[str, int], name: str) -> bool:
    low = name.lower()
    return any(k.startswith(low) for k in sections)


def _placeholders(lines: list[str], owner: str, prefix: str) -> list[dict]:
    out = []
    for i, line in enumerate(lines, start=1):
        if PLACEHOLDER_RE.search(line):
            out.append(
                _finding(
                    f"{prefix}/template-placeholder",
                    "error",
                    i,
                    "template placeholder still present: " + line.strip()[:80],
                    owner,
                )
            )
    return out


def _cells(line: str) -> list[str]:
    m = ROW_RE.match(line)
    if not m:
        return []
    return [c.strip().strip("`").strip() for c in m.group(1).split("|")]


def _is_separator(cells: list[str]) -> bool:
    return bool(cells) and all(set(c) <= set("-: ") and "-" in c for c in cells)


def _table_rows(lines: list[str], start: int) -> tuple[list[list[str]], int]:
    """Data rows of the first table after line index *start*; also the count of
    rows that were still template placeholders."""
    rows, unfilled, header_seen, started = [], 0, False, False
    for line in lines[start:]:
        cells = _cells(line)
        if not cells:
            if started:
                break
            if line.startswith("## "):
                break
            continue
        started = True
        if _is_separator(cells):
            header_seen = True
            continue
        if not header_seen:
            continue
        if any("{{" in c for c in cells):
            unfilled += 1
            continue
        if all(not c for c in cells):
            continue
        rows.append(cells)
    return rows, unfilled


# --------------------------------------------------------------------------- #
# Artifact lint
# --------------------------------------------------------------------------- #


def lint_spec(text: str) -> list[dict]:
    owner = OWNER["spec.md"]
    text = _strip_comments(text)
    lines = text.splitlines()
    findings = _placeholders(lines, owner, "spec")
    sections = _sections(lines)
    for name in SPEC_SECTIONS:
        if not _has_section(sections, name):
            findings.append(
                _finding("spec/missing-section", "error", None, f"missing section `## {name}`", owner)
            )
    for nfr in SECURITY_NFRS:
        if nfr not in text:
            findings.append(
                _finding("spec/missing-security-nfr", "error", None, f"{nfr} is not addressed", owner)
            )
    for i, line in enumerate(lines, start=1):
        if "NEEDS CLARIFICATION[" in line:
            findings.append(
                _finding(
                    "spec/unresolved-clarification", "warning", i, line.strip()[:120], owner
                )
            )
    # Stories, as the document actually heads them. Matching `### USn` and
    # nothing else meant a spec that headed its stories `### P1 · Complete a
    # booking payment` had, as far as this check could tell, no stories at all:
    # every rule below was skipped and the file passed clean. A check that
    # cannot find the thing it governs reports success, which is the worst
    # answer it has available.
    story_start = next((v for k, v in sections.items() if k.startswith("user stor")), None)
    story_end = len(lines) + 1
    if story_start is not None:
        for i in range(story_start, len(lines)):
            if lines[i].startswith("## "):
                story_end = i + 1
                break
    heads = (
        [i for i in range(story_start, story_end - 1) if lines[i].startswith("### ")]
        if story_start is not None
        else []
    )
    for idx, i in enumerate(heads):
        end = heads[idx + 1] if idx + 1 < len(heads) else story_end - 1
        head = lines[i]
        body = "\n".join(lines[i + 1 : end])
        m = STORY_RE.match(head)
        label = f"US{m.group(1)}" if m else head[4:].strip()[:60]
        if not m:
            findings.append(
                _finding(
                    "spec/story-unnumbered",
                    "error",
                    i + 1,
                    f"story `{label}` has no `US<n>` id — tasks tag themselves `[US1]`, "
                    "and the traceability matrix, the tests and every downstream tool "
                    "cite that id; a story without one cannot be pointed at",
                    owner,
                )
            )
        low = body.lower()
        if "given" not in low or "then" not in low:
            findings.append(
                _finding(
                    "spec/story-missing-acceptance",
                    "error",
                    i + 1,
                    f"{label} has no Given/When/Then acceptance criteria",
                    owner,
                )
            )
        if "**satisfies" not in low:
            findings.append(
                _finding(
                    "spec/story-missing-satisfies",
                    "error",
                    i + 1,
                    f"{label} does not say which PRD requirements it answers — "
                    "`**Satisfies.** FR-1, FR-3`, or `none` when the story is new "
                    "here. This line is the PRD-to-spec link; without it a "
                    "requirement can be dropped on the way in and nothing notices",
                    owner,
                )
            )
        # `— priority P1` is the template's spelling; `### P1 · Title` is what
        # gets written. Both state the priority, and a warning that fires on a
        # heading which plainly carries one teaches people to skim past the
        # warnings that matter.
        if not re.search(r"\bP[123]\b", m.group(2) if m else head):
            findings.append(
                _finding(
                    "spec/story-missing-priority",
                    "warning",
                    i + 1,
                    f"{label} has no priority (P1/P2/P3)",
                    owner,
                )
            )
    m = re.search(r"risk[_ -]?tier\**\s*[:=]\**\s*\**\s*([A-Za-z-]+)", text, re.I)
    if not m or m.group(1).lower() not in ("low", "limited", "high"):
        findings.append(
            _finding("spec/missing-risk-tier", "warning", None, "risk_tier is not low|limited|high", owner)
        )
    return findings


def lint_plan(text: str) -> list[dict]:
    owner = OWNER["plan.md"]
    text = _strip_comments(text)
    lines = text.splitlines()
    findings = _placeholders(lines, owner, "plan")
    sections = _sections(lines)
    for name in PLAN_SECTIONS:
        if not _has_section(sections, name):
            findings.append(
                _finding("plan/missing-section", "error", None, f"missing section `## {name}`", owner)
            )
    findings += _lint_platform(lines, sections, owner)
    findings += _lint_presentation(lines, owner)
    return findings


# Rows of the MVP table, once the header and the separator are out of the way.
MVP_ID_RE = re.compile(r"^M(\d+)$", re.I)

# Words that mean a layer of the system rather than a thing a person can do.
# A Delivers cell built out of these has described a phase and called it a
# release, which is the one failure this artifact exists to prevent — and the
# one that is easiest to wave through, because a plausible-sounding phase reads
# like progress right up until the project is cancelled and nobody can use
# anything. Deliberately a small, boring list: it catches the common shape
# without pretending to understand the sentence.
PHASE_WORDS = re.compile(
    r"\b(set ?up|scaffold|infrastructure|foundation|foundations|groundwork|boilerplate|"
    r"schema|database layer|data layer|backend only|api only|ui only|frontend only|"
    r"refactor|migrate the|plumbing|wiring|skeleton)\b",
    re.I,
)


def lint_roadmap(text: str) -> list[dict]:
    """The MVP sequence: is every row something a person could actually use?

    This is a shape check, not a judgement. It cannot tell whether "an operator
    can export a warehouse's SKUs" is worth building — nobody can, from here.
    What it can tell is whether someone wrote a sentence about a person at all,
    whether the rows depend backwards, and whether the ids are a sequence. Those
    are the failures that survive review, because a roadmap of phases looks
    exactly like a roadmap of releases until you ask who uses row one.
    """
    owner = OWNER["roadmap.md"]
    text = _strip_comments(text)
    lines = text.splitlines()
    findings = _placeholders(lines, owner, "roadmap")
    sections = _sections(lines)

    at = next((v for k, v in sections.items() if k.startswith("mvps")), None)
    if at is None:
        return findings + [
            _finding("roadmap/missing-section", "error", None, "missing section `## MVPs`", owner)
        ]

    rows, _unfilled = _table_rows(lines, at)
    if not rows:
        return findings + [
            _finding(
                "roadmap/empty",
                "error",
                at,
                "the MVP table is empty — a roadmap with no rows is a decision not to have one",
                owner,
            )
        ]

    seen: list[str] = []
    for cells in rows:
        if len(cells) < 4:
            continue
        mvp_id, name, delivers, depends = cells[0], cells[1], cells[2], cells[3]
        m = MVP_ID_RE.match(mvp_id)
        if not m:
            findings.append(
                _finding("roadmap/bad-id", "error", at, f"`{mvp_id}` is not an MVP id like `M1`", owner)
            )
            continue
        seen.append(mvp_id.upper())

        # The cancellation test, as close to it as a machine can honestly get:
        # a sentence long enough to name somebody and something they can do.
        if len(delivers.split()) < 4:
            findings.append(
                _finding(
                    "roadmap/no-deliverable",
                    "error",
                    at,
                    f"{mvp_id} does not say what anyone can do with it — `{delivers}` is a label, "
                    f"not a delivery",
                    owner,
                )
            )
        elif PHASE_WORDS.search(delivers) and not re.search(r"\b(can|able to)\b", delivers, re.I):
            findings.append(
                _finding(
                    "roadmap/phase-not-release",
                    "error",
                    at,
                    f"{mvp_id} delivers `{delivers}` — that is a phase of the work, not a version "
                    f"someone could use. If this shipped alone, who is better off?",
                    owner,
                )
            )
        if not name:
            findings.append(_finding("roadmap/unnamed", "warning", at, f"{mvp_id} has no name", owner))

        # Depending forwards is not a note to make, it is an order to fix: the
        # table is read top to bottom by everyone downstream, including a human
        # choosing what to start.
        for dep in re.findall(r"M\d+", depends, re.I):
            if dep.upper() not in seen[:-1]:
                findings.append(
                    _finding(
                        "roadmap/forward-dependency",
                        "error",
                        at,
                        f"{mvp_id} depends on {dep.upper()}, which comes later — reorder the table "
                        f"rather than noting the exception",
                        owner,
                    )
                )

    if len(set(seen)) != len(seen):
        findings.append(
            _finding("roadmap/duplicate-id", "error", at, "two MVPs share an id", owner)
        )
    return findings


def _lint_platform(lines: list[str], sections: dict[str, int], owner: str) -> list[dict]:
    """Every platform choice names where it came from, or it is not a choice.

    This is deliberately structural rather than clever: it does not know that
    Kubernetes is an orchestrator or that Python is a language, and it must not
    try, because the day it holds an opinion about that is the day it is wrong
    about the next one. It asks the one question a machine can answer honestly —
    did a human put this here, or did the architect? A cited org document is
    evidence for a recommendation and is not accepted on its own; the house
    already using something is a good reason to propose it and no reason at all
    to have skipped asking.
    """
    at = next((v for k, v in sections.items() if k.startswith("platform")), None)
    if at is None:
        return []  # already reported as a missing section
    rows, _unfilled = _table_rows(lines, at)
    if not rows:
        return [
            _finding("plan/empty-platform", "error", at, "the platform table has no filled rows", owner)
        ]
    out = []
    for cells in rows:
        choice = cells[0] if cells else ""
        selection = cells[1] if len(cells) > 1 else ""
        source = cells[2] if len(cells) > 2 else ""
        if not PLATFORM_SOURCE_RE.search(source):
            out.append(
                _finding(
                    "plan/platform-unsourced",
                    "error",
                    at,
                    f"platform choice `{choice}` cites no tenet, standard, recorded decision or open "
                    f"question — it was decided rather than asked",
                    owner,
                )
            )
        elif "defer" in selection.lower() and not DECISION_SEQ_RE.search(source):
            # Otherwise "deferred" becomes the way through the check rather than
            # a decision: it reads as though someone chose to wait when in fact
            # nobody was asked, and it is the one answer with nothing to show
            # for it later. `spar gate defer` is what puts a name and a date on
            # it, and this is what makes that the only way to type the word.
            out.append(
                _finding(
                    "plan/platform-defer-unrecorded",
                    "error",
                    at,
                    f"platform choice `{choice}` says deferred but cites no decision — "
                    f"record it with `spar gate defer <feature> <row> --note ...`",
                    owner,
                )
            )
    return out


# The Presentation section, and the single line that decides whether the rest of
# it is required. "No user interface" is a real and common answer; what is not an
# answer is silence.
APPLIES_RE = re.compile(r"^\*\*Applies:?\*\*\s*(.*)$", re.I)
PRESENTATION_FIELDS = (
    ("a token home", re.compile(r"^\*\*Token home\.?\*\*\s*(.*)$", re.I)),
    ("a styling approach", re.compile(r"^\*\*Styling approach\.?\*\*\s*(.*)$", re.I)),
)


def _lint_presentation(lines: list[str], owner: str) -> list[dict]:
    """Does the plan say what this feature looks like, or only what it does?

    Every other section of a plan survives being vague: the tests still pass and
    the contracts still hold. This one does not. Left blank it does not fall back
    to a house style — it falls back to whatever stylesheet the framework's
    scaffold happened to ship, aimed at class names nothing renders, and the
    build goes green over a page of bare form controls. So the bar here is only
    that somebody answered: which file the tokens live in, and what does the
    styling. Taste is not checkable and is not being checked.
    """
    body, start = _section_lines(lines, "Presentation")
    if not body:
        # `plan/missing-section` has already said this, and saying it twice
        # tells a reader there are two problems.
        return []
    applies, applies_at = None, start
    for offset, line in enumerate(body):
        m = APPLIES_RE.match(line.strip())
        if m:
            applies, applies_at = m.group(1).strip(), start + offset
            break
    if applies is None:
        return [
            _finding(
                "plan/presentation-unmarked",
                "error",
                start,
                "Presentation names no `**Applies:**` line — answer `yes`, or "
                "`n/a — no user interface` when nobody ever looks at this feature",
                owner,
            )
        ]
    if applies.lower().lstrip("*`~ ").startswith("n/a"):
        return []
    findings = []
    for label, pattern in PRESENTATION_FIELDS:
        if not any(
            (m := pattern.match(line.strip())) and m.group(1).strip(" .{}`")
            for line in body
        ):
            findings.append(
                _finding(
                    "plan/presentation-empty",
                    "error",
                    applies_at,
                    f"Presentation applies but names {label.replace('a ', 'no ', 1)} — "
                    "the executor styles from this section, so an unanswered row "
                    "becomes the scaffold stylesheet",
                    owner,
                )
            )
    return findings


def parse_tasks(text: str) -> list[dict]:
    """Tasks as the template defines them: heading, tags, fields, phase."""
    tasks: list[dict] = []
    phase = "Phase 0"
    current: dict | None = None
    for i, line in enumerate(text.splitlines(), start=1):
        if line.startswith("## "):
            phase = line[3:].strip()
            current = None
            continue
        m = TASK_HEADING_RE.match(line)
        if m:
            rest = m.group(2)
            story = re.search(r"\[US(\d+)\]", rest)
            current = {
                "id": m.group(1),
                "line": i,
                "parallel": "[P]" in rest,
                "story": story.group(1) if story else None,
                "phase": phase,
                "files": [],
                "acceptance": None,
                "depends": [],
                "fields": set(),
            }
            tasks.append(current)
            continue
        if current is None:
            continue
        f = FIELD_RE.match(line)
        if not f:
            continue
        key, val = f.group(1).strip().lower(), f.group(2).strip()
        current["fields"].add(key)
        if key == "files":
            files = [x.strip() for x in BACKTICK_RE.findall(val)]
            if not files:
                files = [x.strip() for x in val.split(",") if x.strip()]
            current["files"] = [x for x in files if x and not PLACEHOLDER_RE.fullmatch(x)]
        elif key == "acceptance":
            current["acceptance"] = val
        elif key == "depends on":
            current["depends"] = re.findall(r"T\d{3}", val)
    return tasks


def lint_tasks(text: str) -> list[dict]:
    owner = OWNER["tasks.md"]
    text = _strip_comments(text)
    lines = text.splitlines()
    findings = _placeholders(lines, owner, "tasks")
    tasks = parse_tasks(text)
    ids = {t["id"] for t in tasks}

    for t in tasks:
        if not t["files"]:
            findings.append(
                _finding("tasks/missing-files", "error", t["line"], f"{t['id']} names no **Files.**", owner)
            )
        if not t["acceptance"]:
            findings.append(
                _finding(
                    "tasks/missing-acceptance", "error", t["line"], f"{t['id']} has no **Acceptance.**", owner
                )
            )
        if not t["story"]:
            findings.append(
                _finding("tasks/missing-story", "warning", t["line"], f"{t['id']} has no [USn] tag", owner)
            )
        for dep in t["depends"]:
            if dep == t["id"]:
                findings.append(
                    _finding("tasks/self-dependency", "error", t["line"], f"{t['id']} depends on itself", owner)
                )
            elif dep not in ids:
                findings.append(
                    _finding(
                        "tasks/unknown-dependency",
                        "error",
                        t["line"],
                        f"{t['id']} depends on {dep}, which does not exist",
                        owner,
                    )
                )

    checked = set()
    for i, line in enumerate(lines, start=1):
        m = CHECKBOX_RE.match(line)
        if not m:
            continue
        checked.add(m.group(2))
        if m.group(2) not in ids:
            findings.append(
                _finding(
                    "tasks/orphan-checkbox", "error", i, f"checkbox {m.group(2)} has no task heading", owner
                )
            )
    for t in tasks:
        if t["id"] not in checked:
            findings.append(
                _finding("tasks/missing-checkbox", "warning", t["line"], f"{t['id']} has no `- [ ] {t['id']}`", owner)
            )

    # Parallel safety is a claim the file makes about itself, so it can be checked.
    by_phase: dict[str, list[dict]] = {}
    for t in tasks:
        if t["parallel"]:
            by_phase.setdefault(t["phase"], []).append(t)
    for phase, group in by_phase.items():
        seen: dict[str, str] = {}
        for t in group:
            for f in t["files"]:
                if f in seen and seen[f] != t["id"]:
                    findings.append(
                        _finding(
                            "tasks/parallel-file-conflict",
                            "error",
                            t["line"],
                            f"{seen[f]} and {t['id']} are both [P] in `{phase}` and both touch `{f}`",
                            owner,
                        )
                    )
                else:
                    seen[f] = t["id"]

    sections = _sections(lines)
    trace = next((v for k, v in sections.items() if k.startswith("traceability")), None)
    if trace is None:
        findings.append(
            _finding("tasks/missing-traceability", "error", None, "missing section `## Traceability`", owner)
        )
    else:
        rows, _unfilled = _table_rows(lines, trace)
        if not rows:
            findings.append(
                _finding(
                    "tasks/empty-traceability", "error", trace, "the traceability table has no filled rows", owner
                )
            )
    return findings


# An id as it is written at the front of a matrix cell. Cells are written to be
# read — `NFR-S1 authentication`, not `NFR-S1` — so the id has to be taken off
# the front rather than the whole cell compared.
TRACE_ID_RE = re.compile(r"^([A-Za-z]{1,6}-?[A-Za-z]?\d+(?:-[A-Za-z]{1,3}\d+)?)\b")
# Ids the spec is entitled not to define: standards rows and tenets, which live
# in `standards.md` and `tenets.md` and legitimately produce tasks of their own.
FOREIGN_ID_RE = re.compile(r"^[ST]-\d+$", re.I)
SPEC_NFR_RE = re.compile(r"\bNFR-[A-Z]{1,2}\d+\b")


def spec_item_ids(text: str) -> set[str]:
    """Every id `spec.md` defines: story ids, their acceptance criteria, and NFRs.

    This is what the traceability matrix is allowed to cite. Anything else in
    the `Spec item` column is an id the planner made up.
    """
    text = _strip_comments(text)
    out = {m.group(0).upper() for m in SPEC_NFR_RE.finditer(text)}
    out |= {m.group(0).upper() for m in re.finditer(r"\bUS\d+-AC\d+\b", text, re.I)}
    for line in text.splitlines():
        if line.startswith("### "):
            m = STORY_RE.match(line)
            if m:
                out.add(f"US{m.group(1)}")
    return out


def lint_traceability(spec_text: str, tasks_text: str) -> list[dict]:
    """The matrix against the spec it claims to trace.

    `lint_tasks` can only see that the table has rows. Whether those rows point
    at anything is the one question the matrix exists to answer, and it takes
    both documents to ask it — a matrix citing `PERF-01` where the spec never
    wrote a `PERF-01` reads as complete, and reports a requirement covered that
    nobody ever agreed to.
    """
    owner = OWNER["tasks.md"]
    findings: list[dict] = []
    lines = _strip_comments(tasks_text).splitlines()
    sections = _sections(lines)
    trace = next((v for k, v in sections.items() if k.startswith("traceability")), None)
    if trace is None:
        return findings

    header: list[str] = []
    for line in lines[trace:]:
        cells = [c.lower() for c in _cells(line)]
        if cells and any(c.startswith("spec item") for c in cells):
            header = cells
            break
        if line.startswith("## "):
            break
    if not header:
        findings.append(
            _finding(
                "tasks/traceability-no-spec-column",
                "error",
                trace,
                "the traceability table has no `Spec item` column — the columns are "
                "`PRD | Spec item | Task(s) | Code | Test`, and a table that drops one "
                "of them breaks the chain at that link",
                owner,
            )
        )
        return findings
    if not any(c.startswith("prd") for c in header):
        findings.append(
            _finding(
                "tasks/traceability-no-prd-column",
                "warning",
                trace,
                "the traceability table has no `PRD` column, so nothing here records which "
                "brief requirement each spec item came from — the link is then stated "
                "nowhere and a dropped requirement cannot be detected",
                owner,
            )
        )

    at = header.index(next(c for c in header if c.startswith("spec item")))
    defined = spec_item_ids(spec_text)
    cited: set[str] = set()
    started = False
    # Walked by hand rather than through `_table_rows` so each finding can name
    # the row it is about. A table of forty rows reported at the heading is a
    # hunt; reported at the line it is a fix.
    for n, line in enumerate(lines[trace:], start=trace + 1):
        cells = _cells(line)
        if not cells:
            if started:
                break
            if line.startswith("## "):
                break
            continue
        started = True
        if _is_separator(cells) or (at < len(cells) and cells[at].lower().startswith("spec item")):
            continue
        if at >= len(cells) or not cells[at] or "{{" in cells[at]:
            continue
        cell = cells[at]
        m = TRACE_ID_RE.match(cell)
        if not m:
            findings.append(
                _finding(
                    "tasks/traceability-unlabelled-row",
                    "error",
                    n,
                    f"traceability row `{cell[:60]}` names no spec id. A row has to start "
                    "with the id of the item it traces, or it points at a description "
                    "rather than at a requirement",
                    owner,
                )
            )
            continue
        rid = m.group(1).upper()
        if FOREIGN_ID_RE.match(rid):
            continue
        cited.add(rid)
        if rid in defined:
            continue
        if re.fullmatch(r"US\d+-AC\d+", rid) and rid.split("-")[0] in defined:
            continue
        findings.append(
            _finding(
                "tasks/traceability-unknown-item",
                "error",
                n,
                f"traceability row cites `{rid}`, which `spec.md` does not define. Either "
                "the spec is missing a requirement someone is about to build, or the id "
                "was invented here — both mean the row traces to nothing",
                owner,
            )
        )
    for rid in sorted(defined):
        if re.fullmatch(r"US\d+-AC\d+", rid):
            continue
        if rid in cited or any(c.startswith(f"{rid}-") for c in cited):
            continue
        findings.append(
            _finding(
                "tasks/traceability-missing-item",
                "error",
                trace,
                f"`{rid}` is in the spec and in no traceability row — no task builds it and "
                "no test proves it, and the build will finish reporting success without it",
                owner,
            )
        )
    return findings


# --------------------------------------------------------------------------- #
# Verification
# --------------------------------------------------------------------------- #

VERDICT_RE = re.compile(r"\*\*Verdict:?\*\*\s*[:—-]?\s*\**\s*(PASS|FAIL)", re.IGNORECASE)
RESULT_RE = re.compile(
    r"(\d+)\s+tests?\s+run,\s*(\d+)\s+passed,\s*(\d+)\s+failed,\s*(\d+)\s+skipped"
    r"(?:,\s*(\d+)\s+xfail)?",
    re.IGNORECASE,
)
COVERAGE_RE = re.compile(r"(\d+)\s*%\s*against a threshold of\s*(\d+)\s*%", re.IGNORECASE)
COMMAND_RE = re.compile(r"\*\*Command run\.?\*\*\s*`([^`]+)`", re.IGNORECASE)


def _section_lines(lines: list[str], heading: str) -> tuple[list[str], int]:
    low = heading.lower()
    for i, line in enumerate(lines):
        if line.startswith("## ") and line[3:].strip().lower().startswith(low):
            body = []
            for nxt in lines[i + 1 :]:
                if nxt.startswith("## "):
                    break
                body.append(nxt)
            return body, i + 1
    return [], 0


def _norm_result(value: str) -> str:
    v = value.strip().lower().strip("*` ")
    if v.startswith("pass") or v in {"yes", "met", "ok", "✅", "green"}:
        return "pass"
    if v.startswith("fail") or v in {"no", "not met", "❌", "red"} or "not met" in v:
        return "fail"
    return "unknown"


def parse_verification(text: str) -> dict:
    """verification.md as data: verdict, command, counts, coverage, rows.

    Kept here so the contradiction rule lives next to
    the checks that enforce it.
    """
    lines = text.splitlines()
    out: dict = {
        "verdict": "",
        "command": "",
        "tests": {},
        "coverage": {},
        "rows": {"pass": 0, "fail": 0, "unknown": 0},
        "unfilled": 0,
    }
    m = VERDICT_RE.search(text)
    if m:
        out["verdict"] = m.group(1).upper()
    m = COMMAND_RE.search(text)
    if m and "{{" not in m.group(1):
        out["command"] = m.group(1)[:200]
    m = RESULT_RE.search(text)
    if m:
        out["tests"] = {
            "run": int(m.group(1)),
            "passed": int(m.group(2)),
            "failed": int(m.group(3)),
            "skipped": int(m.group(4)),
            "xfail": int(m.group(5) or 0),
        }
    m = COVERAGE_RE.search(text)
    if m:
        cov, thr = int(m.group(1)), int(m.group(2))
        out["coverage"] = {"percent": cov, "threshold": thr, "meets": cov >= thr}
    for heading, result_col in (("traceability", -1), ("tenets", 1), ("controls", 2)):
        body, _ = _section_lines(lines, heading)
        rows, unfilled = _table_rows(body, 0)
        out["unfilled"] += unfilled
        for cells in rows:
            idx = result_col if result_col >= 0 else len(cells) - 1
            if idx < len(cells):
                out["rows"][_norm_result(cells[idx])] += 1
    r = out["rows"]
    out["contradicted"] = out["verdict"] == "PASS" and (
        r["fail"] > 0
        or r["unknown"] > 0
        or bool(out["tests"] and out["tests"]["failed"])
        or (bool(out["coverage"]) and not out["coverage"]["meets"])
    )
    return out


def lint_verification(text: str) -> list[dict]:
    owner = OWNER["verification.md"]
    v = parse_verification(_strip_comments(text))
    findings = []
    if not v["verdict"]:
        findings.append(
            _finding("verify/no-verdict", "error", None, "no PASS or FAIL verdict recorded", owner)
        )
    if not v["command"]:
        findings.append(
            _finding(
                "verify/no-command-run", "error", None, "no **Command run.** recorded — the suite was not shown to run", owner
            )
        )
    if v["unfilled"]:
        findings.append(
            _finding(
                "verify/unfilled-rows", "error", None, f"{v['unfilled']} matrix row(s) still carry template placeholders", owner
            )
        )
    if v["coverage"] and not v["coverage"]["meets"]:
        findings.append(
            _finding(
                "verify/coverage-below-threshold",
                "error",
                None,
                f"coverage {v['coverage']['percent']}% is below the {v['coverage']['threshold']}% threshold",
                owner,
            )
        )
    if v["contradicted"]:
        r = v["rows"]
        why = []
        if r["fail"]:
            why.append(f"{r['fail']} failing row(s)")
        if r["unknown"]:
            why.append(f"{r['unknown']} row(s) with no result")
        if v["tests"] and v["tests"]["failed"]:
            why.append(f"{v['tests']['failed']} failed test(s)")
        if v["coverage"] and not v["coverage"]["meets"]:
            why.append("coverage below threshold")
        findings.append(
            _finding(
                "verify/pass-contradicted",
                "error",
                None,
                "the verdict says PASS but the document disagrees: " + ", ".join(why),
                owner,
            )
        )
    if v["verdict"] == "FAIL":
        findings.append(
            _finding("verify/verdict-fail", "error", None, "verification reports FAIL", owner)
        )
    return findings


# --------------------------------------------------------------------------- #
# Running scopes
# --------------------------------------------------------------------------- #


def _check_from_findings(name: str, findings: list[dict], owner: str, missing: bool = False) -> dict:
    if missing:
        return {
            "name": name,
            "status": "skip",
            "summary": f"{name} does not exist yet",
            "output_tail": "",
            "duration_ms": 0,
            "owner": owner,
            "findings": [],
        }
    errors = [f for f in findings if f["severity"] == "error"]
    warnings = [f for f in findings if f["severity"] == "warning"]
    status = "fail" if errors else "pass"
    parts = []
    if errors:
        parts.append(f"{len(errors)} error(s)")
    if warnings:
        parts.append(f"{len(warnings)} warning(s)")
    return {
        "name": name,
        "status": status,
        "summary": ", ".join(parts) or "clean",
        "output_tail": "",
        "duration_ms": 0,
        "owner": owner,
        "findings": findings,
    }


def run_artifacts(feature_dir: Path) -> list[dict]:
    out = []
    spec = feature_dir / "spec.md"
    spec_text = spec.read_text(encoding="utf-8", errors="replace") if spec.is_file() else ""
    for name, linter in (("spec.md", lint_spec), ("plan.md", lint_plan), ("tasks.md", lint_tasks)):
        p = feature_dir / name
        if not p.is_file():
            out.append(_check_from_findings(name, [], OWNER[name], missing=True))
            continue
        text = p.read_text(encoding="utf-8", errors="replace")
        findings = linter(text)
        # The matrix is the only artifact that is about another artifact, so it
        # is the only one a single-file lint cannot actually check.
        if name == "tasks.md" and spec_text:
            findings = findings + lint_traceability(spec_text, text)
        out.append(_check_from_findings(name, findings, OWNER[name]))
    return out


def run_verification(feature_dir: Path) -> list[dict]:
    p = feature_dir / "verification.md"
    if not p.is_file():
        return [_check_from_findings("verification.md", [], OWNER["verification.md"], missing=True)]
    text = p.read_text(encoding="utf-8", errors="replace")
    return [_check_from_findings("verification.md", lint_verification(text), OWNER["verification.md"])]


def roadmap_path(spar_root: Path) -> Path:
    """Project-level, deliberately. The sequence spans features by definition —
    that is what makes it a roadmap rather than a plan — so it cannot live
    inside any one of them."""
    return spar_root / "roadmap.md"


def read_roadmap(spar_root: Path) -> list[dict]:
    """The MVP table as rows, or an empty list when there is no roadmap.

    Absence is a legitimate state and not an error: a project that decided it
    was one deliverable has no roadmap and should never be nagged for one.
    """
    p = roadmap_path(spar_root)
    if not p.is_file():
        return []
    lines = _strip_comments(p.read_text(encoding="utf-8", errors="replace")).splitlines()
    sections = _sections(lines)
    at = next((v for k, v in sections.items() if k.startswith("mvps")), None)
    if at is None:
        return []
    out = []
    for cells in _table_rows(lines, at)[0]:
        if len(cells) < 4 or not MVP_ID_RE.match(cells[0]):
            continue
        out.append(
            {
                "id": cells[0].upper(),
                "name": cells[1],
                "delivers": cells[2],
                "depends_on": [d.upper() for d in re.findall(r"M\d+", cells[3], re.I)],
                "shipped": len(cells) > 4 and "ship" in cells[4].lower(),
            }
        )
    return out


def checks_config_path(spar_root: Path) -> Path:
    return spar_root / "checks.yaml"


def load_checks_config(spar_root: Path) -> dict | None:
    p = checks_config_path(spar_root)
    if not p.is_file():
        return None
    try:
        data = parse_simple_yaml(p.read_text(encoding="utf-8")) or {}
    except (OSError, ValueError):
        return {"checks": [], "_error": f"could not parse {p}"}
    if not isinstance(data, dict):
        return {"checks": [], "_error": f"{p} is not a mapping"}
    data.setdefault("checks", [])
    return data


def _tail(text: str, n: int = TAIL_LINES) -> str:
    lines = text.splitlines()
    return "\n".join(lines[-n:])



def _skip_exit_codes(check: dict) -> list[int]:
    """`skip_exit_codes: [5]` on a check: exit codes that mean "nothing to check"."""
    raw = check.get("skip_exit_codes") or []
    if isinstance(raw, str):
        raw = [x for x in raw.replace(",", " ").split() if x]
    out = []
    for x in raw if isinstance(raw, list) else []:
        try:
            out.append(int(str(x).strip("[] ")))
        except ValueError:
            continue
    return out

# --------------------------------------------------------------------------- #
# Styling
# --------------------------------------------------------------------------- #

# Markup a person sees, and the files that could be styling it.
UI_MARKUP_EXT = {".tsx", ".jsx", ".vue", ".svelte", ".astro", ".html"}
STYLESHEET_EXT = {".css", ".scss", ".sass", ".less"}
SKIP_DIRS = {
    "node_modules", "dist", "build", "out", "coverage", "vendor", "target",
    "venv", "__pycache__", "site-packages", "bower_components",
}

# Only literal class attributes. A value containing `{` is an expression whose
# result this check cannot know, so it is not judged.
CLASS_ATTR_RE = re.compile(r"""(?:className|class)\s*=\s*(["'])([^"'{}<>]+)\1""")
CSS_CLASS_RE = re.compile(r"\.(-?[A-Za-z_][-\w]*)")

# Three ways of styling whose rules are not in this repo's stylesheets. A
# project doing any of them is not one this check can read, so it does not get
# an opinion about it: a false accusation here would block a build over nothing,
# and a check people learn to disbelieve is worse than no check.
#
# Matched narrowly on purpose. An earlier version looked for framework names as
# bare words and a project with an ordinary `app/bootstrap.ts` silently switched
# the whole check off — a guard against false positives that instead guaranteed
# false negatives, which is the worse of the two because nothing reports it.
# Packaged stylesheets are caught by the import below, where the name appears as
# a package specifier and means what it says.
UTILITY_HINT_RE = re.compile(r"@tailwind\b|@apply\b|tailwindcss|unocss|windicss", re.I)
UTILITY_CONFIGS = {
    "tailwind.config.js", "tailwind.config.ts", "tailwind.config.cjs", "tailwind.config.mjs",
    "uno.config.ts", "unocss.config.ts", "windi.config.ts",
}
PACKAGE_CSS_IMPORT_RE = re.compile(
    r"""(?:import|from|@import)\s+["']([^"'./][^"']*\.(?:css|scss|less))["']"""
)
CSS_IN_JS_RE = re.compile(
    r"styled-components|@emotion|\.module\.(?:css|scss|less)|stitches|vanilla-extract|@stylex", re.I
)

MAX_UNSTYLED_REPORTED = 12
MAX_UI_FILES = 4000


def _ui_files(root: Path) -> tuple[list[Path], list[Path], bool]:
    """Markup, stylesheets, and whether a utility framework configures itself here.

    Build output is never walked: `dist/` and `coverage/` are full of generated
    markup nobody wrote and nobody styles.
    """
    markup: list[Path] = []
    sheets: list[Path] = []
    utility = False
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".")]
        for name in filenames:
            if name in UTILITY_CONFIGS:
                utility = True
            ext = os.path.splitext(name)[1].lower()
            if ext in UI_MARKUP_EXT:
                markup.append(Path(dirpath) / name)
            elif ext in STYLESHEET_EXT:
                sheets.append(Path(dirpath) / name)
        if len(markup) + len(sheets) > MAX_UI_FILES:
            break
    return markup, sheets, utility


def _read(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


def lint_unstyled(root: Path) -> list[dict] | None:
    """Class names the interface renders that no stylesheet defines.

    A component that renders `class="result-card"` when nothing anywhere defines
    `.result-card` is not styled-in-a-way-someone-dislikes; it is unstyled, and
    the browser will draw the default. Nothing else in the pipeline notices:
    types check, tests pass, the contract holds, and the page ships as a stack
    of bare form controls. This is the one check standing between a green build
    and a product nobody would use.

    Returns None when the project has no interface to judge.
    """
    owner = OWNER["project"]
    markup, sheets, utility = _ui_files(root)
    if not markup or utility:
        return None

    texts = {p: _read(p) for p in markup}
    styles = [_read(p) for p in sheets]
    # Utility frameworks and packaged stylesheets keep their rules somewhere
    # this check cannot see. One sighting anywhere is enough to stand down.
    if any(UTILITY_HINT_RE.search(t) for t in styles):
        return None
    if any(UTILITY_HINT_RE.search(t) or PACKAGE_CSS_IMPORT_RE.search(t) for t in texts.values()):
        return None

    defined: set[str] = set()
    for text in styles:
        defined |= set(CSS_CLASS_RE.findall(text))

    findings: list[dict] = []
    seen: set[str] = set()
    extra = 0
    for path in sorted(texts):
        text = texts[path]
        if CSS_IN_JS_RE.search(text):
            continue
        try:
            shown = path.relative_to(root)
        except ValueError:
            shown = path
        for number, line in enumerate(text.splitlines(), 1):
            for _, value in CLASS_ATTR_RE.findall(line):
                for name in value.split():
                    if name in defined or name in seen:
                        continue
                    seen.add(name)
                    if len(findings) >= MAX_UNSTYLED_REPORTED:
                        extra += 1
                        continue
                    findings.append(
                        _finding(
                            "project/unstyled-markup",
                            "error",
                            None,
                            f"`{shown}:{number}` renders `{name}` and no stylesheet defines it",
                            owner,
                        )
                    )
    if extra:
        findings.append(
            _finding(
                "project/unstyled-markup",
                "error",
                None,
                f"and {extra} more class name(s) with no rule behind them — the interface "
                "is unstyled, not differently styled",
                owner,
            )
        )
    return findings


def run_styling(root: Path) -> list[dict]:
    findings = lint_unstyled(root)
    if findings is None:
        return []
    return [_check_from_findings("styling", findings, OWNER["project"])]


def run_project(spar_root: Path, feature_dir: Path | None = None) -> list[dict]:
    cfg = load_checks_config(spar_root)
    owner = OWNER["project"]
    spec_text = ""
    if feature_dir and (feature_dir / "spec.md").is_file():
        spec_text = (feature_dir / "spec.md").read_text(encoding="utf-8", errors="replace")
    if cfg is None:
        return [
            {
                "name": "checks.yaml",
                "status": "skip",
                "summary": "no spar/checks.yaml — run `spar checks init` to declare tests, lint and typecheck",
                "output_tail": "",
                "duration_ms": 0,
                "owner": owner,
                "findings": [],
            }
        ]
    if cfg.get("_error"):
        return [
            {
                "name": "checks.yaml",
                "status": "fail",
                "outcome": "instrument_error",
                "summary": cfg["_error"],
                "output_tail": "",
                "duration_ms": 0,
                "owner": owner,
                "findings": [_finding("project/bad-config", "error", None, cfg["_error"], owner)],
            }
        ]
    root = spar_root.parent
    default_timeout = int(cfg.get("timeout_seconds") or DEFAULT_TIMEOUT)
    out = []
    for entry in cfg.get("checks") or []:
        if not isinstance(entry, dict):
            continue
        name = str(entry.get("name") or "check")
        run = str(entry.get("run") or "").strip()
        required = entry.get("required", True)
        required = required if isinstance(required, bool) else str(required).lower() not in ("false", "no", "0")
        timeout = int(entry.get("timeout_seconds") or default_timeout)
        budget_requirement = str(entry.get("budget_requirement") or "").strip()
        raw_duration_budget = entry.get("max_duration_ms")
        try:
            max_duration_ms = int(raw_duration_budget) if raw_duration_budget is not None else None
        except (TypeError, ValueError):
            max_duration_ms = -1
        raw_ratchet_baseline = entry.get("ratchet_baseline")
        try:
            ratchet_baseline = int(raw_ratchet_baseline) if raw_ratchet_baseline is not None else None
        except (TypeError, ValueError):
            ratchet_baseline = -1
        if max_duration_ms is not None and (max_duration_ms < 1 or not budget_requirement):
            message = f"{name}: max_duration_ms requires a positive value and budget_requirement"
            out.append(
                {
                    "name": name,
                    "status": "fail",
                    "outcome": "instrument_error",
                    "summary": message,
                    "output_tail": "",
                    "duration_ms": 0,
                    "owner": owner,
                    "findings": [_finding("project/bad-budget", "error", None, message, owner)],
                }
            )
            continue
        if ratchet_baseline is not None and ratchet_baseline < 0:
            message = f"{name}: ratchet_baseline must be a non-negative integer"
            out.append(
                {
                    "name": name,
                    "status": "fail",
                    "outcome": "instrument_error",
                    "summary": message,
                    "output_tail": "",
                    "duration_ms": 0,
                    "owner": owner,
                    "findings": [_finding("project/bad-ratchet", "error", None, message, owner)],
                }
            )
            continue
        if budget_requirement and not re.search(rf"\b{re.escape(budget_requirement)}\b", spec_text):
            message = f"{name}: budget requirement `{budget_requirement}` is not declared in spec.md"
            out.append(
                {
                    "name": name,
                    "status": "fail",
                    "outcome": "failed",
                    "summary": message,
                    "output_tail": "",
                    "duration_ms": 0,
                    "budget_requirement": budget_requirement,
                    "max_duration_ms": max_duration_ms,
                    "owner": owner,
                    "findings": [_finding("project/budget-untraced", "error", None, message, owner)],
                }
            )
            continue
        if not run:
            out.append(
                {
                    "name": name,
                    "status": "fail",
                    "summary": "no `run:` command",
                    "output_tail": "",
                    "duration_ms": 0,
                    "owner": owner,
                    "findings": [_finding("project/bad-config", "error", None, f"{name}: no run command", owner)],
                }
            )
            continue
        try:
            program = shlex.split(run)[0]
        except (ValueError, IndexError):
            program = run.split()[0] if run.split() else ""
        # A pack check may call `spar` itself. When the CLI is not on PATH (a
        # source checkout, the test suite) run this very interpreter instead.
        if program == "spar" and shutil.which("spar") is None:
            run = f"{shlex.quote(sys.executable)} -m spar.cli" + run[len("spar"):]
            program = sys.executable
        if program and "/" not in program and shutil.which(program) is None and not (
            program in ("cd", "export", "set", "true", "false")
        ):
            status = "fail" if required else "skip"
            out.append(
                {
                    "name": name,
                    "status": status,
                    "outcome": "instrument_error" if required else "skipped",
                    "summary": f"`{program}` is not installed" + ("" if required else " (optional)"),
                    "output_tail": "",
                    "duration_ms": 0,
                    "owner": owner,
                    "findings": (
                        [_finding("project/tool-missing", "error", None, f"{name}: `{program}` not found", owner)]
                        if required
                        else []
                    ),
                }
            )
            continue
        started = time.time()
        try:
            proc = subprocess.run(
                run,
                shell=True,
                cwd=str(root),
                capture_output=True,
                text=True,
                timeout=timeout,
            )
            duration = int((time.time() - started) * 1000)
            tail = _tail((proc.stdout or "") + ("\n" + proc.stderr if proc.stderr else ""))
            passed = proc.returncode == 0
            # Some exit codes mean "nothing to check yet", not "broken": pytest
            # exits 5 when it collected no tests, which is every project before
            # its first test file lands. A check may also declare its own.
            skip_codes = set(_skip_exit_codes(entry))
            if "pytest" in run:
                skip_codes.add(5)
            nothing_yet = not passed and proc.returncode in skip_codes
            budget_exceeded = passed and max_duration_ms is not None and duration > max_duration_ms
            ratchet_value = None
            ratchet_error = None
            ratchet_growth = False
            if passed and ratchet_baseline is not None:
                measurement = (proc.stdout or "").strip()
                try:
                    ratchet_value = int(measurement)
                    if ratchet_value < 0:
                        raise ValueError
                    ratchet_growth = ratchet_value > ratchet_baseline
                except ValueError:
                    ratchet_error = f"{name}: ratchet command must print exactly one non-negative integer"
            summary = f"exit {proc.returncode} · `{run}`" + (" · nothing to check yet" if nothing_yet else "")
            findings = (
                []
                if passed or nothing_yet
                else [_finding("project/check-failed", "error", None, f"{name}: `{run}` exited {proc.returncode}", owner)]
            )
            if budget_exceeded:
                summary += f" · {duration}ms exceeds {max_duration_ms}ms budget for {budget_requirement}"
                findings.append(_finding("project/budget-exceeded", "error", None, summary, owner))
            if ratchet_error:
                summary += f" · {ratchet_error}"
                findings.append(_finding("project/ratchet-instrument", "error", None, ratchet_error, owner))
            elif ratchet_growth:
                summary += f" · ratchet grew from {ratchet_baseline} to {ratchet_value}"
                findings.append(_finding("project/ratchet-growth", "error", None, summary, owner))
            elif ratchet_value is not None and ratchet_value < ratchet_baseline:
                summary += f" · improved; candidate baseline {ratchet_value} (currently {ratchet_baseline})"
            result = {
                    "name": name,
                    "status": "pass" if passed and not budget_exceeded and not ratchet_growth and not ratchet_error else ("skip" if nothing_yet else "fail"),
                    "summary": summary,
                    "output_tail": tail,
                    "duration_ms": duration,
                    "budget_requirement": budget_requirement or None,
                    "max_duration_ms": max_duration_ms,
                    "ratchet_baseline": ratchet_baseline,
                    "ratchet_value": ratchet_value,
                    "owner": owner,
                    "findings": findings,
                }
            if ratchet_error:
                result["outcome"] = "instrument_error"
            out.append(result)
        except subprocess.TimeoutExpired as exc:
            duration = int((time.time() - started) * 1000)
            partial = (exc.stdout or b"")
            if isinstance(partial, bytes):
                partial = partial.decode("utf-8", "replace")
            out.append(
                {
                    "name": name,
                    "status": "fail",
                    "outcome": "instrument_error",
                    "summary": f"timed out after {timeout}s · `{run}`",
                    "output_tail": _tail(partial),
                    "duration_ms": duration,
                    "owner": owner,
                    "findings": [_finding("project/check-timeout", "error", None, f"{name}: timed out after {timeout}s", owner)],
                }
            )
        except OSError as exc:
            out.append(
                {
                    "name": name,
                    "status": "fail",
                    "outcome": "instrument_error",
                    "summary": f"could not run: {exc}",
                    "output_tail": "",
                    "duration_ms": 0,
                    "owner": owner,
                    "findings": [_finding("project/check-failed", "error", None, f"{name}: {exc}", owner)],
                }
            )
    if not out:
        out.append(
            {
                "name": "checks.yaml",
                "status": "skip",
                "summary": "checks.yaml declares no checks",
                "output_tail": "",
                "duration_ms": 0,
                "owner": owner,
                "findings": [],
            }
        )
    return out


def _summarise(checks: list[dict]) -> tuple[bool, str]:
    passed = sum(1 for c in checks if c["status"] == "pass")
    failed = sum(1 for c in checks if c["status"] == "fail")
    skipped = sum(1 for c in checks if c["status"] == "skip")
    return failed == 0, f"{passed} passed, {failed} failed, {skipped} skipped"


def _add_outcomes(checks: list[dict]) -> None:
    """Add precise semantics without breaking consumers of legacy status."""
    defaults = {"pass": "passed", "fail": "failed", "skip": "skipped"}
    for check in checks:
        check.setdefault("outcome", defaults.get(check.get("status"), "instrument_error"))


def run_scope(spar_root: Path, feature: str | None, scope: str) -> dict:
    """Run one scope, cache it, return the `spar.check/v1` result."""
    feature_dir = spar_root / "specs" / feature if feature else None
    if scope == "artifacts":
        checks = run_artifacts(feature_dir) if feature_dir else []
    elif scope == "verification":
        checks = run_verification(feature_dir) if feature_dir else []
    elif scope == "project":
        checks = run_project(spar_root, feature_dir) + run_styling(spar_root.parent)
    else:
        raise ValueError(f"unknown scope: {scope}")
    if not checks:
        checks = [
            {
                "name": scope,
                "status": "skip",
                "summary": "no feature selected",
                "output_tail": "",
                "duration_ms": 0,
                "owner": None,
                "findings": [],
            }
        ]
    _add_outcomes(checks)
    ok, summary = _summarise(checks)
    version = artifact_version(feature_dir, SCOPE_FILES[scope], raw=(scope == "project")) if feature_dir else ""
    result = {
        "schema": SCHEMA,
        "feature": feature,
        "scope": scope,
        "ok": ok,
        "summary": summary,
        "at": now_iso(),
        "version": version,
        "could_not_run": any(c["outcome"] in ("inconclusive", "instrument_error") for c in checks),
        "checks": checks,
    }
    cache = read_cache(spar_root, feature)
    cache["scopes"][scope] = result
    write_cache(spar_root, feature, cache)
    return result


def run(spar_root: Path, feature: str | None, scope: str = "all") -> dict:
    if scope != "all":
        return run_scope(spar_root, feature, scope)
    results = [run_scope(spar_root, feature, s) for s in SCOPES]
    checks = [c for r in results for c in r["checks"]]
    ok, summary = _summarise(checks)
    feature_dir = spar_root / "specs" / feature if feature else None
    version = (
        artifact_version(feature_dir, ["spec.md", "plan.md", "tasks.md", "build-log.md", "verification.md"])
        if feature_dir
        else ""
    )
    return {
        "schema": SCHEMA,
        "feature": feature,
        "scope": "all",
        "ok": ok,
        "summary": summary,
        "at": now_iso(),
        "version": version,
        "could_not_run": any(c["outcome"] in ("inconclusive", "instrument_error") for c in checks),
        "checks": checks,
    }


def owner_of_failure(result: dict) -> str | None:
    """The agent that owns the first failing check, for routing a fix."""
    for c in result.get("checks", []):
        if c["status"] == "fail":
            for f in c.get("findings", []):
                if f["severity"] == "error" and f.get("owner"):
                    return f["owner"]
            if c.get("owner"):
                return c["owner"]
    return None


# --------------------------------------------------------------------------- #
# Rendering
# --------------------------------------------------------------------------- #


def for_agent(result: dict) -> str:
    """Findings as a markdown block the owning agent can act on."""
    failing = [c for c in result.get("checks", []) if c["status"] == "fail"]
    if not failing:
        return f"All checks passed ({result.get('summary', '')}). Nothing to fix.\n"
    lines = [f"# Deterministic checks failed — {result.get('summary', '')}", ""]
    for c in failing:
        lines.append(f"## {c['name']} — {c['summary']}")
        if c.get("owner"):
            lines.append(f"Owner: `spar-{c['owner']}`")
        lines.append("")
        for f in c.get("findings", []):
            loc = f" (line {f['line']})" if f.get("line") else ""
            lines.append(f"- `{f['code']}` [{f['severity']}]{loc}: {f['message']} — owner `{f['owner']}`")
        if c.get("output_tail"):
            lines.append("")
            lines.append("```")
            lines.append(c["output_tail"])
            lines.append("```")
        lines.append("")
    lines.append("Fix every finding above. Do not start new tasks.")
    return "\n".join(lines) + "\n"


def render_text(result: dict) -> str:
    lines = [f"{result['scope']}: {result['summary']}" + ("" if result["ok"] else "  (FAIL)")]
    for c in result["checks"]:
        mark = {"pass": "✓", "fail": "✗", "skip": "–"}.get(c["status"], "?")
        lines.append(f"  {mark} {c['name']}: {c['summary']}")
        for f in c.get("findings", []):
            loc = f":{f['line']}" if f.get("line") else ""
            lines.append(f"      {f['severity'][0].upper()} {f['code']}{loc} — {f['message']}")
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# `spar checks init`
# --------------------------------------------------------------------------- #


def infer_checks(root: Path) -> list[dict]:
    """A starter set of project checks from whatever manifests are present."""
    checks: list[dict] = []
    pkg = root / "package.json"
    if pkg.is_file():
        runner = "npm"
        if (root / "pnpm-lock.yaml").is_file():
            runner = "pnpm"
        elif (root / "yarn.lock").is_file():
            runner = "yarn"
        try:
            scripts = (json.loads(pkg.read_text(encoding="utf-8")) or {}).get("scripts") or {}
        except (OSError, json.JSONDecodeError):
            scripts = {}
        if "test" in scripts:
            checks.append({"name": "tests", "run": f"{runner} test", "required": True})
        if "lint" in scripts:
            checks.append({"name": "lint", "run": f"{runner} run lint", "required": True})
        if "typecheck" in scripts:
            checks.append({"name": "typecheck", "run": f"{runner} run typecheck", "required": False})
        elif (root / "tsconfig.json").is_file():
            checks.append({"name": "typecheck", "run": "npx tsc --noEmit", "required": False})
    if any((root / n).is_file() for n in ("pyproject.toml", "setup.py", "setup.cfg", "requirements.txt")):
        checks.append({"name": "tests", "run": "pytest -q", "required": True})
        checks.append({"name": "lint", "run": "ruff check .", "required": False})
        checks.append({"name": "typecheck", "run": "mypy .", "required": False})
    if (root / "Cargo.toml").is_file():
        checks.append({"name": "tests", "run": "cargo test", "required": True})
        checks.append({"name": "lint", "run": "cargo clippy -- -D warnings", "required": False})
    if (root / "go.mod").is_file():
        checks.append({"name": "tests", "run": "go test ./...", "required": True})
        checks.append({"name": "lint", "run": "go vet ./...", "required": True})
    if not checks and (root / "Makefile").is_file():
        text = (root / "Makefile").read_text(encoding="utf-8", errors="replace")
        if re.search(r"^test:", text, re.M):
            checks.append({"name": "tests", "run": "make test", "required": True})
        if re.search(r"^lint:", text, re.M):
            checks.append({"name": "lint", "run": "make lint", "required": False})
    # de-duplicate by name, first wins
    seen, out = set(), []
    for c in checks:
        if c["name"] in seen:
            continue
        seen.add(c["name"])
        out.append(c)
    return out


def render_checks_yaml(checks: list[dict], timeout: int = DEFAULT_TIMEOUT) -> str:
    lines = [
        "# Deterministic project checks. `spar check --scope project` runs each `run:`",
        "# from the repository root and feeds failures back to the build. Required checks",
        "# must pass before a checkpoint can be approved; optional ones are reported.",
        f"timeout_seconds: {timeout}",
        "checks:",
    ]
    for c in checks:
        lines.append(f"  - name: {c['name']}")
        lines.append(f"    run: {json.dumps(str(c['run']))}")
        lines.append(f"    required: {'true' if c.get('required', True) else 'false'}")
        if c.get("timeout_seconds"):
            lines.append(f"    timeout_seconds: {int(c['timeout_seconds'])}")
        if c.get("budget_requirement"):
            lines.append(f"    budget_requirement: {c['budget_requirement']}")
        if c.get("max_duration_ms"):
            lines.append(f"    max_duration_ms: {int(c['max_duration_ms'])}")
        if c.get("ratchet_baseline") is not None:
            lines.append(f"    ratchet_baseline: {int(c['ratchet_baseline'])}")
        if c.get("pack"):
            lines.append(f"    pack: {c['pack']}")
        if c.get("needs_tool"):
            lines.append(f"    needs_tool: {c['needs_tool']}")
    if not checks:
        lines.append("  # - name: tests")
        lines.append('  #   run: "pytest -q"')
        lines.append("  #   required: true")
    return "\n".join(lines) + "\n"


def write_checks_config(spar_root: Path, checks: list[dict], timeout: int | None = None) -> Path:
    cfg = load_checks_config(spar_root) or {}
    t = int(timeout or cfg.get("timeout_seconds") or DEFAULT_TIMEOUT)
    p = checks_config_path(spar_root)
    p.write_text(render_checks_yaml(checks, t), encoding="utf-8")
    return p


# --------------------------------------------------------------------------- #
# `spar scan`: pattern scans over the working tree's changes
# --------------------------------------------------------------------------- #

PAN_RE = re.compile(r"(?<![\d-])(?:\d[ -]?){13,19}(?![\d-])")
SSN_RE = re.compile(r"\b(?!000|666|9\d\d)\d{3}-(?!00)\d{2}-(?!0000)\d{4}\b")
EMAIL_RE = re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")
MRN_RE = re.compile(r"\b(?:MRN|medical record (?:number|no\.?))\s*[:#]?\s*\d{5,}", re.I)
DOB_RE = re.compile(r"\b(?:DOB|date of birth)\s*[:#]?\s*\d{1,4}[/-]\d{1,2}[/-]\d{1,4}", re.I)
SECRET_RES = (
    ("private-key", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")),
    ("aws-access-key", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("github-token", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{36,}\b")),
    ("slack-token", re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{10,}\b")),
    ("generic-secret", re.compile(r"(?i)\b(api[_-]?key|secret|password|passwd|token)\b\s*[:=]\s*['\"][^'\"]{8,}['\"]")),
    ("jwt", re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b")),
)
EXAMPLE_EMAIL = re.compile(r"@(example\.(com|org|net)|localhost|test)\b", re.I)


def _luhn(digits: str) -> bool:
    total, alt = 0, False
    for ch in reversed(digits):
        d = ord(ch) - 48
        if alt:
            d *= 2
            if d > 9:
                d -= 9
        total += d
        alt = not alt
    return total % 10 == 0


def _added_lines(root: Path) -> list[tuple[str, int, str]]:
    """(path, line, text) for every line added in the working tree vs HEAD,
    plus every line of untracked files. Falls back to the whole tree when the
    folder is not a git repository."""
    out: list[tuple[str, int, str]] = []
    try:
        diff = subprocess.run(
            ["git", "diff", "--no-color", "-U0", "HEAD", "--"],
            cwd=str(root), capture_output=True, text=True, timeout=60,
        )
        if diff.returncode != 0:
            diff = subprocess.run(
                ["git", "diff", "--no-color", "-U0", "--"],
                cwd=str(root), capture_output=True, text=True, timeout=60,
            )
        if diff.returncode == 0:
            path, line_no = "", 0
            for raw in diff.stdout.splitlines():
                if raw.startswith("+++ "):
                    path = raw[4:].strip()
                    path = path[2:] if path.startswith("b/") else path
                elif raw.startswith("@@"):
                    m = re.search(r"\+(\d+)", raw)
                    line_no = int(m.group(1)) if m else 0
                elif raw.startswith("+") and not raw.startswith("+++"):
                    out.append((path, line_no, raw[1:]))
                    line_no += 1
            untracked = subprocess.run(
                ["git", "ls-files", "--others", "--exclude-standard"],
                cwd=str(root), capture_output=True, text=True, timeout=60,
            )
            for rel in untracked.stdout.splitlines():
                p = root / rel
                if not p.is_file() or p.stat().st_size > 2_000_000:
                    continue
                try:
                    for i, text in enumerate(p.read_text(encoding="utf-8", errors="replace").splitlines(), start=1):
                        out.append((rel, i, text))
                except OSError:
                    pass
            return out
    except (OSError, subprocess.SubprocessError):
        pass
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if not d.startswith(".") and d not in ("node_modules", "target", "dist", "build", "vendor", "__pycache__")]
        for name in filenames:
            p = Path(dirpath) / name
            try:
                if p.stat().st_size > 2_000_000:
                    continue
                for i, text in enumerate(p.read_text(encoding="utf-8", errors="replace").splitlines(), start=1):
                    out.append((str(p.relative_to(root)), i, text))
            except (OSError, ValueError):
                pass
    return out


def scan_diff(root: Path, *, pan: bool = False, phi: bool = False, pii: bool = False, secrets: bool = False) -> list[dict]:
    """Findings over added lines: card numbers, health identifiers, personal
    data, secrets. Deterministic and stdlib-only, so a pack can require it
    without asking anyone to install a scanner first."""
    hits: list[dict] = []
    for path, line, text in _added_lines(root):
        if "/.spar/" in f"/{path}" or path.startswith(".spar/") or path.startswith("spar/"):
            continue
        if pan:
            for m in PAN_RE.finditer(text):
                digits = re.sub(r"[ -]", "", m.group(0))
                if 13 <= len(digits) <= 19 and _luhn(digits) and not digits.startswith(("0", "1", "2", "7", "8", "9")):
                    hits.append({"kind": "pan", "path": path, "line": line, "match": digits[:6] + "…" + digits[-4:]})
        if phi or pii:
            if SSN_RE.search(text):
                hits.append({"kind": "ssn", "path": path, "line": line, "match": "***-**-" + SSN_RE.search(text).group(0)[-4:]})
            if phi and (MRN_RE.search(text) or DOB_RE.search(text)):
                hits.append({"kind": "phi-identifier", "path": path, "line": line, "match": text.strip()[:60]})
            if pii:
                m = EMAIL_RE.search(text)
                if m and not EXAMPLE_EMAIL.search(m.group(0)):
                    hits.append({"kind": "email", "path": path, "line": line, "match": m.group(0)[:3] + "…"})
        if secrets:
            for kind, rx in SECRET_RES:
                if rx.search(text):
                    hits.append({"kind": kind, "path": path, "line": line, "match": "(redacted)"})
    return hits


DEP_AUDITS = (
    ("package.json", "npm", ["npm", "audit", "--audit-level=high", "--omit=dev"]),
    ("pyproject.toml", "pip-audit", ["pip-audit", "--progress-spinner", "off"]),
    ("requirements.txt", "pip-audit", ["pip-audit", "-r", "requirements.txt", "--progress-spinner", "off"]),
    ("Cargo.toml", "cargo-audit", ["cargo", "audit"]),
    ("go.mod", "govulncheck", ["govulncheck", "./..."]),
)


def scan_deps(root: Path) -> tuple[int, str]:
    """Run whichever dependency auditor fits the manifests present.

    Returns (exit_code, output). 0 clean, 1 findings, 2 no auditor available.
    """
    ran = False
    worst = 0
    out_lines: list[str] = []
    for manifest, tool, argv in DEP_AUDITS:
        if not (root / manifest).is_file():
            continue
        if shutil.which(argv[0]) is None:
            out_lines.append(f"{manifest}: `{tool}` is not installed; skipped")
            continue
        ran = True
        try:
            proc = subprocess.run(argv, cwd=str(root), capture_output=True, text=True, timeout=900)
        except (OSError, subprocess.SubprocessError) as exc:
            out_lines.append(f"{manifest}: {tool} could not run: {exc}")
            worst = max(worst, 1)
            continue
        out_lines.append(f"$ {' '.join(argv)}  (exit {proc.returncode})")
        out_lines.append(_tail((proc.stdout or "") + "\n" + (proc.stderr or ""), 40))
        if proc.returncode != 0:
            worst = max(worst, 1)
    if not ran:
        return 2, "\n".join(out_lines) or "no dependency manifest found"
    return worst, "\n".join(out_lines)
