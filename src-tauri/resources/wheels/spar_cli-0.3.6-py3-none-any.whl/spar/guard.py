"""Prove that a regression guard detects the production change it protects."""

from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path

MAX_OUTPUT_BYTES = 8192


def _capture(argv: list[str], cwd: Path, timeout: int) -> tuple[int, str]:
    completed = subprocess.run(
        argv,
        cwd=str(cwd),
        capture_output=True,
        timeout=timeout,
    )
    raw = (completed.stdout or b"") + (b"\n" + completed.stderr if completed.stderr else b"")
    total = len(raw)
    clipped = raw[-MAX_OUTPUT_BYTES:]
    text = clipped.decode("utf-8", "replace").strip()
    if total > MAX_OUTPUT_BYTES:
        text = f"[TRUNCATED: showing last {MAX_OUTPUT_BYTES} of {total} bytes]\n{text}"
    return completed.returncode, text


def _git(repo: Path, *args: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["git", "-C", str(repo), *args],
        capture_output=True,
        text=True,
    )


def _result(outcome: str, summary: str, baseline_exit: int | None = None,
            mutant_exit: int | None = None, output: str = "") -> dict:
    return {
        "schema": "spar.guard-verification/v1",
        "outcome": outcome,
        "summary": summary,
        "baseline_exit": baseline_exit,
        "mutant_exit": mutant_exit,
        "output": output,
    }


def verify_guard(repo: Path, revert_paths: list[str], command: list[str],
                 expected: str | None = None, timeout: int = 600) -> dict:
    """Run a guard green, revert selected fix paths, then require it to go red."""
    try:
        repo = repo.resolve(strict=True)
    except OSError as exc:
        return _result("instrument_error", f"repository cannot be resolved: {exc}")
    if not command:
        return _result("instrument_error", "no guard command was provided")
    if timeout < 1 or timeout > 3600:
        return _result("instrument_error", "timeout must be between 1 and 3600 seconds")

    top = _git(repo, "rev-parse", "--show-toplevel")
    if top.returncode != 0:
        return _result("inconclusive", "repository is not a Git worktree")
    root = Path(top.stdout.strip()).resolve()
    if root != repo:
        return _result("inconclusive", f"--repo must name the Git root: {root}")
    if _git(root, "rev-parse", "--verify", "HEAD^").returncode != 0:
        return _result("inconclusive", "HEAD has no parent to restore")
    if _git(root, "status", "--porcelain", "--untracked-files=all").stdout.strip():
        return _result("inconclusive", "repository is dirty; commit or remove local changes first")

    safe_paths: list[str] = []
    for raw in revert_paths:
        candidate = Path(raw)
        if candidate.is_absolute() or ".." in candidate.parts or not candidate.parts:
            return _result("instrument_error", f"unsafe revert path: {raw}")
        safe_paths.append(candidate.as_posix())
    if not safe_paths:
        return _result("instrument_error", "at least one --revert path is required")

    changed = set(
        line.strip()
        for line in _git(root, "diff", "--name-only", "HEAD^", "HEAD").stdout.splitlines()
        if line.strip()
    )
    absent = [path for path in safe_paths if path not in changed]
    if absent:
        return _result("inconclusive", "revert path was not changed by HEAD: " + ", ".join(absent))

    try:
        baseline_exit, baseline_output = _capture(command, root, timeout)
    except subprocess.TimeoutExpired:
        return _result("instrument_error", f"baseline command timed out after {timeout}s")
    except OSError as exc:
        return _result("instrument_error", f"baseline command could not start: {exc}")
    if baseline_exit != 0:
        return _result(
            "inconclusive",
            "guard is not green with the fix present",
            baseline_exit=baseline_exit,
            output=baseline_output,
        )

    with tempfile.TemporaryDirectory(prefix="spar-guard-") as temporary:
        worktree = Path(temporary) / "worktree"
        added = _git(root, "worktree", "add", "--detach", str(worktree), "HEAD")
        if added.returncode != 0:
            return _result("instrument_error", f"could not create verification worktree: {added.stderr.strip()}", baseline_exit=0)
        try:
            restored = _git(worktree, "restore", "--source", "HEAD^", "--worktree", "--", *safe_paths)
            if restored.returncode != 0:
                return _result("instrument_error", f"could not restore fix paths: {restored.stderr.strip()}", baseline_exit=0)
            try:
                mutant_exit, mutant_output = _capture(command, worktree, timeout)
            except subprocess.TimeoutExpired:
                return _result("instrument_error", f"mutant command timed out after {timeout}s", baseline_exit=0)
            except OSError as exc:
                return _result("instrument_error", f"mutant command could not start: {exc}", baseline_exit=0)
        finally:
            _git(root, "worktree", "remove", "--force", str(worktree))

    detected = mutant_exit != 0 and (expected is None or expected in mutant_output)
    if detected:
        return _result("verified", "guard failed after the fix was reverted", 0, mutant_exit, mutant_output)
    reason = "guard stayed green after the fix was reverted"
    if mutant_exit != 0 and expected is not None:
        reason = f"guard failed, but output did not contain expected marker: {expected}"
    return _result("decoration", reason, 0, mutant_exit, mutant_output)
