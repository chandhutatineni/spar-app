"""Correct draw.io files from a simple description.

Hand-written mxGraph XML is the usual way draw.io diagrams go wrong: every
coordinate is someone's guess, so sequence messages collapse onto one line and
entities overflow their boxes. Agents describe what the diagram says; this
module decides where everything goes.

Three kinds, each from a small JSON object:

  sequence  {"title", "participants": ["Browser", "API", ...],
             "messages": [{"from": "Browser", "to": "API", "label": "POST /x", "reply": false}, ...],
             "notes": [{"over": ["API", "DB"], "after": 2, "label": "alt: ..."}]}
  er        {"title", "entities": [{"name": "User", "fields": ["id: uuid (PK)", ...]}, ...],
             "relations": [{"from": "User", "to": "Posting", "label": "1 : N", "many": "to"}]}
  context-map {"title", "contexts": [{"name": "Hiring", "type": "core|supporting|generic", "aggregates": ["JobPosting"]}],
             "relations": [{"upstream": "Identity", "downstream": "Hiring", "pattern": "OHS/PL|ACL|Conformist|Customer-Supplier|Partnership|Shared Kernel", "label": "JWT claims"}]}
  aggregate {"title", "root": {"name": "JobPosting", "fields": [...], "methods": ["publish()", "close()"]},
             "entities": [{"name", "fields"}], "values": [{"name", "fields"}], "events": ["PostingPublished"],
             "invariants": ["a closed posting accepts no applications"]}
  flow      {"title", "direction": "right" | "down",
             "nodes": [{"id": "api", "label": "API", "shape": "box|db|person|cloud|queue", "group": "Backend"}],
             "edges": [{"from": "web", "to": "api", "label": "HTTPS"}]}
"""

from __future__ import annotations

import html
import json
from pathlib import Path

PALETTE = ["#dae8fc", "#d5e8d4", "#ffe6cc", "#e1d5e7", "#fff2cc", "#f8cecc", "#f5f5f5"]
STROKE = ["#6c8ebf", "#82b366", "#d79b00", "#9673a6", "#d6b656", "#b85450", "#666666"]


def _esc(s: str) -> str:
    return html.escape(str(s), quote=True)


class _Doc:
    def __init__(self, title: str) -> None:
        self.title = title
        self.cells: list[str] = []
        self.n = 1

    def id(self, prefix: str = "c") -> str:
        self.n += 1
        return f"{prefix}{self.n}"

    def vertex(self, value: str, style: str, x: float, y: float, w: float, h: float, parent: str = "1", cid: str | None = None) -> str:
        cid = cid or self.id("v")
        self.cells.append(
            f'<mxCell id="{cid}" value="{_esc(value)}" style="{style}" vertex="1" parent="{parent}">'
            f'<mxGeometry x="{x:.0f}" y="{y:.0f}" width="{w:.0f}" height="{h:.0f}" as="geometry"/></mxCell>'
        )
        return cid

    def edge(self, value: str, style: str, source: str | None = None, target: str | None = None,
             points: tuple[tuple[float, float], tuple[float, float]] | None = None,
             waypoints: list[tuple[float, float]] | None = None) -> str:
        cid = self.id("e")
        attrs = (f' source="{source}"' if source else "") + (f' target="{target}"' if target else "")
        geo = ['<mxGeometry relative="1" as="geometry">']
        if points:
            (sx, sy), (tx, ty) = points
            geo.append(f'<mxPoint x="{sx:.0f}" y="{sy:.0f}" as="sourcePoint"/>')
            geo.append(f'<mxPoint x="{tx:.0f}" y="{ty:.0f}" as="targetPoint"/>')
        if waypoints:
            geo.append('<Array as="points">' + "".join(f'<mxPoint x="{x:.0f}" y="{y:.0f}"/>' for x, y in waypoints) + "</Array>")
        geo.append("</mxGeometry>")
        self.cells.append(f'<mxCell id="{cid}" value="{_esc(value)}" style="{style}" edge="1" parent="1"{attrs}>{"".join(geo)}</mxCell>')
        return cid

    def xml(self) -> str:
        body = "".join(self.cells)
        return (
            f'<mxfile host="SPAR"><diagram name="{_esc(self.title)}"><mxGraphModel grid="1" gridSize="10" '
            f'guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="0" math="0" shadow="0"><root>'
            f'<mxCell id="0"/><mxCell id="1" parent="0"/>{body}</root></mxGraphModel></diagram></mxfile>\n'
        )


def sequence(spec: dict) -> str:
    doc = _Doc(spec.get("title", "Sequence"))
    parts = [str(p) for p in spec.get("participants", [])]
    msgs = spec.get("messages", [])
    for m in msgs:  # participants named only in messages still get a lifeline
        for k in ("from", "to"):
            if m.get(k) and m[k] not in parts:
                parts.append(m[k])
    gap, width, head, step, top = 175, 140, 44, 54, 30
    notes = spec.get("notes", [])
    # One row per message; a note gets its own row after the message it follows.
    rows: list[tuple[str, int]] = []
    for i in range(len(msgs)):
        rows.append(("m", i))
        rows += [("n", j) for j, n in enumerate(notes) if int(n.get("after", len(msgs))) == i + 1]
    rows += [("n", j) for j, n in enumerate(notes) if int(n.get("after", len(msgs))) > len(msgs) or int(n.get("after", 0)) < 1]
    height = head + 40 + step * (len(rows) + 1)
    centre = {}
    for i, p in enumerate(parts):
        x = 20 + i * gap
        doc.vertex(p, "shape=umlLifeline;perimeter=lifelinePerimeter;whiteSpace=wrap;html=1;container=0;"
                      "collapsible=0;recursiveResize=0;outlineConnect=0;size=%d;fillColor=%s;strokeColor=%s;fontStyle=1;"
                      % (head, PALETTE[i % len(PALETTE)], STROKE[i % len(STROKE)]),
                   x, top, width, height)
        centre[p] = x + width / 2
    for r, (kind, i) in enumerate(rows):
        y = top + head + 30 + r * step
        if kind == "n":
            note = notes[i]
            over = [centre[p] for p in note.get("over", []) if p in centre] or list(centre.values())
            x1, x2 = min(over) - width / 2 + 6, max(over) + width / 2 - 6
            doc.vertex(note.get("label", ""), "shape=note;whiteSpace=wrap;html=1;size=10;fillColor=#fff2cc;strokeColor=#d6b656;"
                                              "fontSize=11;align=left;spacingLeft=6;", x1, y - step / 2 + 8, x2 - x1, step - 16)
            continue
        m = msgs[i]
        a, b = centre.get(m.get("from")), centre.get(m.get("to"))
        if a is None or b is None:
            continue
        label = f"{i + 1}. {m.get('label', '')}".strip()
        reply = bool(m.get("reply"))
        style = ("html=1;verticalAlign=bottom;labelBackgroundColor=#ffffff;fontSize=11;"
                 + ("dashed=1;endArrow=open;endSize=8;" if reply else "endArrow=block;endFill=1;"))
        if a == b:  # a message to itself: a small loop to the right, label beside it
            doc.edge(label, style + "align=left;verticalAlign=middle;spacingLeft=4;", points=((a, y - 12), (a, y + 12)),
                     waypoints=[(a + 40, y - 12), (a + 40, y + 12)])
        else:
            doc.edge(label, style, points=((a, y), (b, y)))
    return doc.xml()


def er(spec: dict) -> str:
    doc = _Doc(spec.get("title", "Data model"))
    ents = spec.get("entities", [])
    cols = 3 if len(ents) > 6 else max(1, min(len(ents), 2))
    row_h, head, width, gx, gy = 22, 28, 260, 110, 70
    ids, heights = {}, []
    for i, e in enumerate(ents):
        heights.append(head + row_h * max(1, len(e.get("fields", []))) + 6)
    row_tops, y = [], 20
    for r in range((len(ents) + cols - 1) // cols):
        row_tops.append(y)
        y += max(heights[r * cols:(r + 1) * cols] or [0]) + gy
    for i, e in enumerate(ents):
        c, r = i % cols, i // cols
        x, y = 20 + c * (width + gx), row_tops[r]
        fields = [str(f) for f in e.get("fields", [])]
        eid = doc.vertex(e["name"], "swimlane;fontStyle=1;childLayout=stackLayout;horizontal=1;startSize=%d;"
                                   "horizontalStack=0;resizeParent=1;resizeParentMax=0;collapsible=0;marginBottom=0;"
                                   "html=1;fillColor=%s;strokeColor=%s;swimlaneFillColor=#ffffff;"
                                   % (head, PALETTE[i % len(PALETTE)], STROKE[i % len(STROKE)]),
                         x, y, width, heights[i])
        for j, f in enumerate(fields or [""]):
            key = "(PK)" in f or " PK" in f
            doc.vertex(f, "text;strokeColor=none;fillColor=none;align=left;verticalAlign=middle;spacingLeft=8;"
                          "spacingRight=4;overflow=hidden;rotatable=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;"
                          "html=1;fontSize=11;" + ("fontStyle=1;" if key else ""),
                       0, head + j * row_h, width, row_h, parent=eid)
        ids[e["name"]] = eid
    cell = {e["name"]: (i % cols, i // cols) for i, e in enumerate(ents)}
    for rel in spec.get("relations", []):
        a, b = ids.get(rel.get("from")), ids.get(rel.get("to"))
        if not a or not b:
            continue
        # Leave and enter by the sides that face each other, so lines never cross a box.
        (ca, ra), (cb, rb) = cell[rel["from"]], cell[rel["to"]]
        if ra == rb:
            ports = "exitX=1;exitY=0.3;entryX=0;entryY=0.3;" if ca < cb else "exitX=0;exitY=0.3;entryX=1;entryY=0.3;"
        elif ca == cb:
            ports = "exitX=0.5;exitY=1;entryX=0.5;entryY=0;" if ra < rb else "exitX=0.5;exitY=0;entryX=0.5;entryY=1;"
        else:
            # Diagonal: go vertically out of the source first, then into the side of the target
            # that faces it — the row between them stays clear.
            ports = ("exitX=0.5;exitY=1;" if ra < rb else "exitX=0.5;exitY=0;") + ("entryX=0;entryY=0.5;" if ca < cb else "entryX=1;entryY=0.5;")
        many_end = rel.get("many", "to")
        start = "ERmandOne" if many_end == "to" else "ERmany"
        end = "ERmany" if many_end == "to" else "ERmandOne"
        doc.edge(rel.get("label", ""), "edgeStyle=orthogonalEdgeStyle;rounded=1;html=1;fontSize=11;labelBackgroundColor=#ffffff;"
                                       f"startArrow={start};endArrow={end};startFill=0;endFill=0;" + ports, source=a, target=b)
    return doc.xml()


SHAPES = {
    "box": "rounded=1;whiteSpace=wrap;html=1;",
    "db": "shape=cylinder3;whiteSpace=wrap;html=1;boundedLbl=1;backgroundOutline=1;size=12;",
    "person": "shape=umlActor;verticalLabelPosition=bottom;verticalAlign=top;html=1;outlineConnect=0;",
    "cloud": "ellipse;shape=cloud;whiteSpace=wrap;html=1;",
    "queue": "shape=process;whiteSpace=wrap;html=1;backgroundOutline=1;",
    "decision": "rhombus;whiteSpace=wrap;html=1;",
    "note": "shape=note;whiteSpace=wrap;html=1;size=12;fillColor=#fff2cc;strokeColor=#d6b656;",
}


def flow(spec: dict) -> str:
    doc = _Doc(spec.get("title", "Diagram"))
    nodes = spec.get("nodes", [])
    edges = spec.get("edges", [])
    names = [n["id"] for n in nodes]
    incoming = {n: [e["from"] for e in edges if e.get("to") == n and e.get("from") in names] for n in names}
    layer: dict[str, int] = {}

    def depth(n: str, seen: tuple = ()) -> int:
        if n in layer:
            return layer[n]
        if n in seen:
            return 0
        layer[n] = 0 if not incoming[n] else 1 + max(depth(p, seen + (n,)) for p in incoming[n])
        return layer[n]

    for n in names:
        depth(n)
    right = spec.get("direction", "right") != "down"
    w, h, gl, gi = 160, 64, 90, 40
    slots: dict[int, int] = {}
    pos = {}
    for n in nodes:
        L = layer[n["id"]]
        i = slots.get(L, 0)
        slots[L] = i + 1
        main, cross = L * (w + gl if right else h + gl), i * (h + gi if right else w + gi)
        pos[n["id"]] = (40 + main, 60 + cross) if right else (40 + cross, 60 + main)
    groups: dict[str, list[str]] = {}
    for n in nodes:
        if n.get("group"):
            groups.setdefault(n["group"], []).append(n["id"])
    for gi_, (g, members) in enumerate(groups.items()):
        xs = [pos[m][0] for m in members]
        ys = [pos[m][1] for m in members]
        doc.vertex(g, "rounded=1;whiteSpace=wrap;html=1;dashed=1;fillColor=%s;strokeColor=%s;opacity=60;"
                      "verticalAlign=top;align=left;spacingLeft=8;fontStyle=1;" % (PALETTE[gi_ % 7], STROKE[gi_ % 7]),
                   min(xs) - 20, min(ys) - 34, max(xs) - min(xs) + w + 40, max(ys) - min(ys) + h + 54)
    ids = {}
    for i, n in enumerate(nodes):
        shape = SHAPES.get(n.get("shape", "box"), SHAPES["box"])
        colour = "" if "fillColor" in shape else f"fillColor={PALETTE[i % 7]};strokeColor={STROKE[i % 7]};"
        x, y = pos[n["id"]]
        pw, ph = (40, 70) if n.get("shape") == "person" else (w, h)
        ids[n["id"]] = doc.vertex(n.get("label", n["id"]), shape + colour + "fontSize=12;shadow=1;arcSize=14;", x + (w - pw) / 2, y, pw, ph)
    for e in edges:
        a, b = ids.get(e.get("from")), ids.get(e.get("to"))
        if a and b:
            doc.edge(e.get("label", ""), "edgeStyle=orthogonalEdgeStyle;rounded=1;html=1;fontSize=11;"
                                         "labelBackgroundColor=#ffffff;endArrow=block;endFill=1;"
                                         + ("dashed=1;" if e.get("dashed") else ""), source=a, target=b)
    return doc.xml()


CONTEXT_STYLE = {
    "core": ("#dae8fc", "#6c8ebf", "Core domain"),
    "supporting": ("#d5e8d4", "#82b366", "Supporting"),
    "generic": ("#f5f5f5", "#666666", "Generic"),
}


def context_map(spec: dict) -> str:
    """Bounded contexts as large rounded shapes, coloured by subdomain type, joined by
    relationships labelled with their DDD pattern and U/D direction."""
    doc = _Doc(spec.get("title", "Context map"))
    ctxs = spec.get("contexts", [])
    cols = 1 if len(ctxs) == 1 else (2 if len(ctxs) <= 4 else 3)
    w, h, gx, gy = 280, 170, 300, 120
    ids, cell = {}, {}
    for i, c in enumerate(ctxs):
        col, row = i % cols, i // cols
        fill, stroke, badge = CONTEXT_STYLE.get(str(c.get("type", "core")).lower(), CONTEXT_STYLE["core"])
        aggs = c.get("aggregates", [])
        label = (f"<b style='font-size:15px'>{_esc(c['name'])}</b><br><span style='font-size:10px;color:#555'>"
                 f"{badge} · bounded context</span>")
        if aggs:
            label += "<hr style='border:0;border-top:1px solid #bbb;margin:6px 10px'>" + "<br>".join(
                f"<span style='font-size:11px'>▣ {_esc(a)}</span>" for a in aggs)
        x, y = 40 + col * (w + gx), 40 + row * (h + gy)
        ids[c["name"]] = doc.vertex(label, f"rounded=1;arcSize=18;whiteSpace=wrap;html=1;fillColor={fill};strokeColor={stroke};"
                                           "strokeWidth=2;shadow=1;verticalAlign=top;spacingTop=10;", x, y, w, h)
        cell[c["name"]] = (col, row)
    for r in spec.get("relations", []):
        a, b = ids.get(r.get("upstream")), ids.get(r.get("downstream"))
        if not a or not b:
            continue
        pattern = r.get("pattern", "")
        text = f"<b>U</b> — {_esc(pattern)} — <b>D</b>" + (f"<br><span style='font-size:10px'>{_esc(r['label'])}</span>" if r.get("label") else "")
        (ca, ra), (cb, rb) = cell[r["upstream"]], cell[r["downstream"]]
        ports = ("exitX=1;exitY=0.5;entryX=0;entryY=0.5;" if ca < cb else "exitX=0;exitY=0.5;entryX=1;entryY=0.5;") if ra == rb else (
            "exitX=0.5;exitY=1;entryX=0.5;entryY=0;" if ra < rb else "exitX=0.5;exitY=0;entryX=0.5;entryY=1;")
        doc.edge(text, "edgeStyle=orthogonalEdgeStyle;rounded=1;html=1;fontSize=11;labelBackgroundColor=#ffffff;"
                       "strokeWidth=2;endArrow=block;endFill=1;" + ports, source=a, target=b)
    return doc.xml()


def _class_box(doc: "_Doc", title: str, stereotype: str, fields: list, methods: list, x: float, y: float,
               fill: str, stroke: str, width: float = 230) -> str:
    rows = [f"<i style='font-size:10px'>«{_esc(stereotype)}»</i><br><b>{_esc(title)}</b>"]
    body = "<br>".join(_esc(f) for f in fields) if fields else ""
    ops = "<br>".join(_esc(m) for m in methods) if methods else ""
    label = rows[0] + (f"<hr style='border:0;border-top:1px solid {stroke};margin:4px 0'><div style='text-align:left'>{body}</div>" if body else "") \
        + (f"<hr style='border:0;border-top:1px solid {stroke};margin:4px 0'><div style='text-align:left'>{ops}</div>" if ops else "")
    height = 46 + 16 * len(fields) + 16 * len(methods) + (10 if fields else 0) + (10 if methods else 0)
    return doc.vertex(label, f"rounded=1;arcSize=6;whiteSpace=wrap;html=1;fillColor={fill};strokeColor={stroke};shadow=1;"
                             "verticalAlign=top;spacingTop=6;spacingLeft=8;spacingRight=8;fontSize=11;", x, y, width, height)


def aggregate(spec: dict) -> str:
    """One aggregate: its root, entities and value objects inside the consistency boundary,
    the domain events it raises, and its invariants."""
    doc = _Doc(spec.get("title", "Aggregate"))
    root = spec.get("root", {})
    ents, vals, events = spec.get("entities", []), spec.get("values", []), spec.get("events", [])
    inv = spec.get("invariants", [])
    members = ents + vals
    cols = max(1, min(3, len(members)))
    bw, gap = 230, 40
    inner_w = max(bw, cols * bw + (cols - 1) * gap)
    rows_h = 0
    for r in range((len(members) + cols - 1) // cols):
        row = members[r * cols:(r + 1) * cols]
        rows_h += max(46 + 16 * len(m.get("fields", [])) + 10 for m in row) + gap
    root_h = 46 + 16 * len(root.get("fields", [])) + 16 * len(root.get("methods", [])) + 20
    boundary_h = 40 + root_h + gap + rows_h + 20
    doc.vertex(f"<b>{_esc(root.get('name', 'Aggregate'))} aggregate</b> <span style='font-size:10px'>(consistency boundary)</span>",
               "rounded=1;arcSize=4;whiteSpace=wrap;html=1;dashed=1;dashPattern=8 4;fillColor=#fafafa;strokeColor=#9673a6;"
               "strokeWidth=2;verticalAlign=top;align=left;spacingLeft=12;spacingTop=6;fontSize=12;",
               20, 20, inner_w + 60, boundary_h)
    rid = _class_box(doc, root.get("name", "Root"), "Aggregate Root", root.get("fields", []), root.get("methods", []),
                     50 + (inner_w - bw) / 2, 60, "#e1d5e7", "#9673a6", bw)
    y = 60 + root_h + gap
    for r in range((len(members) + cols - 1) // cols):
        row = members[r * cols:(r + 1) * cols]
        for c, m in enumerate(row):
            is_value = m in vals
            mid = _class_box(doc, m["name"], "Value Object" if is_value else "Entity", m.get("fields", []), [],
                             50 + c * (bw + gap), y, "#d5e8d4" if is_value else "#dae8fc", "#82b366" if is_value else "#6c8ebf", bw)
            doc.edge("", "edgeStyle=orthogonalEdgeStyle;rounded=1;html=1;endArrow=diamondThin;endFill=1;endSize=12;"
                         "exitX=0.5;exitY=0;entryX=0.5;entryY=1;", source=mid, target=rid)
        y += max(46 + 16 * len(m.get("fields", [])) + 10 for m in row) + gap
    side_x = inner_w + 110
    ey = 40
    for e in events:
        eid = doc.vertex(f"<i style='font-size:10px'>«Domain Event»</i><br><b>{_esc(e)}</b>",
                         "rounded=1;whiteSpace=wrap;html=1;fillColor=#ffe6cc;strokeColor=#d79b00;shadow=1;fontSize=11;",
                         side_x, ey, 200, 50)
        doc.edge("raises", "edgeStyle=orthogonalEdgeStyle;rounded=1;html=1;dashed=1;fontSize=10;endArrow=open;"
                           "labelBackgroundColor=#ffffff;exitX=1;exitY=0.5;entryX=0;entryY=0.5;", source=rid, target=eid)
        ey += 70
    if inv:
        text = "<b>Invariants</b><br>" + "<br>".join("• " + _esc(i) for i in inv)
        doc.vertex(text, "shape=note;whiteSpace=wrap;html=1;size=12;fillColor=#fff2cc;strokeColor=#d6b656;align=left;"
                         "verticalAlign=top;spacingLeft=8;spacingTop=6;fontSize=11;",
                   side_x, max(ey, 40) + 10, 240, 30 + 18 * len(inv))
    return doc.xml()


KINDS = {"sequence": sequence, "er": er, "flow": flow, "context-map": context_map, "aggregate": aggregate}


def render(kind: str, spec: dict | str) -> str:
    if isinstance(spec, str):
        spec = json.loads(spec)
    if kind not in KINDS:
        raise ValueError(f"unknown diagram kind: {kind} (expected {', '.join(KINDS)})")
    return KINDS[kind](spec)


def write(kind: str, spec: dict | str, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(render(kind, spec), encoding="utf-8")
    return path
