"""Compliance policy packs: HIPAA, PCI DSS, SOC 2, GDPR.

A pack is data, not code: a YAML file naming the tool guardrails the hook
should enforce, the tenets and standards rows the governance trio gains, and
the deterministic checks the build must pass. Applying a pack writes those into
`spar/` between markers so it can be removed as cleanly as it was added.

Every pack says so in its header, and it bears repeating here: a pack is a
starting point for a regulated engagement, not a certification of one.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

from .checks import checks_config_path, load_checks_config, render_checks_yaml
from .cli import DATA, parse_simple_yaml

SCHEMA = "spar.packs/v1"
PACKS_SRC = DATA / "packs"


def packs_path(spar_root: Path) -> Path:
    return spar_root / "packs.json"


def load_packs() -> list[dict]:
    out = []
    if not PACKS_SRC.is_dir():
        return out
    for p in sorted(PACKS_SRC.glob("*.yaml")):
        try:
            data = parse_simple_yaml(p.read_text(encoding="utf-8")) or {}
        except (OSError, ValueError):
            continue
        if not isinstance(data, dict) or not data.get("id"):
            continue
        data.setdefault("guardrails", [])
        data.setdefault("tenets", [])
        data.setdefault("standards_rows", [])
        data.setdefault("checks", [])
        out.append(data)
    return out


def pack(pack_id: str) -> dict | None:
    return next((p for p in load_packs() if p["id"] == pack_id), None)


def selected(spar_root: Path) -> list[str]:
    p = packs_path(spar_root)
    if not p.is_file():
        return []
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    sel = data.get("selected") if isinstance(data, dict) else None
    return [s for s in sel if isinstance(s, str)] if isinstance(sel, list) else []


def _write_selected(spar_root: Path, ids: list[str]) -> None:
    spar_root.mkdir(parents=True, exist_ok=True)
    packs_path(spar_root).write_text(
        json.dumps({"schema": SCHEMA, "selected": ids}, indent=2) + "\n", encoding="utf-8"
    )


def summary(spar_root: Path | None) -> dict:
    """The `spar packs list --json` payload."""
    sel = selected(spar_root) if spar_root else []
    return {
        "schema": SCHEMA,
        "selected": sel,
        "available": [
            {
                "id": p["id"],
                "name": p.get("name", p["id"]),
                "summary": p.get("summary", ""),
                "disclaimer": p.get("disclaimer", ""),
                "guardrails": p["guardrails"],
                "checks": p["checks"],
                "tenets": len(p["tenets"]),
                "standards_rows": len(p["standards_rows"]),
            }
            for p in load_packs()
        ],
    }


def guardrails(spar_root: Path | None) -> list[dict]:
    """The union of every selected pack's guardrails, each tagged with its pack."""
    sel = selected(spar_root) if spar_root else []
    out = []
    for p in load_packs():
        if p["id"] not in sel:
            continue
        for g in p["guardrails"]:
            if not isinstance(g, dict) or not g.get("match"):
                continue
            out.append(
                {
                    "action": str(g.get("action") or "deny"),
                    "match": str(g["match"]),
                    "why": str(g.get("why") or ""),
                    "pack": p["id"],
                }
            )
    return out


# --------------------------------------------------------------------------- #
# Marker blocks in the governance trio
# --------------------------------------------------------------------------- #


def _block_re(pack_id: str) -> re.Pattern:
    pid = re.escape(pack_id)
    return re.compile(rf"\n?<!-- pack:{pid} -->\n.*?<!-- /pack:{pid} -->\n?", re.S)


def _strip_block(text: str, pack_id: str) -> str:
    return _block_re(pack_id).sub("\n", text).rstrip("\n") + "\n" if text.strip() else ""


def _render_tenets(p: dict) -> str:
    lines = [f"<!-- pack:{p['id']} -->", f"<!-- {p.get('name', p['id'])} pack. {p.get('disclaimer', '')} -->", ""]
    for t in p["tenets"]:
        if not isinstance(t, dict):
            continue
        lines.append(f"## {t.get('id', 'T-?')} · {t.get('title', '')}".rstrip(" ·"))
        lines.append("")
        lines.append(f"- **Stance.** {t.get('stance', '')}")
        lines.append(f"- **Why.** {t.get('why', '')}")
        lines.append(f"- **How to apply.** {t.get('apply', '')}")
        lines.append("")
    lines.append(f"<!-- /pack:{p['id']} -->")
    return "\n".join(lines) + "\n"


def _render_standards(p: dict) -> str:
    lines = [
        f"<!-- pack:{p['id']} -->",
        f"## Pack: {p.get('name', p['id'])}",
        "",
        f"<!-- {p.get('disclaimer', '')} -->",
        "",
        "| # | Required artifact | Applies when | Verified by | Blocking |",
        "| --- | --- | --- | --- | --- |",
    ]
    for r in p["standards_rows"]:
        if not isinstance(r, dict):
            continue
        blocking = r.get("blocking", True)
        blocking = "yes" if (blocking is True or str(blocking).lower() in ("yes", "true")) else "no"
        lines.append(
            f"| {r.get('id', '')} | {r.get('artifact', '')} | {r.get('applies_when', 'always')} | {r.get('verified_by', '')} | {blocking} |"
        )
    lines.append("")
    lines.append(f"<!-- /pack:{p['id']} -->")
    return "\n".join(lines) + "\n"


def _upsert_block(path: Path, pack_id: str, block: str, header: str) -> None:
    text = path.read_text(encoding="utf-8") if path.is_file() else header
    text = _strip_block(text, pack_id)
    if text and not text.endswith("\n"):
        text += "\n"
    text = text + "\n" + block
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _remove_block(path: Path, pack_id: str) -> None:
    if not path.is_file():
        return
    path.write_text(_strip_block(path.read_text(encoding="utf-8"), pack_id), encoding="utf-8")


# --------------------------------------------------------------------------- #
# checks.yaml merge
# --------------------------------------------------------------------------- #


def _merge_checks(spar_root: Path, p: dict | None, pack_id: str) -> None:
    cfg = load_checks_config(spar_root) or {}
    existing = [c for c in (cfg.get("checks") or []) if isinstance(c, dict)]
    kept = [c for c in existing if c.get("pack") != pack_id]
    if p is not None:
        names = {c.get("name") for c in kept}
        for c in p["checks"]:
            if not isinstance(c, dict) or not c.get("run"):
                continue
            entry = {
                "name": c.get("name", "check"),
                "run": c["run"],
                "required": c.get("required", True),
                "pack": pack_id,
            }
            if c.get("needs_tool"):
                entry["needs_tool"] = c["needs_tool"]
            if c.get("timeout_seconds"):
                entry["timeout_seconds"] = c["timeout_seconds"]
            if entry["name"] in names:
                kept = [k for k in kept if k.get("name") != entry["name"]]
            kept.append(entry)
    if not kept and not checks_config_path(spar_root).is_file():
        return
    checks_config_path(spar_root).write_text(
        render_checks_yaml(kept, int(cfg.get("timeout_seconds") or 600)), encoding="utf-8"
    )


# --------------------------------------------------------------------------- #
# apply / remove
# --------------------------------------------------------------------------- #

TENETS_HEADER = "# Engineering Tenets\n\n**Version:** 1.0.0 · **Status:** DRAFT — requires review before enforcement\n"
STANDARDS_HEADER = "# Required Scaffolding Standards\n\n**Version:** 1.0.0 · **Status:** DRAFT — requires review\n"


def apply(spar_root: Path, ids: list[str]) -> list[str]:
    """Apply packs idempotently. Returns the ids that were unknown."""
    unknown = []
    sel = selected(spar_root)
    for pid in ids:
        p = pack(pid)
        if p is None:
            unknown.append(pid)
            continue
        _upsert_block(spar_root / "tenets.md", pid, _render_tenets(p), TENETS_HEADER)
        _upsert_block(spar_root / "standards.md", pid, _render_standards(p), STANDARDS_HEADER)
        _merge_checks(spar_root, p, pid)
        if pid not in sel:
            sel.append(pid)
    _write_selected(spar_root, sel)
    return unknown


def remove(spar_root: Path, ids: list[str]) -> None:
    sel = [s for s in selected(spar_root) if s not in ids]
    for pid in ids:
        _remove_block(spar_root / "tenets.md", pid)
        _remove_block(spar_root / "standards.md", pid)
        _merge_checks(spar_root, None, pid)
    _write_selected(spar_root, sel)
