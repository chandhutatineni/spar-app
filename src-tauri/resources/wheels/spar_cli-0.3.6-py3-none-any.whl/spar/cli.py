"""SPAR command-line interface.

Zero third-party dependencies -- standard library only. Every path that touches
the filesystem is confined to a discovered ``spar/`` root or the user's
``~/.claude/`` install directory.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from . import __version__

# --------------------------------------------------------------------------- #
# Paths & constants
# --------------------------------------------------------------------------- #

DATA = Path(__file__).resolve().parent / "data"
AGENTS_SRC = DATA / "agents"
COMMANDS_SRC = DATA / "commands"
TEMPLATES_SRC = DATA / "templates"
# The steps the phase commands run (specify, plan, tasks, …). Not slash commands.
STEPS_SRC = DATA / "steps"
CONNECTORS_SRC = DATA / "connectors"

CLAUDE_DIR = Path.home() / ".claude"
AGENTS_DST = CLAUDE_DIR / "agents"
COMMANDS_DST = CLAUDE_DIR / "commands"
TEMPLATES_LINK = CLAUDE_DIR / "spar-templates"
STEPS_LINK = CLAUDE_DIR / "spar-steps"
SETTINGS = CLAUDE_DIR / "settings.json"

HOOK_MARKER = "spar-artifact-review"
SPAR_DIR_NAME = "spar"
# Projects created before the rename keep their artifacts in spar/.
LEGACY_DIR_NAME = ".spar"
# Files that mark a folder as a SPAR workspace (a plain "spar" folder, such as
# SPAR's own source, is not one).
WORKSPACE_MARKERS = ("specs", "tenets.md", "standards.md", "manifest.json", "decisions.jsonl", "briefs")


def is_workspace(path: Path) -> bool:
    return path.is_dir() and any((path / m).exists() for m in WORKSPACE_MARKERS)


def workspace_in(root: Path) -> Path | None:
    """The SPAR workspace directly inside *root*: spar/, else legacy spar/."""
    if is_workspace(root / SPAR_DIR_NAME):
        return root / SPAR_DIR_NAME
    if (root / LEGACY_DIR_NAME).is_dir():
        return root / LEGACY_DIR_NAME
    return None
ZERO_HASH = "0" * 64

ROLES = (
    "docs",
    "issues",
    "scm",
    "ci",
    "db",
    "catalog",
    "observability",
    "security",
    "assistant",
    "cloud",
)

PHASE_ORDER = ["empty", "specified", "planned", "tasks-ready", "building", "verified"]

# --------------------------------------------------------------------------- #
# Output helpers
# --------------------------------------------------------------------------- #

_NO_COLOR = bool(os.environ.get("NO_COLOR")) or not sys.stdout.isatty()


def _c(text: str, code: str) -> str:
    if _NO_COLOR:
        return text
    return f"\033[{code}m{text}\033[0m"


def bold(t: str) -> str:
    return _c(t, "1")


def green(t: str) -> str:
    return _c(t, "32")


def red(t: str) -> str:
    return _c(t, "31")


def yellow(t: str) -> str:
    return _c(t, "33")


def cyan(t: str) -> str:
    return _c(t, "36")


def dim(t: str) -> str:
    return _c(t, "2")


def ok(msg: str) -> None:
    print(f"{green('✓')} {msg}")


def bad(msg: str) -> None:
    print(f"{red('✗')} {msg}")


def warn(msg: str) -> None:
    print(f"{yellow('!')} {msg}")


def info(msg: str) -> None:
    print(f"{cyan('·')} {msg}")


def head(msg: str) -> None:
    print(f"\n{bold(msg)}")


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


# --------------------------------------------------------------------------- #
# Root discovery
# --------------------------------------------------------------------------- #


def find_git_root(start: Path | None = None) -> Path | None:
    """Return the git top-level directory, or None."""
    cwd = str(start or Path.cwd())
    try:
        out = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=10,
        )
        if out.returncode == 0 and out.stdout.strip():
            return Path(out.stdout.strip())
    except (OSError, subprocess.SubprocessError):
        pass
    return None


def find_spar_root(start: Path | None = None) -> Path | None:
    """Walk up from *start* looking for a ``spar/`` directory.

    ``SPAR_ROOT`` wins when set: a host that runs the CLI or the MCP server for a
    specific checkout (the SPAR app, building a feature in a git worktree) names it
    outright, because a process whose cwd is decided by someone else can walk up
    from the wrong place. That is how one feature's ledger forked into two
    chains once — agents in the worktree and the MCP server in the main
    checkout each appending their own entry 15.
    """
    pinned = os.environ.get("SPAR_ROOT")
    if pinned and start is None:
        base = Path(pinned).expanduser()
        if base.name in (SPAR_DIR_NAME, LEGACY_DIR_NAME) and (is_workspace(base) or base.name == LEGACY_DIR_NAME and base.is_dir()):
            return base
        found = workspace_in(base)
        if found:
            return found
    cur = (start or Path.cwd()).resolve()
    for candidate in [cur, *cur.parents]:
        sp = workspace_in(candidate)
        if sp:
            return sp
    return None


def require_spar_root() -> Path:
    root = find_spar_root()
    if root is None:
        bad(f"No {SPAR_DIR_NAME}/ directory found in this directory or any parent.")
        info("Run /spar.init \"<what you want to build>\" in Claude Code or the SPAR app, or `spar init` here.")
        raise SystemExit(1)
    return root


def _confined(root: Path, target: Path) -> bool:
    """True when *target* resolves inside *root*. Path-traversal guard."""
    try:
        root_r = root.resolve()
        target_r = target.resolve()
    except OSError:
        return False
    return root_r == target_r or root_r in target_r.parents


# --------------------------------------------------------------------------- #
# Minimal config parsing (JSON, or a tiny YAML subset -- no PyYAML)
# --------------------------------------------------------------------------- #


def parse_simple_yaml(text: str):
    """Parse the small YAML subset SPAR config needs.

    Supports nested mappings by indentation, lists of scalars, and lists of
    mappings introduced by ``- key: value``. Values are strings unless they look
    like a bool, int or null. Comments and blank lines are ignored. Anything more
    exotic is unsupported on purpose -- use JSON instead.
    """

    def scalar(raw: str):
        v = raw.strip()
        if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
            return v[1:-1]
        low = v.lower()
        if low in ("true", "yes"):
            return True
        if low in ("false", "no"):
            return False
        if low in ("null", "~", ""):
            return None
        try:
            return int(v)
        except ValueError:
            pass
        try:
            return float(v)
        except ValueError:
            pass
        return v

    root: dict = {}
    # stack of (indent, container, pending_key)
    stack: list = [(-1, root)]
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        raw = lines[i]
        i += 1
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        indent = len(raw) - len(raw.lstrip(" "))
        line = raw.strip()

        while len(stack) > 1 and indent <= stack[-1][0]:
            stack.pop()
        container = stack[-1][1]

        if line.startswith("- "):
            item = line[2:].strip()
            if not isinstance(container, list):
                continue
            if ":" in item and not item.startswith(("\"", "'")):
                k, _, v = item.partition(":")
                obj = {k.strip(): scalar(v)}
                container.append(obj)
                stack.append((indent, obj))
            else:
                container.append(scalar(item))
            continue

        if ":" not in line:
            continue
        key, _, val = line.partition(":")
        key = key.strip()
        val = val.strip()
        if not isinstance(container, dict):
            continue
        if val == "":
            # Look ahead to decide list vs mapping.
            nxt = None
            for j in range(i, len(lines)):
                if lines[j].strip() and not lines[j].lstrip().startswith("#"):
                    nxt = lines[j]
                    break
            child: object
            if nxt is not None and nxt.strip().startswith("- ") and (
                len(nxt) - len(nxt.lstrip(" "))
            ) >= indent:
                child = []
            else:
                child = {}
            container[key] = child
            stack.append((indent, child))
        else:
            container[key] = scalar(val)
    return root


def load_config_file(path: Path):
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() == ".json":
        return json.loads(text)
    return parse_simple_yaml(text)


REGISTRY_CANDIDATES = (
    "org-registry.yaml",
    "org-registry.yml",
    "org-registry.json",
)


def host_config_dir() -> Path:
    """Where this host keeps organisation-level state: registry, policy, extra
    connectors, credentials, access. ``SPAR_HOME`` relocates all of it together,
    which is how the test suite stays clear of a real installation."""
    override = os.environ.get("SPAR_HOME")
    if override:
        return Path(override).expanduser()
    return Path.home() / ".config" / "spar"


def registry_search_paths(explicit: str | None) -> list[Path]:
    paths: list[Path] = []
    if explicit:
        paths.append(Path(explicit).expanduser())
        return paths
    env = os.environ.get("SPAR_ORG_REGISTRY")
    if env:
        paths.append(Path(env).expanduser())
    spar_root = find_spar_root()
    if spar_root:
        paths.extend(spar_root / n for n in REGISTRY_CANDIDATES)
    paths.extend(host_config_dir() / n for n in REGISTRY_CANDIDATES)
    return paths


REGISTRY_SCHEMA_HELP = """\
Expected org registry (placeholders only -- never commit real secrets):

  # spar/org-registry.yaml
  bridge: <optional-cli-that-proxies-authenticated-mcp>
  scope: user
  connectors:
    - use: confluence            # a connector id from `spar connectors list`
      host: <confluence-mcp-host>
      token_env: CONFLUENCE_TOKEN
    - use: github
      host: api.github.com
      token_env: GITHUB_TOKEN
    - use: postgres
      dsn_env: WAREHOUSE_DSN
      readonly: true

Run `spar connectors list` to see every prebuilt connector and the config keys
each one needs. Secrets are read from environment variables at run time; SPAR
never stores or logs their values."""


def load_registry(explicit: str | None) -> tuple[dict | None, Path | None, list[Path]]:
    tried = registry_search_paths(explicit)
    for p in tried:
        if p.is_file():
            try:
                return load_config_file(p) or {}, p, tried
            except (OSError, ValueError, json.JSONDecodeError) as exc:
                bad(f"Could not parse {p}: {exc}")
                raise SystemExit(1)
    return None, None, tried


# --------------------------------------------------------------------------- #
# Connector catalog
# --------------------------------------------------------------------------- #


def connector_dirs() -> list[Path]:
    """Catalog search path: shipped, then user, then project (later wins)."""
    dirs = [CONNECTORS_SRC, host_config_dir() / "connectors"]
    spar_root = find_spar_root()
    if spar_root:
        dirs.append(spar_root / "connectors")
    return [d for d in dirs if d.is_dir()]


def load_catalog() -> dict[str, dict]:
    catalog: dict[str, dict] = {}
    for d in connector_dirs():
        for f in sorted(d.glob("*.json")):
            try:
                spec = json.loads(f.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as exc:
                warn(f"skipping malformed connector {f.name}: {exc}")
                continue
            cid = spec.get("id") or f.stem
            spec["id"] = cid
            spec["_source"] = str(f)
            catalog[cid] = spec
    return catalog


CONNECTIONS_FILE = "connections.json"


def load_project_selection(spar_root: Path | None) -> set[str] | None:
    """The developer's per-project choice of which org connectors to use.

    Returns None when no selection exists, which means "use everything the
    organisation has enabled". An empty set means the developer deliberately
    selected nothing.
    """
    if not spar_root:
        return None
    path = spar_root / CONNECTIONS_FILE
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8")) or {}
    except (OSError, json.JSONDecodeError):
        return None
    sel = data.get("selected")
    if not isinstance(sel, list):
        return None
    return {str(s) for s in sel}


def save_project_selection(spar_root: Path, selected: list[str]) -> Path:
    spar_root.mkdir(parents=True, exist_ok=True)
    path = spar_root / CONNECTIONS_FILE
    path.write_text(
        json.dumps({"schema": "spar.connections/v1", "selected": sorted(set(selected))}, indent=2)
        + "\n",
        encoding="utf-8",
    )
    return path


def org_enabled(entry: dict) -> bool:
    """A control-plane admin may stage a connector without enabling it."""
    val = entry.get("enabled", True)
    return val is not False and str(val).lower() not in ("false", "no", "0")


def resolve_connectors(
    registry: dict | None,
    *,
    selection: set[str] | None = None,
    include_disabled: bool = False,
) -> list[dict]:
    """Merge the shipped catalog with the org registry, then apply both tiers.

    Tier 1 (organisation, set in the control plane): ``enabled`` on each entry.
    Tier 2 (developer, per project): ``spar/connections.json``.

    A connector must clear both to be usable. Pass ``include_disabled=True`` to get
    everything with an ``availability`` field explaining each exclusion -- the control
    plane and the gateway's diagnostics both need that.
    """
    catalog = load_catalog()
    out: list[dict] = []
    if not registry:
        return out
    entries = registry.get("connectors") or registry.get("servers") or []
    if not isinstance(entries, list):
        return out
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        cid = entry.get("use") or entry.get("connector") or entry.get("name")
        spec = dict(catalog.get(cid, {})) if cid else {}
        if not spec:
            # Unknown connector: treat the entry itself as an ad-hoc definition.
            spec = {
                "id": cid or "custom",
                "name": cid or "custom",
                "role": entry.get("role", "docs"),
                "transport": "http" if entry.get("url") else "stdio",
                "adhoc": True,
            }
        merged = dict(spec)
        merged["config_values"] = {k: v for k, v in entry.items() if k not in ("use", "connector")}
        if entry.get("role"):
            merged["role"] = entry["role"]
        if entry.get("name") and not spec.get("adhoc"):
            merged["alias"] = entry["name"]

        label = merged.get("alias") or merged["id"]
        if not org_enabled(entry):
            merged["availability"] = "not-enabled-by-org"
        elif selection is not None and label not in selection and merged["id"] not in selection:
            merged["availability"] = "not-selected-for-project"
        else:
            merged["availability"] = "available"

        if merged["availability"] != "available" and not include_disabled:
            continue
        out.append(merged)
    return out


def active_connectors(registry: dict | None, spar_root: Path | None) -> list[dict]:
    """Connectors that clear both tiers for the project at *spar_root*."""
    return resolve_connectors(registry, selection=load_project_selection(spar_root))


def _substitute(text: str, mapping: dict) -> str:
    """Replace {key} placeholders, leaving unknown ones untouched.

    Deliberately not str.format: a command template may reference a placeholder the
    operator has not supplied, and raising KeyError there would take down anything
    that merely wants to *display* the endpoint.
    """
    for key, val in mapping.items():
        if isinstance(val, (str, int)):
            text = text.replace("{" + key + "}", str(val))
    return text


def endpoint_mapping(conn: dict, resolve_secrets: bool = False) -> dict:
    """Placeholder values for a connector's endpoint template.

    A ``*_env`` config field names an environment variable. The matching placeholder
    is the field without that suffix -- so ``dsn_env: WAREHOUSE_DSN`` fills ``{dsn}``.
    With ``resolve_secrets`` the real value comes from the organisation credential
    store on this host (falling back to the environment); without it the variable
    name is shown instead, so no credential can reach a UI or a log.
    """
    values = dict(conn.get("config_values", {}) or {})
    mapping = {k: v for k, v in values.items() if isinstance(v, (str, int))}
    for key, val in list(values.items()):
        if key.endswith("_env") and isinstance(val, str) and val:
            base = key[: -len("_env")]
            if base in mapping and mapping[base]:
                continue
            if resolve_secrets:
                from .vault import resolve as resolve_secret

                mapping[base] = resolve_secret(conn.get("id", ""), val) or ""
            else:
                mapping[base] = "$" + val
    return mapping


def connector_endpoint(conn: dict, resolve_secrets: bool = False) -> tuple[str, object]:
    """Return (transport, endpoint) where endpoint is a URL or an argv list."""
    mapping = endpoint_mapping(conn, resolve_secrets)
    transport = conn.get("transport", "http")
    if transport == "http":
        url = (conn.get("config_values") or {}).get("url") or conn.get("url_template", "")
        return "http", _substitute(str(url), mapping)
    argv = [
        _substitute(a, mapping) if ("{" in a and "}" in a) else a
        for a in (conn.get("command") or [])
    ]
    return "stdio", argv


def missing_config(conn: dict) -> list[str]:
    required = [f["key"] for f in conn.get("config", []) if f.get("required", True)]
    have = conn.get("config_values", {}) or {}
    return [k for k in required if not have.get(k)]


# --------------------------------------------------------------------------- #
# Decision ledger (AEGIS convergence surface)
# --------------------------------------------------------------------------- #


def decisions_path(spar_root: Path) -> Path:
    return spar_root / "decisions.jsonl"


def _record_hash(record: dict) -> str:
    payload = {k: v for k, v in record.items() if k != "hash"}
    blob = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def read_decisions(spar_root: Path) -> list[dict]:
    path = decisions_path(spar_root)
    if not path.is_file():
        return []
    out = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError:
            out.append({"_malformed": line})
    return out


class HumanRequired(RuntimeError):
    """A human decision was attempted by something that is not demonstrably a person."""


def _human_token_file() -> Path:
    # Overridable only so the test suites can run without a real terminal.
    return Path(os.environ.get("SPAR_HUMAN_TOKEN_FILE") or (Path.home() / ".config" / "spar" / "human-token"))


def human_present() -> bool:
    """A person is deciding: an interactive terminal, or the SPAR app (which passes a
    per-launch token only to the commands it runs for the person — never to agents)."""
    try:
        if sys.stdin.isatty() and sys.stdout.isatty():
            return True
    except (ValueError, OSError):
        pass
    token = os.environ.get("SPAR_HUMAN_TOKEN", "")
    f = _human_token_file()
    if token and f.is_file():
        known = {l.strip() for l in f.read_text(encoding="utf-8").splitlines() if l.strip()}
        return hashlib.sha256(token.encode()).hexdigest() in known
    return False


def append_decision(
    spar_root: Path,
    *,
    subject: dict,
    action: dict,
    resource: dict,
    context: dict,
    verdict: str,
    explanation: str = "",
) -> dict:
    """Append one hash-chained decision record. This is the AEGIS seam.

    A record claiming a human decided is only written when a person is present
    (`human_present`): an agent can never approve a gate, pick an MVP or answer a
    platform question in someone's name.
    """
    if (subject or {}).get("kind") == "human" and not human_present():
        raise HumanRequired(
            "Only a person can record this decision: use the buttons in the SPAR app, or run the command "
            "yourself in a terminal. Agents record their own findings with --subject-kind agent."
        )
    existing = read_decisions(spar_root)
    prev = existing[-1] if existing else None
    prev_hash = (prev or {}).get("hash") or ZERO_HASH
    record = {
        "seq": len(existing) + 1,
        "at": now_iso(),
        "subject": subject,
        "action": action,
        "resource": resource,
        "context": context,
        "verdict": verdict,
        "explanation": explanation,
        "prev_hash": prev_hash,
    }
    record["hash"] = _record_hash(record)
    spar_root.mkdir(parents=True, exist_ok=True)
    with decisions_path(spar_root).open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(record, separators=(",", ":")) + "\n")
    return record


def verify_chain(spar_root: Path) -> tuple[bool, str]:
    records = read_decisions(spar_root)
    if not records:
        return True, "no decisions recorded yet"
    prev_hash = ZERO_HASH
    for idx, rec in enumerate(records, start=1):
        if "_malformed" in rec:
            return False, f"line {idx} is not valid JSON"
        if rec.get("prev_hash") != prev_hash:
            return False, f"line {idx} prev_hash does not match line {idx - 1}"
        if rec.get("hash") != _record_hash(rec):
            return False, f"line {idx} hash does not match its contents (record altered)"
        prev_hash = rec["hash"]
    return True, f"{len(records)} decisions, chain intact"


# --------------------------------------------------------------------------- #
# Read-only spar/ scanner -- shared by status, metrics, dashboard, export
# --------------------------------------------------------------------------- #

ARTIFACT_ORDER = [
    "spec.md",
    "research.md",
    "plan.md",
    "data-model.md",
    "threat-model.md",
    "diagram.md",
    "tasks.md",
    "build-log.md",
    "verification.md",
    "retro.md",
]

TASK_LINE = re.compile(r"^\s*[-*]\s*\[( |x|X)\]")
TASK_ID_LINE = re.compile(r"^\s*[-*]\s*\[( |x|X)\]\s*T\d{3}\b")
CHECKPOINT = re.compile(r"checkpoint", re.IGNORECASE)
FINDING = re.compile(r"\b(BLOCKING|IMPORTANT|NIT|WARNING|INFO)\b\s*[:\-]\s*(.{0,80})")
# Tolerate markdown emphasis around the label and the separator, since specs are
# written by hand: `risk_tier: high`, `**risk_tier:** high`, `**risk_tier**: high`.
RISK_TIER = re.compile(r"risk[_ -]?tier\**\s*[:=]\**\s*\**\s*([A-Za-z-]+)", re.IGNORECASE)


def infer_phase(feature_dir: Path) -> str:
    for name, phase in (
        ("verification.md", "verified"),
        ("build-log.md", "building"),
        ("tasks.md", "tasks-ready"),
        ("plan.md", "planned"),
        ("spec.md", "specified"),
    ):
        if (feature_dir / name).is_file():
            return phase
    return "empty"


def scan_feature(feature_dir: Path) -> dict:
    artifacts = {}
    for name in ARTIFACT_ORDER:
        p = feature_dir / name
        if p.is_file():
            artifacts[name] = str(p)
    contracts = sorted(str(p) for p in (feature_dir / "contracts").glob("*.md")) if (
        feature_dir / "contracts"
    ).is_dir() else []
    checklists = sorted(str(p) for p in (feature_dir / "checklists").glob("*.md")) if (
        feature_dir / "checklists"
    ).is_dir() else []

    total = done = checkpoints = converge = legacy = 0
    tasks_md = feature_dir / "tasks.md"
    if tasks_md.is_file():
        lines = tasks_md.read_text(encoding="utf-8", errors="replace").splitlines()
        # The template puts one countable `- [ ] T001` per task and nests the
        # definition-of-done checkboxes under the task. Counting every checkbox
        # reported 120 tasks for a 20-task feature, so when task-id checkboxes
        # exist only those count; the plain count remains for older files.
        matcher = TASK_ID_LINE if any(TASK_ID_LINE.match(l) for l in lines) else TASK_LINE
        for line in lines:
            m = matcher.match(line)
            if m:
                total += 1
                if m.group(1).lower() == "x":
                    done += 1
            if CHECKPOINT.search(line):
                checkpoints += 1
            if "[CONVERGE]" in line:
                converge += 1
            if "[LEGACY]" in line:
                legacy += 1

    findings: dict[str, int] = {}
    build_log = feature_dir / "build-log.md"
    if build_log.is_file():
        for line in build_log.read_text(encoding="utf-8", errors="replace").splitlines():
            m = FINDING.search(line)
            if m:
                key = m.group(1).upper()
                findings[key] = findings.get(key, 0) + 1

    verification = {"status": "none"}
    ver = feature_dir / "verification.md"
    if ver.is_file():
        text = ver.read_text(encoding="utf-8", errors="replace")
        low = text.lower()
        if "fail" in low or "blocked" in low:
            verification["status"] = "fail"
        elif "pass" in low:
            verification["status"] = "pass"
        else:
            verification["status"] = "unknown"
        m = re.search(r"(\d+)\s+tests?\s+(?:run|passed)", low)
        if m:
            verification["tests_run"] = int(m.group(1))

    risk_tier = "unset"
    spec = feature_dir / "spec.md"
    if spec.is_file():
        m = RISK_TIER.search(spec.read_text(encoding="utf-8", errors="replace"))
        if m:
            risk_tier = m.group(1).lower()

    return {
        "id": feature_dir.name,
        "phase": infer_phase(feature_dir),
        "risk_tier": risk_tier,
        "artifacts": artifacts,
        "contracts": contracts,
        "checklists": checklists,
        "tasks_total": total,
        "tasks_done": done,
        "task_completion": round(done / total, 4) if total else 0.0,
        "checkpoints": checkpoints,
        "converge_tasks": converge,
        "legacy_tasks": legacy,
        "findings": findings,
        "verification": verification,
    }


def scan_spar(spar_root: Path) -> dict:
    specs = spar_root / "specs"
    features = []
    if specs.is_dir():
        for d in sorted(p for p in specs.iterdir() if p.is_dir()):
            features.append(scan_feature(d))
    trio = {
        name: (spar_root / f"{name}.md").is_file()
        for name in ("tenets", "standards", "references")
    }
    return {
        "root": str(spar_root),
        "project": spar_root.parent.name,
        "governance": trio,
        "features": features,
    }


def portfolio(scan: dict) -> dict:
    feats = scan["features"]
    n = len(feats)
    by_phase: dict[str, int] = {}
    for f in feats:
        by_phase[f["phase"]] = by_phase.get(f["phase"], 0) + 1
    total_tasks = sum(f["tasks_total"] for f in feats)
    done_tasks = sum(f["tasks_done"] for f in feats)
    findings: dict[str, int] = {}
    for f in feats:
        for k, v in f["findings"].items():
            findings[k] = findings.get(k, 0) + v
    return {
        "features": n,
        "by_phase": by_phase,
        "avg_completion": round(sum(f["task_completion"] for f in feats) / n, 4) if n else 0.0,
        "tasks_total": total_tasks,
        "tasks_done": done_tasks,
        "verified": sum(1 for f in feats if f["verification"]["status"] == "pass"),
        "findings": findings,
        "converge_tasks": sum(f["converge_tasks"] for f in feats),
        "legacy_tasks": sum(f["legacy_tasks"] for f in feats),
    }


def write_manifest(spar_root: Path) -> Path:
    """Regenerate spar/manifest.json -- machine-readable feature registry."""
    scan = scan_spar(spar_root)
    manifest = {
        "schema": "spar.manifest/v1",
        "generated_at": now_iso(),
        "project": scan["project"],
        "governance": {
            "tenets": scan["governance"]["tenets"],
            "standards": scan["governance"]["standards"],
            "references": scan["governance"]["references"],
        },
        "features": [
            {
                "id": f["id"],
                "phase": f["phase"],
                "risk_tier": f["risk_tier"],
                "task_completion": f["task_completion"],
                "artifacts": {k.replace(".md", ""): v for k, v in f["artifacts"].items()},
                "verification": f["verification"],
            }
            for f in scan["features"]
        ],
        "portfolio": portfolio(scan),
    }
    path = spar_root / "manifest.json"
    path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return path


# --------------------------------------------------------------------------- #
# install / uninstall / status
# --------------------------------------------------------------------------- #


def _link_or_copy(src: Path, dst: Path, copy: bool) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.is_symlink() or dst.exists():
        dst.unlink()
    if copy:
        shutil.copy2(src, dst)
    else:
        dst.symlink_to(src)


def _prune_stale(dst_dir: Path, prefix: str, valid: set[str]) -> int:
    removed = 0
    if not dst_dir.is_dir():
        return 0
    for p in dst_dir.iterdir():
        if p.name.startswith(prefix) and p.name.endswith(".md") and p.name not in valid:
            p.unlink()
            removed += 1
    return removed


def cmd_install(args) -> int:
    project = bool(args.project)
    base = Path.cwd() / ".claude" if project else CLAUDE_DIR
    if project and not (Path.cwd() / ".git").exists():
        warn("cwd does not look like a repository root -- installing here anyway.")

    agents_dst = base / "agents"
    commands_dst = base / "commands"
    templates_dst = base / ("spar-templates" if not project else "spar-templates")

    agents = sorted(AGENTS_SRC.glob("spar-*.md"))
    commands = sorted(COMMANDS_SRC.glob("spar.*.md"))

    for f in agents:
        _link_or_copy(f, agents_dst / f.name, copy=project)
    for f in commands:
        _link_or_copy(f, commands_dst / f.name, copy=project)

    stale = _prune_stale(agents_dst, "spar-", {f.name for f in agents})
    stale += _prune_stale(commands_dst, "spar.", {f.name for f in commands})

    if templates_dst.is_symlink() or templates_dst.exists():
        if templates_dst.is_dir() and not templates_dst.is_symlink():
            shutil.rmtree(templates_dst)
        else:
            templates_dst.unlink()
    if project:
        shutil.copytree(TEMPLATES_SRC, templates_dst)
    else:
        templates_dst.parent.mkdir(parents=True, exist_ok=True)
        templates_dst.symlink_to(TEMPLATES_SRC, target_is_directory=True)

    steps_dst = base / "spar-steps"
    if steps_dst.is_symlink() or steps_dst.exists():
        if steps_dst.is_dir() and not steps_dst.is_symlink():
            shutil.rmtree(steps_dst)
        else:
            steps_dst.unlink()
    if project:
        shutil.copytree(STEPS_SRC, steps_dst)
    else:
        steps_dst.parent.mkdir(parents=True, exist_ok=True)
        steps_dst.symlink_to(STEPS_SRC, target_is_directory=True)

    mode = "copied into ./.claude/" if project else f"symlinked into {CLAUDE_DIR}/"
    ok(f"{len(agents)} agents, {len(commands)} commands {mode}")
    ok(f"templates {'copied' if project else 'linked'} -> {templates_dst}")
    if stale:
        info(f"removed {stale} stale file(s) from a previous install")

    if not project and not args.no_hooks:
        added = install_hooks(remove=False)
        ok(f"hooks {'installed' if added else 'already present'} in {SETTINGS}")

    head("Next steps")
    print("  1. spar doctor                     # confirm the install is healthy")
    print("  2. spar connectors list            # see the prebuilt org connectors")
    print("  3. spar mcp install                # register connectors with your host")
    print("  4. In Claude Code (or the SPAR app): /spar.init \"<what you want to build>\"")
    print("     then /spar.explore, /spar.design, /spar.build, /spar.deliver")
    return 0


def cmd_uninstall(args) -> int:
    removed = 0
    for d, prefix in ((AGENTS_DST, "spar-"), (COMMANDS_DST, "spar."), (CLAUDE_DIR / "skills", "spar-")):
        if not d.is_dir():
            continue
        for p in d.iterdir():
            if p.name.startswith(prefix) and p.name.endswith(".md"):
                p.unlink()
                removed += 1
    for link in (TEMPLATES_LINK, STEPS_LINK):
        if link.is_symlink() or link.exists():
            if link.is_dir() and not link.is_symlink():
                shutil.rmtree(link)
            else:
                link.unlink()
            removed += 1
    install_hooks(remove=True)
    ok(f"removed {removed} item(s) and SPAR hooks")
    return 0


def cmd_status(args) -> int:
    agents_total = len(list(AGENTS_SRC.glob("spar-*.md")))
    commands_total = len(list(COMMANDS_SRC.glob("spar.*.md")))
    agents_installed = len(list(AGENTS_DST.glob("spar-*.md"))) if AGENTS_DST.is_dir() else 0
    commands_installed = len(list(COMMANDS_DST.glob("spar.*.md"))) if COMMANDS_DST.is_dir() else 0

    head(f"SPAR {__version__}")
    print(f"  agents      {agents_installed}/{agents_total} installed")
    print(f"  commands    {commands_installed}/{commands_total} installed")
    print(f"  templates   {'linked' if TEMPLATES_LINK.exists() else dim('not linked')}")
    print(f"  hooks       {'present' if hooks_present() else dim('absent')}")
    print(f"  connectors  {len(load_catalog())} in catalog")

    spar_root = find_spar_root()
    if not spar_root:
        print(f"\n  {dim('no spar/ in this directory tree')}")
        return 0

    scan = scan_spar(spar_root)
    pf = portfolio(scan)
    head(f"Project: {scan['project']}  ({spar_root})")
    trio = scan["governance"]
    print(
        "  governance  "
        + "  ".join(
            f"{green('✓') if v else red('✗')} {k}" for k, v in trio.items()
        )
    )
    if not scan["features"]:
        print(f"  {dim('no features yet -- run /spar.explore to create one')}")
        return 0

    print()
    print(f"  {'FEATURE':<28} {'PHASE':<12} {'TASKS':<12} {'RISK':<9} VERIFY")
    for f in scan["features"]:
        bar = f"{f['tasks_done']}/{f['tasks_total']}" if f["tasks_total"] else "-"
        pct = f" {int(f['task_completion'] * 100)}%" if f["tasks_total"] else ""
        v = f["verification"]["status"]
        vtxt = green("pass") if v == "pass" else (red("fail") if v == "fail" else dim(v))
        print(f"  {f['id']:<28} {f['phase']:<12} {bar + pct:<12} {f['risk_tier']:<9} {vtxt}")
    print(
        f"\n  portfolio: {pf['features']} features · "
        f"{int(pf['avg_completion'] * 100)}% avg completion · "
        f"{pf['verified']} verified · {pf['tasks_done']}/{pf['tasks_total']} tasks"
    )
    return 0


def cmd_update(args) -> int:
    for argv in (
        ["uv", "tool", "upgrade", "spar-cli"],
        ["pipx", "upgrade", "spar-cli"],
        [sys.executable, "-m", "pip", "install", "--upgrade", "spar-cli"],
    ):
        if shutil.which(argv[0]) or argv[0] == sys.executable:
            info("running: " + " ".join(argv))
            return subprocess.call(argv)
    bad("found none of uv, pipx or pip")
    return 1


# --------------------------------------------------------------------------- #
# Hooks
# --------------------------------------------------------------------------- #


def _read_settings() -> dict:
    if not SETTINGS.is_file():
        return {}
    try:
        return json.loads(SETTINGS.read_text(encoding="utf-8")) or {}
    except (OSError, json.JSONDecodeError):
        warn(f"{SETTINGS} is not valid JSON; leaving it untouched")
        return {}


def hooks_present() -> bool:
    hooks = _read_settings().get("hooks", {})
    for entries in hooks.values():
        if isinstance(entries, list):
            for e in entries:
                if isinstance(e, dict) and e.get("_spar") == HOOK_MARKER:
                    return True
    return False


def install_hooks(remove: bool) -> bool:
    settings = _read_settings()
    hooks = settings.setdefault("hooks", {})
    changed = False

    for event in ("PostToolUse", "Stop"):
        entries = hooks.get(event)
        if isinstance(entries, list):
            kept = [e for e in entries if not (isinstance(e, dict) and e.get("_spar") == HOOK_MARKER)]
            if len(kept) != len(entries):
                changed = True
            if kept:
                hooks[event] = kept
            else:
                hooks.pop(event, None)

    if not remove:
        hooks.setdefault("PostToolUse", []).append(
            {
                "matcher": "Write|Edit",
                "hooks": [{"type": "command", "command": "spar _hook post-tool-use"}],
                "_spar": HOOK_MARKER,
            }
        )
        hooks.setdefault("Stop", []).append(
            {
                "hooks": [{"type": "command", "command": "spar _hook stop"}],
                "_spar": HOOK_MARKER,
            }
        )
        changed = True

    if changed:
        SETTINGS.parent.mkdir(parents=True, exist_ok=True)
        SETTINGS.write_text(json.dumps(settings, indent=2) + "\n", encoding="utf-8")
    return changed


def cmd_hooks(args) -> int:
    install_hooks(remove=bool(args.remove))
    ok("hooks removed" if args.remove else "hooks installed")
    return 0


def cmd_hook(args) -> int:
    """Internal: invoked by Claude Code hooks. Reads a JSON event on stdin."""
    try:
        payload = json.loads(sys.stdin.read() or "{}")
    except (json.JSONDecodeError, OSError):
        return 0

    if args.event == "post-tool-use":
        path = (
            payload.get("tool_input", {}).get("file_path")
            or payload.get("file_path")
            or ""
        )
        norm = path.replace(os.sep, "/")
        if not path or not ("/spar/specs/" in norm or "/.spar/specs/" in norm) or not path.endswith(".md"):
            return 0
        root = find_git_root(Path(path).parent if Path(path).parent.exists() else None)
        base = (workspace_in(root) or root / SPAR_DIR_NAME) if root else Path(path).parent
        try:
            base.mkdir(parents=True, exist_ok=True)
            with (base / "review-queue.txt").open("a", encoding="utf-8") as fh:
                fh.write(path + "\n")
        except OSError:
            pass
        return 0

    # stop
    root = find_git_root()
    queue = ((workspace_in(root) or root / SPAR_DIR_NAME) / "review-queue.txt") if root else None
    if not queue or not queue.is_file():
        return 0
    seen, items = set(), []
    for line in queue.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and line not in seen:
            seen.add(line)
            items.append(line)
    if items:
        print("\nSPAR artifacts written this session:")
        for i in items:
            try:
                shown = str(Path(i).relative_to(root))
            except ValueError:
                shown = i
            print(f"  · {shown}")
        print("Review them before the next phase. Next: `spar status`")
    try:
        queue.unlink()
    except OSError:
        pass
    return 0


# --------------------------------------------------------------------------- #
# new workspace
# --------------------------------------------------------------------------- #

NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")

CLAUDE_MD = """# {name}

This project uses **SPAR** -- a governed AI delivery pipeline. Artifacts live in `spar/`.

## Pipeline

```
/spar.init "<brief>"   set up spar/, propose engineering principles  [review: principles]
/spar.explore          roadmap -> spec, questions in one sitting  [review: spec]
/spar.design           plan, architecture doc, tasks, cross-check [review: plan]
/spar.build            tests first, then code, per phase          [review: each checkpoint]
/spar.deliver          the four test pillars, traced to the spec
```

Existing code: `/spar.adopt`. A bug: `/spar.fix "<bug>"`. Specs behind the code: `/spar.reconcile`.
Code changed outside SPAR: `/spar.sync`.

## Rules for AI sessions

1. Read `spar/tenets.md`, `spar/standards.md` and `spar/references.md` before proposing design.
2. Consult org sources through the SPAR MCP gateway before the open web.
3. Never guess: write `NEEDS CLARIFICATION[topic]: question` inline instead.
4. Every artifact you write goes under `spar/`; code goes to the repo root through `/spar.build`.
5. When lost, run ``spar status``.
"""


def cmd_init(args) -> int:
    """Set SPAR up in the current folder and keep the brief for /spar.explore."""
    root = Path.cwd()
    spar_root = root / SPAR_DIR_NAME
    if (root / LEGACY_DIR_NAME).is_dir() and not spar_root.exists():
        info("this project keeps SPAR files in .spar/ -- run `spar migrate` to move them to spar/")
        spar_root = root / LEGACY_DIR_NAME
    for sub in ("specs", "briefs"):
        (spar_root / sub).mkdir(parents=True, exist_ok=True)
    brief = " ".join(args.brief or []).strip()
    if brief:
        (spar_root / "briefs" / "pending.md").write_text(brief + "\n", encoding="utf-8")
    gi = root / ".gitignore"
    wanted = ["spar/specs/*/.checks.json", "spar/.checks.json", "spar/cache/", "spar/last-sync",
              "spar/ignored-paths", "spar/review-queue.txt"]
    existing = gi.read_text(encoding="utf-8").splitlines() if gi.is_file() else []
    missing = [w for w in wanted if w not in existing]
    if missing:
        block = ([""] if existing and existing[-1].strip() else []) + ["# SPAR bookkeeping (the trio and specs/ ARE tracked)"] + missing
        gi.write_text("\n".join(existing + block) + "\n", encoding="utf-8")
    for fname in ("CLAUDE.md", "AGENTS.md"):
        if not (root / fname).exists():
            (root / fname).write_text(CLAUDE_MD.format(name=root.name), encoding="utf-8")
    ok(f"SPAR set up in {spar_root.relative_to(root)}/" + (" with your brief saved" if brief else ""))
    has_code = any(p.suffix in (".py", ".ts", ".js", ".go", ".rs", ".java", ".swift", ".rb", ".cs", ".kt")
                   for p in root.rglob("*") if p.is_file() and ".git" not in p.parts and SPAR_DIR_NAME not in p.parts)
    info("next: /spar.adopt proposes engineering principles from the existing code" if has_code
         else "next: /spar.init proposes the engineering principles (tenets, standards, references)")
    return 0


def cmd_drawio(args) -> int:
    """Write a draw.io diagram from a short JSON description (sequence, er or flow)."""
    from . import drawio
    if not args.out.endswith(".drawio"):
        bad("the output must be a .drawio file")
        return 2
    if args.spec == "-":
        raw = sys.stdin.read()
    elif args.spec.lstrip().startswith(("{", "[")):
        raw = args.spec          # inline JSON (can be longer than any file name)
    else:
        raw = Path(args.spec).read_text(encoding="utf-8")
    try:
        out = drawio.write(args.kind, raw, Path(args.out))
    except (ValueError, KeyError, json.JSONDecodeError) as exc:
        bad(f"could not build the diagram: {exc}")
        return 2
    ok(f"wrote {out}")
    return 0


def cmd_template(args) -> int:
    """Print an artifact template (spec, plan, tasks, tenets, …) — the CLI twin of the
    spar_template MCP tool, for agents that work through a shell."""
    names = sorted(p.stem.replace("-template", "") for p in TEMPLATES_SRC.glob("*.md"))
    if args.list or not args.name:
        print("\n".join(names))
        return 0
    name = args.name.strip()
    if "/" in name or ".." in name:
        bad("invalid template name")
        return 2
    for candidate in (f"{name}-template.md", f"{name}.md"):
        p = TEMPLATES_SRC / candidate
        if p.is_file():
            sys.stdout.write(p.read_text(encoding="utf-8"))
            return 0
    bad(f"unknown template: {name} (available: {', '.join(names)})")
    return 2


def cmd_new(args) -> int:
    name = args.name
    if not NAME_RE.match(name) or any(part in name for part in ("/", "\\", "..")):
        bad(f"invalid workspace name: {name!r}")
        info("names must match ^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$ and contain no / \\ or ..")
        return 1

    target = Path.cwd() / name
    if target.exists():
        bad(f"{target} already exists")
        return 1
    target.mkdir(parents=True)

    if not args.no_git:
        subprocess.run(["git", "init", "-b", "main"], cwd=str(target), capture_output=True)

    for fname in ("CLAUDE.md", "AGENTS.md"):
        (target / fname).write_text(CLAUDE_MD.format(name=name), encoding="utf-8")
    (target / ".gitignore").write_text(
        "\n".join(
            [
                "__pycache__/",
                "node_modules/",
                ".env",
                "",
                "# SPAR bookkeeping (the trio and specs/ ARE tracked)",
                "spar/last-sync",
                "spar/ignored-paths",
                "spar/review-queue.txt",
                "spar/specs/*/.checks.json",
                "spar/.checks.json",
                "spar/cache/",
                "",
            ]
        ),
        encoding="utf-8",
    )
    (target / SPAR_DIR_NAME / "specs").mkdir(parents=True)

    cwd = Path.cwd()
    try:
        os.chdir(target)
        ns = argparse.Namespace(project=True, no_hooks=True)
        cmd_install(ns)
    finally:
        os.chdir(cwd)

    ok(f"created workspace {target}")
    head("Next steps")
    print(f"  cd {name}")
    print("  # in Claude Code: /spar.init --preset=org")
    return 0


# --------------------------------------------------------------------------- #
# connectors
# --------------------------------------------------------------------------- #


def _connector_matches(spec: dict, query: str) -> bool:
    if not query:
        return True
    q = query.lower()
    haystack = " ".join(
        [
            spec.get("id", ""),
            spec.get("name", ""),
            spec.get("category", ""),
            spec.get("role", ""),
            spec.get("summary", ""),
            " ".join(spec.get("tools", [])),
        ]
    ).lower()
    return q in haystack


def cmd_connectors(args) -> int:
    catalog = load_catalog()
    if args.action in (None, "list"):
        registry, _, _ = load_registry(args.registry)
        configured = {c["id"] for c in resolve_connectors(registry)}

        specs = list(catalog.values())
        if args.category:
            specs = [s for s in specs if s.get("category", "").lower() == args.category.lower()]
        if args.role:
            specs = [s for s in specs if s.get("role", "") == args.role]
        if args.search:
            specs = [s for s in specs if _connector_matches(s, args.search)]
        if args.configured:
            specs = [s for s in specs if s["id"] in configured]

        filt = []
        if args.category:
            filt.append(f"category={args.category}")
        if args.role:
            filt.append(f"role={args.role}")
        if args.search:
            filt.append(f"match={args.search!r}")
        if args.configured:
            filt.append("configured only")
        suffix = f"  {dim('· '.join([''] + filt))}" if filt else ""
        head(f"MCP connector catalog — {len(specs)} of {len(catalog)}{suffix}")

        if not specs:
            print(f"  {dim('nothing matched. Try `spar connectors list --search azure`')}")
            return 0

        group_key = "role" if args.by == "role" else "category"
        groups: dict[str, list[dict]] = {}
        for spec in specs:
            groups.setdefault(spec.get(group_key, "other"), []).append(spec)

        for name in sorted(groups):
            print(f"\n  {bold(name)}  {dim(str(len(groups[name])))}")
            for spec in sorted(groups[name], key=lambda s: s["id"]):
                marks = []
                if spec["id"] in configured:
                    marks.append(green("configured"))
                if spec.get("status") == "verified":
                    marks.append(cyan("verified"))
                if not spec.get("readonly", True):
                    marks.append(yellow("writes"))
                tail = "  " + " ".join(marks) if marks else ""
                other = spec.get("role") if group_key == "category" else spec.get("category")
                print(f"    {spec['id']:<24} {dim(str(other)):<20} {spec.get('name','')}{tail}")
                if args.long:
                    print(f"      {dim(spec.get('summary',''))}")

        print()
        info(f"{len(configured)} configured · filter with --category / --role / --search")
        print(f"  {dim('spar connectors show <id>   config keys a connector needs')}")
        print(f"  {dim('spar connectors list --long  include one-line summaries')}")
        return 0

    if args.action == "show":
        spec = catalog.get(args.id)
        if not spec:
            bad(f"unknown connector: {args.id}")
            near = [s["id"] for s in catalog.values() if _connector_matches(s, args.id)][:8]
            if near:
                info("did you mean: " + ", ".join(near))
            else:
                info("run `spar connectors list` to see available ids")
            return 1
        head(f"{spec['id']} — {spec.get('name','')}")
        print(f"  category    {spec.get('category')}")
        print(f"  role        {spec.get('role')}")
        print(
            f"  status      {spec.get('status')}"
            + (
                dim("  (connection template — point it at your endpoint)")
                if spec.get("status") == "template"
                else dim("  (invocation verified)")
            )
        )
        print(f"  transport   {spec.get('transport')}")
        print(f"  auth        {spec.get('auth')}")
        print(f"  read-only   {spec.get('readonly', False)}")
        if spec.get("url_template"):
            print(f"  url         {spec['url_template']}")
        if spec.get("command"):
            print(f"  command     {' '.join(spec['command'])}")
        print(f"\n  {bold('config keys')} (values come from your registry / env, never from SPAR)")
        for f in spec.get("config", []):
            req = "required" if f.get("required", True) else "optional"
            print(f"    {f['key']:<16} {req:<9} {f.get('desc','')}")
            if f.get("example"):
                print(f"      {dim('e.g. ' + str(f['example']))}")
        if spec.get("tools"):
            print(f"\n  {bold('tools exposed')}  {', '.join(spec['tools'])}")
        if spec.get("grants"):
            print(f"  {bold('agents granted')} {', '.join(spec['grants'])}")
        if spec.get("notes"):
            print(f"\n  {dim(spec['notes'])}")
        head("Add it to your registry")
        print(f"  connectors:\n    - use: {spec['id']}")
        for f in spec.get("config", []):
            if f.get("required", True):
                print(f"      {f['key']}: <{f.get('example', 'value')}>")
        return 0

    if args.action == "test":
        registry, path, tried = load_registry(args.registry)
        if registry is None:
            warn("no org registry found; nothing to test")
            print(REGISTRY_SCHEMA_HELP)
            return 0
        conns = resolve_connectors(registry)
        head(f"Testing {len(conns)} configured connector(s) from {path}")
        failures = 0
        for conn in conns:
            miss = missing_config(conn)
            transport, endpoint = connector_endpoint(conn)
            label = conn.get("alias") or conn["id"]
            if miss:
                bad(f"{label}: missing config {', '.join(miss)}")
                failures += 1
                continue
            unresolved = "{" in str(endpoint)
            env_keys = [
                v for k, v in (conn.get("config_values") or {}).items() if k.endswith("_env")
            ]
            missing_env = [e for e in env_keys if isinstance(e, str) and not os.environ.get(e)]
            if unresolved:
                bad(f"{label}: endpoint has unresolved placeholders -> {endpoint}")
                failures += 1
            elif missing_env:
                warn(f"{label}: env var(s) not set in this shell: {', '.join(missing_env)}")
            else:
                ok(f"{label}: {transport} -> {endpoint if isinstance(endpoint, str) else ' '.join(endpoint)}")
        return 1 if failures else 0

    return 0


# --------------------------------------------------------------------------- #
# mcp check / install
# --------------------------------------------------------------------------- #


def cmd_mcp(args) -> int:
    registry, path, tried = load_registry(args.registry)
    if registry is None:
        warn("no org registry found. SPAR works without one -- agents just fall back to the open web.")
        print("\nLooked in:")
        for p in tried:
            print(f"  {dim(str(p))}")
        print()
        print(REGISTRY_SCHEMA_HELP)
        return 0

    conns = resolve_connectors(registry)
    if not conns:
        warn(f"{path} has no `connectors:` entries")
        print(REGISTRY_SCHEMA_HELP)
        return 0

    head(f"{len(conns)} connector(s) declared in {path}")
    if args.only:
        conns = [c for c in conns if (c.get("alias") or c["id"]) == args.only]
        if not conns:
            bad(f"no configured connector named {args.only}")
            return 1

    if args.action == "check":
        problems = 0
        for conn in conns:
            label = conn.get("alias") or conn["id"]
            miss = missing_config(conn)
            if miss:
                bad(f"{label}: missing {', '.join(miss)}")
                problems += 1
            else:
                ok(f"{label}: role={conn.get('role')} ready")
        gw = "installed" if gateway_registered() else "not registered"
        sv = "installed" if server_registered() else "not registered"
        info(f"SPAR MCP server: {sv} · SPAR gateway: {gw}")
        return 1 if problems else 0

    # install: register the SPAR gateway (single entry) and optionally each server
    if not shutil.which("claude"):
        warn("`claude` CLI not on PATH -- printing the commands to run instead of executing them.")
    cmds = gateway_register_commands(scope=registry.get("scope", "user"))
    present = _host_servers()
    for argv in cmds:
        name = argv[3]
        if name in present:
            info(f"{name}: already registered")
            continue
        if shutil.which("claude"):
            info("running: " + " ".join(argv))
            rc = subprocess.call(argv)
            if rc != 0:
                bad(f"command failed (exit {rc})")
        else:
            print("  " + " ".join(argv))
    ok("SPAR MCP server and gateway registration prepared -- agents get spar_* tools; one entry fronts every connector")
    info("agents address connectors by role (docs, issues, scm, ci, db) via the gateway")
    return 0


GATEWAY_POLICY_CANDIDATES = ("gateway-policy.yaml", "gateway-policy.yml", "gateway-policy.json")

DEFAULT_POLICY = {
    "default": {"readonly": True, "max_result_chars": 24000, "cache_ttl_seconds": 900},
    "roles": {
        "db": {"schema_only": True},
        "comms": {"max_results": 20},
    },
    "deny_tools": [
        "get_secret_value",
        "read_secret",
        "get_app_settings_values",
        "reveal",
        "decrypt",
    ],
    "redact_patterns": [
        "(?i)(api[_-]?key|secret|password|token|bearer)\\s*[:=]\\s*\\S+",
        "-----BEGIN [A-Z ]*PRIVATE KEY-----",
    ],
}


def gateway_policy_dirs(spar_root: Path | None) -> list[Path]:
    """Where gateway policy may live, least specific first.

    The organisation tier is user-scoped, like the registry, so an administrator
    running the control plane outside any project still has somewhere to write.
    A project may then tighten it further, and the project always wins.
    """
    dirs = [host_config_dir()]
    if spar_root:
        dirs.append(spar_root)
    return dirs


def load_gateway_policy(spar_root: Path | None) -> dict:
    """Merge the shipped defaults with org-level then project-level policy."""
    policy = json.loads(json.dumps(DEFAULT_POLICY))  # deep copy
    for d in gateway_policy_dirs(spar_root):
        for name in GATEWAY_POLICY_CANDIDATES:
            p = d / name
            if not p.is_file():
                continue
            try:
                user = load_config_file(p) or {}
            except (OSError, ValueError):
                warn(f"could not parse {p}; ignoring it")
                break
            for key, val in user.items():
                if isinstance(val, dict) and isinstance(policy.get(key), dict):
                    policy[key].update(val)
                else:
                    policy[key] = val
            # the last file read is the one in force, so report the narrowest
            policy["_source"] = str(p)
            break
    return policy


def read_gateway_log(spar_root: Path, limit: int | None = None) -> list[dict]:
    path = spar_root / "gateway-log.jsonl"
    if not path.is_file():
        return []
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    if limit:
        lines = lines[-limit:]
    out = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return out


def cmd_connections(args) -> int:
    """The developer tier: choose which org-enabled connectors this project uses."""
    spar_root = require_spar_root()
    registry, rpath, _ = load_registry(args.registry)
    if registry is None:
        bad("no org registry — nothing has been enabled by your organisation yet")
        info("an administrator connects systems in the control plane: spar control")
        return 1

    everything = resolve_connectors(registry, include_disabled=True)
    org_ok = [c for c in everything if c.get("availability") != "not-enabled-by-org"]
    selection = load_project_selection(spar_root)

    if args.action == "list":
        head(f"Connections for {spar_root.parent.name}")
        if selection is None:
            info("no project selection — every org-enabled connector is in use")
        print(f"\n  {'CONNECTOR':<22} {'ROLE':<14} IN USE")
        for c in org_ok:
            label = c.get("alias") or c["id"]
            on = selection is None or label in selection or c["id"] in selection
            print(f"  {label:<22} {c.get('role',''):<14} {green('yes') if on else dim('no')}")
        disabled = [c for c in everything if c.get("availability") == "not-enabled-by-org"]
        if disabled:
            print()
            info(
                f"{len(disabled)} connector(s) staged but not enabled by your organisation: "
                + ", ".join((c.get("alias") or c["id"]) for c in disabled[:8])
            )
        return 0

    if args.action == "reset":
        path = spar_root / CONNECTIONS_FILE
        if path.is_file():
            path.unlink()
            ok("selection cleared — every org-enabled connector is in use again")
        else:
            info("no selection to clear")
        return 0

    names = {(c.get("alias") or c["id"]) for c in org_ok}
    ids = {c["id"] for c in org_ok}

    if not args.connector:
        bad(f"`connections {args.action}` needs at least one connector id")
        info("run `spar connections list` to see what your organisation has enabled")
        return 1

    for want in args.connector:
        if want not in names and want not in ids:
            bad(f"'{want}' is not enabled by your organisation")
            info("ask an administrator to enable it, or run `spar connections list`")
            return 1

    if args.action == "use":
        # Explicit: this project uses exactly these, nothing else.
        current = set(args.connector)
    else:
        # add/remove operate on the effective set, which is everything when no
        # explicit selection exists yet.
        current = set(selection) if selection is not None else set(names)
        before = set(current)
        for want in args.connector:
            current.add(want) if args.action == "add" else current.discard(want)
        if current == before and args.action == "add":
            warn("nothing changed — every org-enabled connector was already in use")
            info("to narrow this project instead: spar connections use " + " ".join(args.connector))
            return 0

    path = save_project_selection(spar_root, sorted(current))
    ok(f"{len(current)} of {len(org_ok)} org-enabled connector(s) in use: {', '.join(sorted(current))}")
    info(f"wrote {path} — commit it so the team shares the same grounding")
    return 0


def cmd_gateway_status(args) -> int:
    spar_root = find_spar_root()
    registry, rpath, tried = load_registry(args.registry)
    catalog = load_catalog()
    selection = load_project_selection(spar_root)
    everything = resolve_connectors(registry, selection=selection, include_disabled=True)
    conns = [c for c in everything if c.get("availability") == "available"]
    excluded = [c for c in everything if c.get("availability") != "available"]
    policy = load_gateway_policy(spar_root)

    head("MCP gateway")
    print(f"  catalog        {len(catalog)} connectors available")
    print(f"  org registry   {rpath if rpath else dim('none — no org grounding configured')}")
    print(
        "  project sel'n  "
        + (f"{len(selection)} selected" if selection is not None else dim("all org-enabled"))
    )
    print(f"  registered     {'yes' if gateway_registered() else dim('no (spar mcp install)')}")
    print(f"  policy         {policy.get('_source', dim('built-in defaults'))}")

    if excluded:
        print()
        for c in excluded:
            label = c.get("alias") or c["id"]
            why = (
                "not enabled by your organisation"
                if c["availability"] == "not-enabled-by-org"
                else "not selected for this project"
            )
            print(f"  {dim('- ' + label + ': ' + why)}")

    if not conns:
        print()
        warn("no connector is active. Agents must declare the grounding gap, not guess.")
        if not excluded:
            print(f"\n{REGISTRY_SCHEMA_HELP}")
        return 0

    print(f"\n  {'CONNECTOR':<22} {'ROLE':<14} {'MODE':<11} CONFIG")
    for conn in conns:
        label = conn.get("alias") or conn["id"]
        miss = missing_config(conn)
        values = conn.get("config_values") or {}
        mode = "read-only" if conn.get("readonly", True) else yellow("read-write")
        if conn.get("role") == "db" and not values.get("allow_query"):
            mode = "schema-only"
        state = red("missing " + ",".join(miss)) if miss else green("ok")
        print(f"  {label:<22} {conn.get('role',''):<14} {mode:<11} {state}")

    if spar_root:
        entries = read_gateway_log(spar_root)
        if entries:
            head(f"Runtime activity  {dim(f'({len(entries)} calls logged)')}")
            per: dict[str, dict[str, int]] = {}
            for e in entries:
                c = per.setdefault(e.get("connector", "?"), {})
                v = e.get("verdict", "?")
                c[v] = c.get(v, 0) + 1
            print(f"\n  {'CONNECTOR':<22} {'OK':>5} {'CACHE':>6} {'BLOCKED':>8} {'ERROR':>6}")
            for c, counts in sorted(per.items()):
                print(
                    f"  {c:<22} {counts.get('ok', 0):>5} {counts.get('cache-hit', 0):>6} "
                    f"{counts.get('blocked', 0):>8} {counts.get('error', 0):>6}"
                )
            blocked = [e for e in entries if e.get("verdict") == "blocked"]
            if blocked:
                head(f"Policy denials ({len(blocked)})")
                for e in blocked[-8:]:
                    print(f"  {red('✗')} {e.get('connector')}·{e.get('tool')}")
                    print(f"    {dim(str(e.get('reason', ''))[:120])}")
            hits = sum(1 for e in entries if e.get("verdict") == "cache-hit")
            if hits:
                info(f"{hits} call(s) served from cache — latency and tokens saved")
        else:
            print(f"\n  {dim('no gateway calls logged yet')}")
    return 0


def cmd_gateway_policy(args) -> int:
    spar_root = require_spar_root()
    target = spar_root / "gateway-policy.yaml"
    if target.exists() and not args.force:
        bad(f"{target} already exists (use --force to overwrite)")
        return 1
    body = """# SPAR MCP gateway policy.
# Controls what agents may do through the gateway, at runtime, for every connector.

default:
  readonly: true              # mutating-looking tools are denied unless a connector opts out
  max_result_chars: 24000     # truncate oversized upstream responses
  cache_ttl_seconds: 900      # identical read calls inside this window are served from cache

roles:
  db:
    schema_only: true         # introspection only; per-connector allow_query overrides
  comms:
    max_results: 20           # chat history is noisy; keep responses small

# Tool names denied everywhere, whatever a connector exposes. Secret VALUES never
# reach an agent -- SPAR only needs to know that a secret exists.
deny_tools:
  - get_secret_value
  - read_secret
  - get_app_settings_values
  - reveal
  - decrypt

# Anything matching these is masked in upstream responses before an agent sees it.
redact_patterns:
  - "(?i)(api[_-]?key|secret|password|token|bearer)\\\\s*[:=]\\\\s*\\\\S+"
  - "-----BEGIN [A-Z ]*PRIVATE KEY-----"

# Per-connector overrides, e.g.:
# connectors:
#   jira:
#     readonly: false         # allow the issues step (offered by /spar.deliver) to export tasks
#   slack:
#     max_results: 10
"""
    target.write_text(body, encoding="utf-8")
    ok(f"wrote {target}")
    info("edit it, then `spar gateway status` to confirm it loads")
    return 0


def _host_servers() -> dict:
    """The MCP servers Claude Code has registered at user scope."""
    cfg = Path.home() / ".claude.json"
    if not cfg.is_file():
        return {}
    try:
        data = json.loads(cfg.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    servers = data.get("mcpServers") if isinstance(data, dict) else None
    return servers if isinstance(servers, dict) else {}


def gateway_registered() -> bool:
    return "spar-gateway" in _host_servers()


def server_registered() -> bool:
    """Whether the SPAR MCP server itself is registered.

    Every agent's frontmatter asks for `mcp__spar__spar_read`, `spar_write`,
    `spar_template`, `spar_status`, `spar_decision`, `spar_check` and `spar_next`.
    Those come from `spar mcp-server`, a separate entry from the gateway; without
    it the agents fall back to plain file tools and never write a ledger record.
    """
    return "spar" in _host_servers()


def gateway_register_commands(scope: str = "user") -> list[list[str]]:
    """Both host registrations: the SPAR server the agents need, and the gateway."""
    exe = shutil.which("spar") or "spar"
    return [
        ["claude", "mcp", "add", "spar", "--scope", scope, "--", exe, "mcp-server"],
        ["claude", "mcp", "add", "spar-gateway", "--scope", scope, "--", exe, "gateway"],
    ]


# --------------------------------------------------------------------------- #
# doctor
# --------------------------------------------------------------------------- #


def cmd_doctor(args) -> int:
    # (passed, label, fix, hard) -- advisory checks report but never fail the exit code,
    # because org grounding and host registration are optional by design.
    checks: list[tuple[bool, str, str, bool]] = []

    agents_total = len(list(AGENTS_SRC.glob("spar-*.md")))
    commands_total = len(list(COMMANDS_SRC.glob("spar.*.md")))
    templates_total = len(list(TEMPLATES_SRC.glob("*.md")))

    a_inst = sorted(p.name for p in AGENTS_DST.glob("spar-*.md")) if AGENTS_DST.is_dir() else []
    c_inst = sorted(p.name for p in COMMANDS_DST.glob("spar.*.md")) if COMMANDS_DST.is_dir() else []
    checks.append(
        (
            len(a_inst) == agents_total and agents_total > 0,
            f"agents installed ({len(a_inst)}/{agents_total})",
            "spar install",
            True,
        )
    )
    checks.append(
        (
            len(c_inst) == commands_total and commands_total > 0,
            f"commands installed ({len(c_inst)}/{commands_total})",
            "spar install",
            True,
        )
    )

    stale = [
        n
        for n in a_inst
        if (AGENTS_DST / n).is_symlink() and not (AGENTS_DST / n).resolve().exists()
    ]
    checks.append((not stale, "no stale agent links", "spar install", True))

    checks.append(
        (
            TEMPLATES_LINK.exists() and len(list(TEMPLATES_SRC.glob("*.md"))) == templates_total,
            f"templates reachable ({templates_total} files)",
            "spar install",
            True,
        )
    )
    # Advisory: the hooks only queue written artifacts and print a session summary. The pipeline
    # works without them, and `spar install --no-hooks` is a supported choice.
    checks.append(
        (
            hooks_present(),
            "no artifact-review hooks in settings.json",
            "spar hooks",
            False,
        )
    )

    cat = load_catalog()
    checks.append(
        (len(cat) > 0, f"connector catalog loaded ({len(cat)})", "reinstall the package", True)
    )

    registry, rpath, _ = load_registry(getattr(args, "registry", None))
    if registry is None:
        checks.append(
            (
                False,
                "no org registry — agents have no internal grounding",
                "spar connectors list, then create spar/org-registry.yaml",
                False,
            )
        )
    else:
        conns = resolve_connectors(registry)
        broken = [c for c in conns if missing_config(c)]
        checks.append(
            (
                not broken,
                f"org registry {rpath.name}: {len(conns)} connector(s) configured"
                + (f", {len(broken)} incomplete" if broken else ""),
                "spar connectors test",
                False,
            )
        )
    checks.append(
        (server_registered(), "SPAR MCP server registered with host (agents need spar_read/spar_write/spar_decision)", "spar mcp install", False)
    )
    checks.append(
        (gateway_registered(), "MCP gateway registered with host", "spar mcp install", False)
    )

    spar_root = find_spar_root()
    if spar_root:
        good, msg = verify_chain(spar_root)
        checks.append((good, f"decision chain: {msg}", "inspect spar/decisions.jsonl", True))
        policy = load_gateway_policy(spar_root)
        checks.append(
            (
                True,
                f"gateway policy: {policy.get('_source', 'built-in defaults')}",
                "",
                False,
            )
        )

    head("spar doctor")
    hard_failures = 0
    advisories = 0
    for passed, label, fix, hard in checks:
        if passed:
            ok(label)
        elif hard:
            bad(label)
            if fix:
                print(f"    {dim('fix: ' + fix)}")
            hard_failures += 1
        else:
            warn(label)
            if fix:
                print(f"    {dim('optional: ' + fix)}")
            advisories += 1

    print()
    if hard_failures:
        bad(f"{hard_failures} required check(s) failed")
        return 1
    if advisories:
        ok(f"all required checks passed  ({advisories} optional item(s) not configured)")
    else:
        ok("all checks passed")
    return 0


# --------------------------------------------------------------------------- #
# export
# --------------------------------------------------------------------------- #

HTML_SHELL = """<!doctype html>
<html><head><meta charset="utf-8"><title>{title}</title>
<style>
body{{max-width:52rem;margin:2rem auto;padding:0 1.25rem;font:16px/1.65 -apple-system,BlinkMacSystemFont,
"Segoe UI",Roboto,sans-serif;color:#1a1d24;background:#fff}}
h1,h2,h3{{line-height:1.25;margin-top:2rem}} h1{{border-bottom:2px solid #e5e7eb;padding-bottom:.4rem}}
pre{{background:#f6f7f9;padding:.9rem;border-radius:6px;overflow-x:auto}}
code{{background:#f6f7f9;padding:.15rem .35rem;border-radius:3px;font-size:.9em}}
pre code{{background:none;padding:0}} table{{border-collapse:collapse;width:100%}}
th,td{{border:1px solid #e5e7eb;padding:.45rem .6rem;text-align:left}}
hr{{border:0;border-top:1px solid #e5e7eb;margin:2.5rem 0}}
.meta{{color:#6b7280;font-size:.85rem}}
@media(prefers-color-scheme:dark){{body{{background:#0f1115;color:#e6e8ec}}
pre,code{{background:#191d24}} th,td,h1,hr{{border-color:#2a2f39}} .meta{{color:#9aa1ad}}}}
</style></head><body>
<h1>{title}</h1><p class="meta">SPAR feature dossier · generated {when}</p>
<pre>{body}</pre></body></html>
"""


def cmd_export(args) -> int:
    spar_root = require_spar_root()
    feature_dir = spar_root / "specs" / args.feature
    if not _confined(spar_root, feature_dir) or not feature_dir.is_dir():
        bad(f"unknown feature: {args.feature}")
        info("run `spar status` to list features")
        return 1

    parts: list[str] = []
    for name in ARTIFACT_ORDER:
        p = feature_dir / name
        if p.is_file():
            parts.append(f"\n\n---\n\n# {name}\n\n" + p.read_text(encoding="utf-8", errors="replace"))
    for sub in ("contracts", "checklists"):
        d = feature_dir / sub
        if d.is_dir():
            for p in sorted(d.glob("*.md")):
                parts.append(
                    f"\n\n---\n\n# {sub}/{p.name}\n\n" + p.read_text(encoding="utf-8", errors="replace")
                )
    if not parts:
        bad(f"no artifacts found under {feature_dir}")
        return 1

    body = f"# SPAR dossier — {args.feature}\n\nGenerated {now_iso()}\n" + "".join(parts)
    if args.format == "html":
        esc = body.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        out_text = HTML_SHELL.format(title=f"SPAR — {args.feature}", when=now_iso(), body=esc)
        default_name = f"{args.feature}-dossier.html"
    else:
        out_text = body
        default_name = f"{args.feature}-dossier.md"

    if args.out:
        dest = Path(args.out).expanduser()
        dest.write_text(out_text, encoding="utf-8")
        ok(f"wrote {dest} ({len(out_text)} bytes)")
    else:
        dest = Path.cwd() / default_name
        dest.write_text(out_text, encoding="utf-8")
        ok(f"wrote {dest} ({len(out_text)} bytes)")
    return 0


# --------------------------------------------------------------------------- #
# metrics
# --------------------------------------------------------------------------- #


def cmd_metrics(args) -> int:
    spar_root = require_spar_root()
    scan = scan_spar(spar_root)
    feats = scan["features"]
    if args.feature:
        feats = [f for f in feats if f["id"] == args.feature]
        if not feats:
            bad(f"unknown feature: {args.feature}")
            return 1

    if args.json:
        payload = {
            "schema": "spar.metrics/v1",
            "generated_at": now_iso(),
            "project": scan["project"],
            "governance": scan["governance"],
            "features": feats,
            "portfolio": portfolio({"features": feats}),
        }
        print(json.dumps(payload, indent=2))
        return 0

    head(f"Delivery metrics — {scan['project']}")
    if not feats:
        print(f"  {dim('no features yet')}")
        return 0

    def bar(frac: float, width: int = 18) -> str:
        filled = int(round(frac * width))
        return "█" * filled + dim("·" * (width - filled))

    print()
    for f in feats:
        print(f"  {bold(f['id'])}   {dim(f['phase'])}   risk: {f['risk_tier']}")
        print(
            f"    tasks       {bar(f['task_completion'])} "
            f"{f['tasks_done']}/{f['tasks_total']} ({int(f['task_completion'] * 100)}%)"
        )
        print(f"    checkpoints {f['checkpoints']}")
        if f["converge_tasks"] or f["legacy_tasks"]:
            print(f"    brownfield  {f['converge_tasks']} CONVERGE · {f['legacy_tasks']} LEGACY")
        v = f["verification"]
        vt = green("pass") if v["status"] == "pass" else (
            red("fail") if v["status"] == "fail" else dim(v["status"])
        )
        extra = f" ({v['tests_run']} tests)" if v.get("tests_run") else ""
        print(f"    verification {vt}{extra}")
        if f["findings"]:
            items = ", ".join(f"{k}×{v}" for k, v in sorted(f["findings"].items()))
            print(f"    findings    {items}")
        print()

    pf = portfolio({"features": feats})
    print(f"  {bold('Portfolio')}")
    print(f"    features        {pf['features']}")
    print(f"    avg completion  {int(pf['avg_completion'] * 100)}%")
    print(f"    tasks           {pf['tasks_done']}/{pf['tasks_total']}")
    print(f"    verified        {pf['verified']}/{pf['features']}")
    print(
        "    phases          "
        + ", ".join(f"{k}={v}" for k, v in sorted(pf["by_phase"].items()))
    )
    if pf["findings"]:
        print(
            "    findings        "
            + ", ".join(f"{k}×{v}" for k, v in sorted(pf["findings"].items()))
        )
    return 0


# --------------------------------------------------------------------------- #
# dashboard
# --------------------------------------------------------------------------- #

DASH_HTML = r"""<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SPAR — __PROJECT__</title>
<style>
:root{--bg:#0d1017;--bg2:#141922;--line:#232a36;--t1:#e7eaf0;--t2:#a5aebd;--t3:#6b7484;
--ok:#35d39a;--warn:#f2b23c;--bad:#ff6b8b;--ac:#6f9dff}
@media(prefers-color-scheme:light){:root{--bg:#fbfcfd;--bg2:#fff;--line:#e3e7ee;--t1:#151922;
--t2:#4f5766;--t3:#8a92a1;--ac:#2f6bff}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--t1);
font:15px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}
header{padding:22px 26px;border-bottom:1px solid var(--line);display:flex;gap:14px;align-items:baseline;flex-wrap:wrap}
h1{font-size:19px;margin:0;letter-spacing:-.2px}
.sub{color:var(--t3);font-size:12.5px}
.wrap{display:grid;grid-template-columns:minmax(300px,380px) 1fr;gap:0;min-height:calc(100vh - 66px)}
@media(max-width:820px){.wrap{grid-template-columns:1fr}}
aside{border-right:1px solid var(--line);padding:18px;overflow:auto}
main{padding:22px 26px;overflow:auto;min-width:0}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(112px,1fr));gap:10px;margin-bottom:18px}
.kpi{background:var(--bg2);border:1px solid var(--line);border-radius:8px;padding:11px 13px}
.kpi b{display:block;font-size:21px;letter-spacing:-.5px}
.kpi span{color:var(--t3);font-size:11px;text-transform:uppercase;letter-spacing:.6px}
.feat{background:var(--bg2);border:1px solid var(--line);border-radius:8px;padding:11px 13px;
margin-bottom:9px;cursor:pointer;transition:border-color .12s}
.feat:hover,.feat.on{border-color:var(--ac)}
.feat h3{margin:0 0 6px;font-size:14px;display:flex;justify-content:space-between;gap:8px;align-items:center}
.badge{font-size:10px;text-transform:uppercase;letter-spacing:.6px;padding:2px 7px;border-radius:99px;
border:1px solid var(--line);color:var(--t2);white-space:nowrap}
.badge.verified{color:var(--ok);border-color:var(--ok)}
.badge.building{color:var(--warn);border-color:var(--warn)}
.badge.empty{color:var(--t3)}
.bar{height:5px;background:var(--line);border-radius:99px;overflow:hidden;margin:7px 0 5px}
.bar i{display:block;height:100%;background:var(--ac)}
.meta{color:var(--t3);font-size:11.5px}
.arts{display:flex;flex-wrap:wrap;gap:5px;margin-top:8px}
.art{font-size:11px;padding:2px 7px;border:1px solid var(--line);border-radius:5px;color:var(--t2);
background:transparent;cursor:pointer;font-family:ui-monospace,monospace}
.art:hover{border-color:var(--ac);color:var(--t1)}
h2{font-size:14px;text-transform:uppercase;letter-spacing:.8px;color:var(--t3);margin:22px 0 10px}
#doc{background:var(--bg2);border:1px solid var(--line);border-radius:8px;padding:20px 22px;min-height:220px}
#doc h1,#doc h2,#doc h3{text-transform:none;letter-spacing:-.2px;color:var(--t1);margin:1.3em 0 .5em}
#doc h1{font-size:22px}#doc h2{font-size:17px}#doc h3{font-size:15px}
#doc pre{background:var(--bg);border:1px solid var(--line);padding:12px;border-radius:6px;overflow-x:auto}
#doc code{font-family:ui-monospace,monospace;font-size:12.5px}
#doc table{border-collapse:collapse;width:100%;font-size:13px;display:block;overflow-x:auto}
#doc td,#doc th{border:1px solid var(--line);padding:6px 9px;text-align:left}
#doc a{color:var(--ac)}#doc blockquote{border-left:3px solid var(--line);margin:1em 0;padding-left:1em;color:var(--t2)}
.trio{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:6px}
.empty{color:var(--t3);font-size:13px}
</style></head><body>
<header><h1>SPAR</h1><span class="sub">__PROJECT__ · read-only · 127.0.0.1 only</span></header>
<div class="wrap">
<aside>
  <div class="trio" id="trio"></div>
  <h2 style="margin-top:14px">Features</h2>
  <div id="feats"></div>
</aside>
<main>
  <div class="kpis" id="kpis"></div>
  <h2 id="doctitle">Artifact</h2>
  <div id="doc"><p class="empty">Pick a feature, then an artifact.</p></div>
</main></div>
<script>
var S=null,cur=null;
function esc(s){return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}
// Tiny read-only Markdown renderer. Deliberately minimal -- no third-party code.
function md(src){
  var out=[],lines=src.split(/\r?\n/),i=0,inCode=false,code=[];
  function inline(t){
    t=esc(t);
    t=t.replace(/`([^`]+)`/g,'<code>$1</code>');
    t=t.replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>');
    t=t.replace(/(^|[^*])\*([^*\n]+)\*/g,'$1<em>$2</em>');
    t=t.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g,'<a href="$2" rel="noreferrer">$1</a>');
    return t;
  }
  while(i<lines.length){
    var L=lines[i];
    if(/^```/.test(L)){
      if(inCode){out.push('<pre><code>'+esc(code.join("\n"))+'</code></pre>');code=[];inCode=false}
      else{inCode=true}
      i++;continue;
    }
    if(inCode){code.push(L);i++;continue}
    var h=L.match(/^(#{1,6})\s+(.*)$/);
    if(h){out.push('<h'+h[1].length+'>'+inline(h[2])+'</h'+h[1].length+'>');i++;continue}
    if(/^\s*(---|\*\*\*)\s*$/.test(L)){out.push('<hr>');i++;continue}
    if(/^\s*\|/.test(L)){
      var rows=[];
      while(i<lines.length&&/^\s*\|/.test(lines[i])){rows.push(lines[i]);i++}
      var body=rows.filter(function(r){return !/^\s*\|[\s:|-]+\|\s*$/.test(r)});
      var html='<table>';
      body.forEach(function(r,idx){
        var cells=r.replace(/^\s*\|/,'').replace(/\|\s*$/,'').split('|');
        html+='<tr>'+cells.map(function(c){var tag=idx===0?'th':'td';
          return '<'+tag+'>'+inline(c.trim())+'</'+tag+'>'}).join('')+'</tr>';
      });
      out.push(html+'</table>');continue;
    }
    if(/^\s*[-*]\s+/.test(L)){
      var items=[];
      while(i<lines.length&&/^\s*[-*]\s+/.test(lines[i])){
        var txt=lines[i].replace(/^\s*[-*]\s+/,'');
        txt=txt.replace(/^\[( |x|X)\]\s*/,function(m,g){
          return g.toLowerCase()==='x'?'<b>[done]</b> ':'[ ] '});
        items.push('<li>'+inline(txt)+'</li>');i++;
      }
      out.push('<ul>'+items.join('')+'</ul>');continue;
    }
    if(/^\s*>\s?/.test(L)){out.push('<blockquote>'+inline(L.replace(/^\s*>\s?/,''))+'</blockquote>');i++;continue}
    if(!L.trim()){i++;continue}
    var para=[];
    while(i<lines.length&&lines[i].trim()&&!/^(#{1,6}\s|```|\s*[-*]\s|\s*\||\s*>)/.test(lines[i])){
      para.push(lines[i]);i++;
    }
    out.push('<p>'+inline(para.join(' '))+'</p>');
  }
  if(inCode&&code.length){out.push('<pre><code>'+esc(code.join("\n"))+'</code></pre>')}
  return out.join('\n');
}
function kpi(v,l){return '<div class="kpi"><b>'+v+'</b><span>'+l+'</span></div>'}
function render(){
  var p=S.portfolio;
  document.getElementById('kpis').innerHTML=
    kpi(p.features,'features')+kpi(Math.round(p.avg_completion*100)+'%','avg done')+
    kpi(p.tasks_done+'/'+p.tasks_total,'tasks')+kpi(p.verified,'verified')+
    kpi(p.converge_tasks+p.legacy_tasks,'brownfield');
  var g=S.governance,t='';
  ['tenets','standards','references'].forEach(function(k){
    t+='<span class="badge'+(g[k]?' verified':'')+'">'+(g[k]?'✓':'✗')+' '+k+'</span>'});
  document.getElementById('trio').innerHTML=t;
  var h='';
  if(!S.features.length){h='<p class="empty">No features yet. Run /spar.explore in Claude Code.</p>'}
  S.features.forEach(function(f){
    var pct=Math.round(f.task_completion*100);
    h+='<div class="feat" data-id="'+f.id+'"><h3>'+esc(f.id)+
       '<span class="badge '+f.phase+'">'+f.phase+'</span></h3>'+
       '<div class="bar"><i style="width:'+pct+'%"></i></div>'+
       '<div class="meta">'+f.tasks_done+'/'+f.tasks_total+' tasks · '+pct+'% · risk: '+
       f.risk_tier+' · verify: '+f.verification.status+'</div><div class="arts">';
    Object.keys(f.artifacts).forEach(function(a){
      h+='<button class="art" data-f="'+f.id+'" data-a="'+a+'">'+a.replace('.md','')+'</button>'});
    h+='</div></div>';
  });
  document.getElementById('feats').innerHTML=h;
  document.querySelectorAll('.art').forEach(function(b){
    b.addEventListener('click',function(e){
      e.stopPropagation();open(b.dataset.f,b.dataset.a)})});
  document.querySelectorAll('.feat').forEach(function(d){
    d.addEventListener('click',function(){
      var f=S.features.filter(function(x){return x.id===d.dataset.id})[0];
      var first=Object.keys(f.artifacts)[0];if(first)open(f.id,first)})});
}
function open(feature,artifact){
  document.querySelectorAll('.feat').forEach(function(d){
    d.classList.toggle('on',d.dataset.id===feature)});
  document.getElementById('doctitle').textContent=feature+' / '+artifact;
  var doc=document.getElementById('doc');
  doc.innerHTML='<p class="empty">Loading…</p>';
  fetch('/api/artifact?feature='+encodeURIComponent(feature)+'&name='+encodeURIComponent(artifact))
    .then(function(r){if(!r.ok)throw new Error('HTTP '+r.status);return r.text()})
    .then(function(t){doc.innerHTML=md(t)})
    .catch(function(e){doc.innerHTML='<p class="empty">Could not load: '+esc(String(e))+'</p>'});
}
fetch('/api/state').then(function(r){return r.json()}).then(function(j){S=j;render()})
  .catch(function(e){document.body.insertAdjacentHTML('beforeend',
    '<p class="empty" style="padding:20px">Failed to load state: '+esc(String(e))+'</p>')});
</script></body></html>
"""


def cmd_dashboard(args) -> int:
    import http.server
    import urllib.parse

    spar_root = require_spar_root()
    root = spar_root.resolve()
    project = root.parent.name

    class Handler(http.server.BaseHTTPRequestHandler):
        server_version = f"spar/{__version__}"

        def log_message(self, fmt, *a):  # quieter, and never to stderr noise
            if args.verbose:
                sys.stdout.write(f"  {dim(self.address_string() + ' ' + fmt % a)}\n")

        def _send(self, code: int, body: bytes, ctype: str) -> None:
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            try:
                self.wfile.write(body)
            except BrokenPipeError:
                pass

        def _text(self, code: int, msg: str) -> None:
            self._send(code, msg.encode("utf-8"), "text/plain; charset=utf-8")

        def do_POST(self):  # noqa: N802 - read-only server
            self._text(405, "read-only")

        def do_PUT(self):  # noqa: N802
            self._text(405, "read-only")

        def do_DELETE(self):  # noqa: N802
            self._text(405, "read-only")

        def do_GET(self):  # noqa: N802
            parsed = urllib.parse.urlparse(self.path)
            path = parsed.path
            if path in ("/", "/index.html"):
                html = DASH_HTML.replace("__PROJECT__", project)
                return self._send(200, html.encode("utf-8"), "text/html; charset=utf-8")

            if path == "/api/state":
                scan = scan_spar(root)
                payload = {
                    "project": scan["project"],
                    "governance": scan["governance"],
                    "features": scan["features"],
                    "portfolio": portfolio(scan),
                    "generated_at": now_iso(),
                }
                return self._send(
                    200,
                    json.dumps(payload).encode("utf-8"),
                    "application/json; charset=utf-8",
                )

            if path == "/api/artifact":
                q = urllib.parse.parse_qs(parsed.query)
                feature = (q.get("feature") or [""])[0]
                name = (q.get("name") or [""])[0]
                # Path-traversal guard: names are single components, and the
                # resolved target must live inside the spar/ root.
                if (
                    not feature
                    or not name
                    or "/" in feature
                    or "\\" in feature
                    or ".." in feature
                    or "\\" in name
                    or ".." in name
                    or not name.endswith(".md")
                ):
                    return self._text(403, "forbidden")
                target = (root / "specs" / feature / name)
                if not _confined(root, target):
                    return self._text(403, "forbidden")
                if not target.is_file():
                    return self._text(404, "not found")
                data = target.read_text(encoding="utf-8", errors="replace")
                return self._send(200, data.encode("utf-8"), "text/markdown; charset=utf-8")

            if path == "/api/trio":
                q = urllib.parse.parse_qs(parsed.query)
                name = (q.get("name") or [""])[0]
                if name not in ("tenets", "standards", "references"):
                    return self._text(403, "forbidden")
                target = root / f"{name}.md"
                if not target.is_file():
                    return self._text(404, "not found")
                return self._send(
                    200,
                    target.read_text(encoding="utf-8", errors="replace").encode("utf-8"),
                    "text/markdown; charset=utf-8",
                )

            return self._text(404, "not found")

    port = args.port
    httpd = None
    for attempt in range(6):
        try:
            httpd = http.server.ThreadingHTTPServer(("127.0.0.1", port), Handler)
            break
        except OSError:
            info(f"port {port} busy, trying {port + 1}")
            port += 1
    if httpd is None:
        bad("could not bind a port on 127.0.0.1")
        return 1

    url = f"http://127.0.0.1:{port}/"
    ok(f"SPAR dashboard on {url}  {dim('(loopback only, read-only)')}")
    info(f"serving {root}")
    print(f"  {dim('Ctrl-C to stop')}")
    # Flush explicitly: when stdout is a pipe or a file it is block-buffered, and a
    # long-running server would otherwise show nothing until it exits.
    sys.stdout.flush()

    if not args.no_open:
        try:
            import webbrowser

            webbrowser.open(url)
        except Exception:  # pragma: no cover - best effort
            pass

    # Handle SIGINT and SIGTERM explicitly rather than relying on KeyboardInterrupt
    # propagating out of the selector loop. shutdown() must be called from another
    # thread, since serve_forever() owns this one.
    import signal
    import threading

    stopping = threading.Event()

    def _stop(signum, _frame):
        if stopping.is_set():
            return
        stopping.set()
        threading.Thread(target=httpd.shutdown, daemon=True).start()

    previous = {}
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            previous[sig] = signal.signal(sig, _stop)
        except (ValueError, OSError):  # not the main thread, or unsupported
            pass

    try:
        httpd.serve_forever(poll_interval=0.3)
    except KeyboardInterrupt:  # belt and braces
        pass
    finally:
        for sig, handler in previous.items():
            try:
                signal.signal(sig, handler)
            except (ValueError, OSError):
                pass
        httpd.server_close()

    print()
    ok("dashboard stopped")
    sys.stdout.flush()
    return 0


# --------------------------------------------------------------------------- #
# misc thin wrappers
# --------------------------------------------------------------------------- #


def cmd_threat_model(args) -> int:
    head("Threat modelling is agent-driven")
    print("  Run this inside Claude Code:\n")
    print(f"    /spar.design {args.feature}\n")
    print("  It reads spec.md, plan.md, data-model.md and contracts/, walks STRIDE per trust")
    print("  boundary, and writes threat-model.md. High-severity threats with no mitigation are")
    print("  written back into the spec as NEEDS CLARIFICATION[security-*] markers, so they")
    print("  re-enter the gated pipeline instead of dying in a side document.")
    return 0


def cmd_migrate(args) -> int:
    """`spar migrate`: move a project's artifacts from .spar/ to spar/."""
    root = Path(args.path).expanduser().resolve() if getattr(args, "path", None) else Path.cwd()
    old, new = root / LEGACY_DIR_NAME, root / SPAR_DIR_NAME
    if not old.is_dir():
        info(f"nothing to migrate: no {LEGACY_DIR_NAME}/ in {root}")
        return 0
    if new.exists():
        bad(f"{SPAR_DIR_NAME}/ already exists in {root}; move or merge it by hand")
        return 1
    tracked = subprocess.run(["git", "ls-files", "--error-unmatch", "--", str(old)], cwd=root,
                             capture_output=True, text=True).returncode == 0
    if tracked:
        r = subprocess.run(["git", "mv", LEGACY_DIR_NAME, SPAR_DIR_NAME], cwd=root, capture_output=True, text=True)
        if r.returncode != 0:
            bad(r.stderr.strip() or "git mv failed")
            return 1
    else:
        old.rename(new)
    ignore = root / ".gitignore"
    if ignore.is_file():
        text = ignore.read_text(encoding="utf-8")
        updated = "\n".join(("spar/" + line[len(".spar/"):]) if line.startswith(".spar/") else line
                            for line in text.split("\n"))
        if updated != text:
            ignore.write_text(updated, encoding="utf-8")
    ok(f"moved {LEGACY_DIR_NAME}/ to {SPAR_DIR_NAME}/" + (" (git mv)" if tracked else ""))
    return 0


def cmd_manifest(args) -> int:
    spar_root = require_spar_root()
    path = write_manifest(spar_root)
    ok(f"wrote {path}")
    return 0


def cmd_decision(args) -> int:
    """Append a decision record. Used by agents via the gateway, and by humans."""
    spar_root = require_spar_root()
    rec = append_decision(
        spar_root,
        subject={"kind": args.subject_kind, "id": args.subject, "assurance": "asserted"},
        action={"kind": args.action_kind, "name": args.name},
        resource={"type": "artifact", "id": args.resource, "version": args.version or ""},
        context={"feature_id": args.feature or "", "phase": args.phase or ""},
        verdict=args.verdict,
        explanation=args.explanation or "",
    )
    ok(f"decision #{rec['seq']} recorded ({args.verdict})")
    return 0




def cmd_control(args) -> int:
    from .control import serve_control

    return serve_control(args.port, not args.no_open, args.registry, args.verbose)


def cmd_gateway(args) -> int:
    from .gateway import serve_gateway

    return serve_gateway()


def cmd_gateway_serve(args) -> int:
    from .gateway import serve_gateway_http

    return serve_gateway_http(args.port, args.bind, bool(args.verbose))


def cmd_login(args) -> int:
    """Enroll this machine, or just point it at an already-enrolled gateway."""
    import getpass
    import socket

    from .remote import check, enroll, remote_config, save_login

    url = args.url.rstrip("/")
    label = args.label or f"{getpass.getuser()}@{socket.gethostname()}"

    if args.enroll:
        res = enroll(url, args.enroll, label)
        if "error" in res:
            bad(res["error"])
            return 1
        path = save_login(url, res["token"], label)
        ok(f"enrolled as {res['label']} ({res['id']})")
        info(f"access token saved to {path} (mode 0600)")
    else:
        cfg = remote_config()
        if not cfg or cfg["url"] != url or not cfg.get("token"):
            bad("this machine is not enrolled with that gateway")
            info("ask an administrator for the enrollment token, then:")
            info(f"  spar login {url} --enroll <token>")
            return 1
        save_login(url, cfg["token"], label)
        ok(f"pointed at {url}")

    cfg = remote_config()
    res = check(cfg)
    if not res.get("ok"):
        bad(res.get("error", "gateway did not answer"))
        return 1
    ok(f"gateway reachable, {len(res['tools'])} tool(s) available")
    info("no credentials are held on this machine -- the gateway holds them")
    return 0


def cmd_logout(args) -> int:
    from .remote import forget_login, gateway_path

    if forget_login():
        ok(f"removed {gateway_path()}")
        info("this machine will run a local gateway again")
        return 0
    info("this machine was not pointed at a gateway")
    return 0


def cmd_mcp_server(args) -> int:
    from .server import serve

    return serve()



# --------------------------------------------------------------------------- #
# harness: check / next / gate / packs / scan
# --------------------------------------------------------------------------- #


def _resolve_feature(spar_root: Path, feature: str | None, required: bool) -> str | None:
    from .next import latest_feature

    if feature:
        if not (spar_root / "specs" / feature).is_dir():
            bad(f"unknown feature: {feature}")
            raise SystemExit(2)
        return feature
    latest = latest_feature(spar_root)
    if latest is None and required:
        bad("no feature under spar/specs/ — run /spar.explore first")
        raise SystemExit(2)
    return latest


def cmd_check(args) -> int:
    """Run deterministic checks and report with stable codes."""
    from . import checks

    spar_root = require_spar_root()
    # Agents reach for the artifact's name; map those to the harness scopes.
    scope = {"spec": "artifacts", "plan": "artifacts", "tasks": "artifacts", "verify": "verification", "tests": "project"}.get(
        args.scope, args.scope
    )
    if args.note_analyze_attempt:
        feature = _resolve_feature(spar_root, args.feature, required=True)
        version = checks.note_analyze_attempt(spar_root, feature)
        if scope is None:
            payload = {"noted": "analyze", "feature": feature, "version": version}
            print(json.dumps(payload, indent=2) if args.json else f"noted analyze attempt for {feature}")
            return 0
    scope = scope or "all"
    feature = _resolve_feature(spar_root, args.feature, required=scope != "project")
    result = checks.run(spar_root, feature, scope)
    if args.for_agent:
        print(checks.for_agent(result), end="")
    elif args.json:
        print(json.dumps(result, indent=2))
    else:
        print(checks.render_text(result))
    return 0 if result["ok"] else 1


def cmd_checks(args) -> int:
    """`spar checks init`: write a starter spar/checks.yaml from the manifests."""
    from . import checks

    spar_root = require_spar_root()
    if args.action == "init":
        path = checks.checks_config_path(spar_root)
        if path.is_file() and not args.force:
            warn(f"{path} already exists; not overwriting (use --force)")
            return 0
        inferred = checks.infer_checks(spar_root.parent)
        path = checks.write_checks_config(spar_root, inferred)
        ok(f"wrote {path} with {len(inferred)} check(s)")
        for c in inferred:
            print(f"  · {c['name']}: {c['run']}" + ("" if c.get("required", True) else "  (optional)"))
        if not inferred:
            info("no manifest recognised; edit the file and add your test, lint and typecheck commands")
        return 0
    cfg = checks.load_checks_config(spar_root)
    if cfg is None:
        info("no spar/checks.yaml — run `spar checks init`")
        return 0
    print(json.dumps(cfg, indent=2) if args.json else checks.render_checks_yaml(cfg.get("checks") or [], int(cfg.get("timeout_seconds") or 600)), end="")
    return 0


def cmd_verify_guard(args) -> int:
    """Prove that a guard fails when selected production changes are removed."""
    from .guard import verify_guard

    command = list(args.command)
    if command[:1] == ["--"]:
        command = command[1:]
    result = verify_guard(Path(args.repo), args.revert, command, args.expect, args.timeout)
    print(json.dumps(result, indent=2))
    return {"verified": 0, "decoration": 1, "inconclusive": 2}.get(result["outcome"], 3)


def cmd_next(args) -> int:
    """The one deterministic next action for a feature."""
    from .next import compute_next

    spar_root = find_spar_root()
    root = spar_root.parent if spar_root else Path.cwd()
    feature = args.feature
    if spar_root and feature and not (spar_root / "specs" / feature).is_dir():
        bad(f"unknown feature: {feature}")
        return 2
    result = compute_next(root, spar_root, feature)
    if args.json:
        print(json.dumps(result, indent=2))
        return 0
    label = {
        "prompt": "needs your words",
        "run": f"run /spar.{result['command']}",
        "check": f"run spar check --scope {result['scope']}",
        "fix": f"fix {result['scope']} (owner spar-{result['owner']}) via /spar.{result['command']}",
        "gate": f"waiting on gate {result['gate']}",
        "select": "waiting on you to choose an MVP",
        "blocked": "blocked",
        "done": "done",
    }[result["action"]]
    head(f"{result['feature'] or '(no feature)'} · {result['stage']}")
    print(f"  {label}")
    print(f"  {result['reason']}")
    for opt in result.get("options", []):
        print(f"    {opt['id']:<5} {opt['label']}")
        if opt.get("detail"):
            print(f"          {opt['detail']}")
    return 0


def cmd_mvp(args) -> int:
    """Read the roadmap, and record which MVP a person chose to build.

    Selection is a subcommand rather than a flag on something else because it is
    a decision in its own right, made by a human, and it wanted a name someone
    would think to type.
    """
    from . import gates
    from .checks import lint_roadmap, read_roadmap, roadmap_path

    spar_root = require_spar_root()
    state = gates.roadmap_state(spar_root)
    roadmap = read_roadmap(spar_root)

    if args.action == "single":
        try:
            rec = gates.mark_single(spar_root, args.note or "", withdraw=args.withdraw)
        except ValueError as exc:
            bad(str(exc))
            return 2
        if args.withdraw:
            ok(f"no longer recorded as a single deliverable (decision #{rec['seq']})")
        else:
            ok(f"recorded as one deliverable by {rec['subject']['id']} (decision #{rec['seq']})")
            info("nothing will ask about MVPs again; go straight to /spar.explore")
        return 0

    if args.action == "select":
        if not args.rest:
            bad("usage: spar mvp select <M1|M2|…> [--note TEXT]")
            return 2
        wanted = args.rest[0].strip().upper()
        # Refuse an id the roadmap does not contain. A typo that silently
        # records M12 for a four-MVP project would route the whole project at
        # nothing, and the error would surface days later as "why is it still
        # asking me to choose?"
        if roadmap and not any(m["id"] == wanted for m in roadmap):
            bad(f"no {wanted} on the roadmap (it has {', '.join(m['id'] for m in roadmap)})")
            return 2
        try:
            rec = gates.select_mvp(spar_root, wanted, args.note or "", withdraw=args.withdraw)
        except ValueError as exc:
            bad(str(exc))
            return 2
        if args.withdraw:
            ok(f"{wanted} is no longer selected (decision #{rec['seq']})")
            return 0
        row = next((m for m in roadmap if m["id"] == wanted), None)
        ok(f"{wanted} selected by {rec['subject']['id']} (decision #{rec['seq']})")
        if row:
            info(f"{row['delivers']}")
        info("the spec is written for this MVP alone; the rest of the roadmap is out of scope")
        return 0

    # `list`, and the default.
    p = roadmap_path(spar_root)
    if state["single"]:
        head("one deliverable")
        print(f"  recorded by {state['single']['by']}: {state['single']['note'] or ''}")
        return 0
    if not p.is_file():
        head("no roadmap")
        print("  This project has not been split into MVPs, and has not been recorded as one")
        print("  deliverable either. Run /spar.explore, or `spar mvp single --note ...`.")
        return 0

    findings = lint_roadmap(p.read_text(encoding="utf-8", errors="replace"))
    errors = [f for f in findings if f.get("severity") == "error"]
    selected = state["selected"]
    head(f"roadmap · {len(roadmap)} MVP{'s' if len(roadmap) != 1 else ''}")
    for m in roadmap:
        mark = "→" if selected and selected["id"] == m["id"] else ("✓" if m["shipped"] else " ")
        print(f"  {mark} {m['id']:<4} {m['name']}")
        print(f"       {m['delivers']}")
    if selected:
        print(f"\n  selected: {selected['id']} by {selected['by']}")
    else:
        print("\n  nothing selected — `spar mvp select <id>`")
    for f in errors:
        warn(f"{f['code']}: {f['message']}")
    return 1 if errors else 0


def cmd_impact(args) -> int:
    """AI impact and ROI: sessions around tasks, git history, spend."""
    from . import impact

    return impact.main(args, require_spar_root(), (ok, bad, info))


def cmd_gate(args) -> int:
    """Read or decide the human gates of a feature."""
    from . import gates

    spar_root = require_spar_root()
    GATE_NAMES = ("approve-spec", "approve-plan", "checkpoint", "approve-release")
    # A bug fix: `spar gate approve approve-fix <fix-id>`.
    if args.action in ("approve", "request-changes") and gates.FIX_GATE in ([args.feature] + list(args.rest or [])):
        ids = [x for x in [args.feature] + list(args.rest or []) if x and x != gates.FIX_GATE]
        if not ids:
            bad("usage: spar gate approve|request-changes approve-fix <fix-id> [--note TEXT]")
            return 2
        if args.action == "request-changes" and not args.note:
            bad("request-changes needs --note saying what should change")
            return 2
        verdict = "approved" if args.action == "approve" else "changes-requested"
        try:
            rec = gates.decide_fix(spar_root, ids[0], verdict, args.note or "")
        except ValueError as exc:
            bad(str(exc))
            return 2
        ok(f"{gates.FIX_GATE} {ids[0]} {verdict} by {rec['subject']['id']} (decision #{rec['seq']})")
        return 0
    # The engineering principles are project-level: `spar gate approve approve-tenets`.
    if args.action in ("approve", "request-changes") and gates.TENETS_GATE in ([args.feature] + list(args.rest or [])):
        if args.action == "request-changes" and not args.note:
            bad("request-changes needs --note saying what should change")
            return 2
        verdict = "approved" if args.action == "approve" else "changes-requested"
        try:
            rec = gates.decide_tenets(spar_root, verdict, args.note or "")
        except ValueError as exc:
            bad(str(exc))
            return 2
        ok(f"{gates.TENETS_GATE} {verdict} by {rec['subject']['id']} (decision #{rec['seq']})")
        return 0
    if args.action in ("approve", "request-changes"):
        gate = args.rest[0] if args.rest else None
        if gate not in GATE_NAMES:
            bad("usage: spar gate approve|request-changes <feature> approve-spec|approve-plan|checkpoint|approve-release [--note TEXT]")
            return 2
        if args.action == "request-changes" and not args.note:
            bad("request-changes needs --note saying what should change")
            return 2
        feature = _resolve_feature(spar_root, args.feature, required=True)
        verdict = "approved" if args.action == "approve" else "changes-requested"
        try:
            rec = gates.decide(spar_root, feature, gate, verdict, args.note or "")
        except ValueError as exc:
            bad(str(exc))
            return 2
        ok(f"{gate} {verdict} by {rec['subject']['id']} (decision #{rec['seq']}, version {rec['resource']['version'][:12]})")
        return 0
    if args.action in ("exempt", "unexempt"):
        if not args.rest:
            bad("usage: spar gate exempt|unexempt <feature> <ROW-ID> [<ROW-ID>...] --note TEXT")
            return 2
        feature = _resolve_feature(spar_root, args.feature, required=True)
        try:
            recs = gates.exempt(spar_root, feature, args.rest, args.note or "", withdraw=args.action == "unexempt")
        except ValueError as exc:
            bad(str(exc))
            return 2
        verb = "exemption withdrawn" if args.action == "unexempt" else "exempted"
        for rec in recs:
            ok(f"{rec['action']['name']} {verb} for {feature} by {rec['subject']['id']} (decision #{rec['seq']})")
        if args.action == "exempt":
            info("the analyzer and tenets gate honour this on their next run; `spar next` re-runs analyze")
        return 0
    if args.action in ("defer", "undefer"):
        if not args.rest:
            bad(f"usage: spar gate defer|undefer <feature> <row> [<row>...] --note TEXT\n"
                f"       rows: {', '.join(gates.PLATFORM_ROWS)}")
            return 2
        feature = _resolve_feature(spar_root, args.feature, required=True)
        try:
            recs = gates.defer(spar_root, feature, args.rest, args.note or "", withdraw=args.action == "undefer")
        except ValueError as exc:
            bad(str(exc))
            return 2
        verb = "no longer deferred" if args.action == "undefer" else "deferred"
        for rec in recs:
            ok(f"platform {rec['action']['name']} {verb} for {feature} by {rec['subject']['id']} (decision #{rec['seq']})")
        if args.action == "defer":
            info("cite it in the plan's platform table as `deferred (decision #N)`; "
                 "nothing downstream may assume a value for a deferred row")
        return 0
    # show: `spar gate <feature>` — the first positional is the feature
    feature = _resolve_feature(spar_root, args.action if args.action not in (None, "show") else args.feature, required=True)
    state = gates.gate_state(spar_root, feature)
    if args.json:
        print(json.dumps(state, indent=2))
        return 0
    head(f"gates · {feature}")
    for name, g in state["gates"].items():
        if g["approved"] and g["stale"]:
            status = f"approved by {g['by']} but STALE — {'+'.join(g['artifacts'])} changed since"
        elif g["approved"]:
            status = f"approved by {g['by']} at {g['at']}"
        elif g["changes_requested"]:
            status = f"changes requested by {g['by']}: {g['note'] or ''}"
        else:
            status = "open"
        print(f"  {name:<14} {status}")
    if state["analyze"]:
        a = state["analyze"]
        print(f"  {'analyze':<14} {a['verdict']} by {a['by']} at {a['at']}")
    for e in state.get("exemptions", []):
        print(f"  {'exempt ' + e['row']:<14} by {e['by']}: {e['note'] or ''}")
    for d in state.get("deferrals", []):
        print(f"  {'defer ' + d['row']:<14} by {d['by']}: {d['note'] or ''}")
    return 0


def cmd_packs(args) -> int:
    """Compliance policy packs: list, show, apply, remove, guardrails."""
    from . import packs

    spar_root = find_spar_root()
    action = args.action
    if action == "list":
        payload = packs.summary(spar_root)
        if args.json:
            print(json.dumps(payload, indent=2))
            return 0
        head("policy packs")
        for p in payload["available"]:
            mark = "●" if p["id"] in payload["selected"] else "○"
            print(f"  {mark} {p['id']:<9} {p['name']:<8} {p['summary']}")
            print(f"    {len(p['guardrails'])} guardrails · {p['tenets']} tenets · {p['standards_rows']} standards rows · {len(p['checks'])} checks")
        info("a pack is a starting point, not a certification")
        return 0
    if action == "guardrails":
        print(json.dumps({"guardrails": packs.guardrails(spar_root)}, indent=2))
        return 0
    if action == "show":
        if not args.ids:
            bad("usage: spar packs show <id>")
            return 2
        p = packs.pack(args.ids[0])
        if p is None:
            bad(f"unknown pack: {args.ids[0]}")
            return 2
        print(json.dumps(p, indent=2))
        return 0
    if spar_root is None:
        spar_root = require_spar_root()
    if not args.ids:
        bad(f"usage: spar packs {action} <id>...")
        return 2
    if action == "apply":
        unknown = packs.apply(spar_root, args.ids)
        for u in unknown:
            bad(f"unknown pack: {u}")
        applied = [i for i in args.ids if i not in unknown]
        if applied:
            ok(f"applied {', '.join(applied)} → tenets.md, standards.md, checks.yaml, packs.json")
            info("a pack is a starting point, not a certification; review the rows it added")
        return 2 if unknown else 0
    if action == "remove":
        packs.remove(spar_root, args.ids)
        ok(f"removed {', '.join(args.ids)}")
        return 0
    bad(f"unknown action: {action}")
    return 2


def cmd_scan(args) -> int:
    """Pattern scans over the working tree's added lines, for pack checks."""
    from . import checks

    spar_root = find_spar_root()
    root = spar_root.parent if spar_root else Path.cwd()
    rc = 0
    if args.deps:
        code, out = checks.scan_deps(root)
        print(out)
        if code == 2:
            warn("no dependency auditor available (npm, pip-audit, cargo-audit, govulncheck)")
        rc = max(rc, 1 if code == 1 else 0)
    if args.pan or args.phi or args.pii or args.secrets:
        hits = checks.scan_diff(root, pan=args.pan, phi=args.phi, pii=args.pii, secrets=args.secrets)
        if args.json:
            print(json.dumps({"hits": hits}, indent=2))
        else:
            for h in hits:
                print(f"  ✗ {h['kind']:<16} {h['path']}:{h['line']}  {h['match']}")
            if not hits:
                ok("no card numbers, identifiers or secrets in the added lines")
        if hits:
            rc = 1
    return rc


# --------------------------------------------------------------------------- #
# argparse wiring
# --------------------------------------------------------------------------- #


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="spar",
        description="SPAR — governed, end-to-end AI software delivery. Specify · Plan · Approve · Release.",
        epilog="Artifacts live in spar/. Docs: README.md · INSTALL.md",
    )
    p.add_argument("--version", action="version", version=f"spar {__version__}")
    sub = p.add_subparsers(dest="cmd")

    s = sub.add_parser("install", help="install agents, commands and templates")
    s.add_argument("--project", action="store_true", help="copy into ./.claude/ instead of ~/.claude/")
    s.add_argument("--no-hooks", action="store_true", help="skip settings.json hook install")
    s.set_defaults(func=cmd_install)

    s = sub.add_parser("uninstall", help="remove everything SPAR installed")
    s.set_defaults(func=cmd_uninstall)

    s = sub.add_parser("status", help="install state + per-feature delivery status")
    s.set_defaults(func=cmd_status)

    s = sub.add_parser("update", help="upgrade the spar package")
    s.set_defaults(func=cmd_update)

    s = sub.add_parser("hooks", help="install or remove SPAR hooks")
    s.add_argument("--remove", action="store_true")
    s.set_defaults(func=cmd_hooks)

    s = sub.add_parser("init", help="set SPAR up in this folder and keep your brief (then /spar.init proposes the engineering principles)")
    s.add_argument("brief", nargs="*", help="what you want to build")
    s.add_argument("--preset", help="used by /spar.init (for example --preset=org)")
    s.set_defaults(func=cmd_init)

    s = sub.add_parser("drawio", help="write a correctly laid-out draw.io diagram from a JSON description (sequence, er, flow, context-map, aggregate)")
    s.add_argument("kind", choices=["sequence", "er", "flow", "context-map", "aggregate"])
    s.add_argument("spec", help="the JSON description, a path to a .json file, or - for stdin")
    s.add_argument("-o", "--out", required=True, help="the .drawio file to write")
    s.set_defaults(func=cmd_drawio)

    s = sub.add_parser("template", help="print an artifact template (spec, plan, tasks, tenets, ...)")
    s.add_argument("name", nargs="?", help="template name, e.g. spec, plan, tasks, tenets, tenets-org-preset")
    s.add_argument("--list", action="store_true", help="list the template names")
    s.set_defaults(func=cmd_template)

    s = sub.add_parser("new", help="scaffold a new SPAR workspace in a new folder")
    s.add_argument("name")
    s.add_argument("--no-git", action="store_true")
    s.set_defaults(func=cmd_new)

    s = sub.add_parser("connectors", help="browse, filter and test the MCP connector catalog")
    s.add_argument("action", nargs="?", default="list", choices=["list", "show", "test"])
    s.add_argument("id", nargs="?", help="connector id (for show)")
    s.add_argument("--category", help="filter by category, e.g. Development, Documentation")
    s.add_argument("--role", help="filter by SPAR role, e.g. docs, scm, ci, db")
    s.add_argument("--search", help="free-text match on id, name, summary or tools")
    s.add_argument("--configured", action="store_true", help="only connectors in your registry")
    s.add_argument("--by", choices=["category", "role"], default="category", help="grouping")
    s.add_argument("--long", action="store_true", help="include summaries")
    s.add_argument("--registry", help="path to an org registry file")
    s.set_defaults(func=cmd_connectors)

    s = sub.add_parser("mcp", help="check or install MCP registration")
    s.add_argument("action", choices=["check", "install"])
    s.add_argument("--only", help="limit to one configured connector")
    s.add_argument("--registry", help="path to an org registry file")
    s.set_defaults(func=cmd_mcp)

    s = sub.add_parser("connections", help="choose which org-enabled connectors this project uses")
    s.add_argument(
        "action", nargs="?", default="list", choices=["list", "use", "add", "remove", "reset"]
    )
    s.add_argument(
        "connector", nargs="*", help="connector id(s); `use` replaces the selection entirely"
    )
    s.add_argument("--registry", help="path to an org registry file")
    s.set_defaults(func=cmd_connections)



    s = sub.add_parser("control", help="serve the MCP control plane (admin web UI)")
    s.add_argument("--port", type=int, default=8788)
    s.add_argument("--no-open", action="store_true")
    s.add_argument("--registry", help="path to an org registry file")
    s.add_argument("--verbose", action="store_true", help="log requests")
    s.set_defaults(func=cmd_control)

    s = sub.add_parser("gateway", help="run the SPAR MCP gateway (stdio), or inspect it")
    gsub = s.add_subparsers(dest="gcmd")
    gs = gsub.add_parser("status", help="connectors, policy and runtime activity")
    gs.add_argument("--registry", help="path to an org registry file")
    gs.set_defaults(func=cmd_gateway_status)
    gp = gsub.add_parser("policy", help="write a starter gateway-policy.yaml")
    gp.add_argument("--force", action="store_true")
    gp.set_defaults(func=cmd_gateway_policy)
    gv = gsub.add_parser("serve", help="run the gateway as a service for the whole organisation")
    gv.add_argument("--port", type=int, default=8790)
    gv.add_argument("--bind", default="127.0.0.1",
                    help="interface to listen on; anything but loopback needs TLS in front")
    gv.add_argument("--verbose", action="store_true")
    gv.set_defaults(func=cmd_gateway_serve)
    s.set_defaults(func=cmd_gateway)

    s = sub.add_parser("login", help="point this machine at the organisation's gateway")
    s.add_argument("url", help="e.g. https://aegis.corp.internal")
    s.add_argument("--enroll", help="the organisation enrollment token (once per machine)")
    s.add_argument("--label", help="how this machine appears in AEGIS Control")
    s.set_defaults(func=cmd_login)

    s = sub.add_parser("logout", help="forget the organisation's gateway on this machine")
    s.set_defaults(func=cmd_logout)

    s = sub.add_parser("mcp-server", help="run the SPAR MCP server (stdio)")
    s.set_defaults(func=cmd_mcp_server)

    s = sub.add_parser("doctor", help="diagnose install health")
    s.add_argument("--registry", help="path to an org registry file")
    s.set_defaults(func=cmd_doctor)

    s = sub.add_parser("export", help="bundle a feature's artifacts into one dossier")
    s.add_argument("feature")
    s.add_argument("--out", help="output file")
    s.add_argument("--format", choices=["md", "html"], default="md")
    s.set_defaults(func=cmd_export)

    s = sub.add_parser("metrics", help="delivery analytics from spar/")
    s.add_argument("feature", nargs="?")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_metrics)

    s = sub.add_parser("dashboard", help="local read-only web view of spar/")
    s.add_argument("--port", type=int, default=8787)
    s.add_argument("--no-open", action="store_true")
    s.add_argument("--verbose", action="store_true", help="log requests")
    s.set_defaults(func=cmd_dashboard)

    s = sub.add_parser("threat-model", help="how to run STRIDE threat modelling")
    s.add_argument("feature")
    s.set_defaults(func=cmd_threat_model)

    s = sub.add_parser("manifest", help="regenerate spar/manifest.json")
    s.set_defaults(func=cmd_manifest)

    s = sub.add_parser("migrate", help="move a project's artifacts from .spar/ to spar/")
    s.add_argument("path", nargs="?", help="project folder (default: current directory)")
    s.set_defaults(func=cmd_migrate)

    s = sub.add_parser("decision", help="append a hash-chained decision record")
    s.add_argument("--subject", required=True)
    s.add_argument("--subject-kind", default="human", choices=["human", "agent"])
    s.add_argument("--action-kind", default="artifact.approve")
    s.add_argument("--name", required=True)
    s.add_argument("--resource", required=True)
    s.add_argument("--verdict", required=True, choices=["pass", "blocked", "approved", "changes-requested"])
    s.add_argument("--feature")
    s.add_argument("--phase")
    s.add_argument("--explanation")
    s.add_argument("--version", dest="version", default="",
                   help="content version of the approved artifact (see `spar gate`)")
    s.set_defaults(func=cmd_decision)

    s = sub.add_parser("check", help="run deterministic checks on artifacts, the project, or verification")
    s.add_argument("--feature", help="feature id (default: the latest)")
    s.add_argument(
        "--scope",
        choices=["artifacts", "project", "verification", "all", "spec", "plan", "tasks", "verify", "tests"],
        help="artifacts | project | verification | all (spec/plan/tasks mean artifacts; verify means verification; tests means project)",
    )
    s.add_argument("--json", action="store_true")
    s.add_argument("--for-agent", action="store_true", help="print findings as a fix brief for the owning agent")
    s.add_argument("--note-analyze-attempt", action="store_true",
                   help="record that /spar.design ran against the current plan and tasks")
    s.set_defaults(func=cmd_check)

    s = sub.add_parser("checks", help="declare the project's test, lint and typecheck commands")
    s.add_argument("action", nargs="?", default="show", choices=["init", "show"])
    s.add_argument("--force", action="store_true", help="overwrite an existing checks.yaml")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_checks)

    s = sub.add_parser("verify-guard", help="prove a regression guard fails without its production fix")
    s.add_argument("--repo", default=".", help="clean Git repository root (default: current directory)")
    s.add_argument("--revert", action="append", required=True, metavar="PATH",
                   help="production path changed by HEAD to restore from HEAD^ (repeatable)")
    s.add_argument("--expect", help="text that must appear in the failing guard output")
    s.add_argument("--timeout", type=int, default=600, help="seconds allowed for each guard run")
    s.add_argument("command", nargs=argparse.REMAINDER, help="guard argv after --; never run through a shell")
    s.set_defaults(func=cmd_verify_guard)

    s = sub.add_parser("next", help="the one deterministic next action for a feature")
    s.add_argument("feature", nargs="?")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_next)

    s = sub.add_parser(
        "gate",
        help=(
            "read or decide the human gates: spar gate <feature> | approve|request-changes <feature> <gate> | "
            "exempt|unexempt <feature> <ROW-ID>... --note | defer|undefer <feature> <platform-row>... --note"
        ),
    )
    s.add_argument("action", nargs="?", help="a feature id to show, or approve | request-changes | exempt | unexempt | defer | undefer")
    s.add_argument("feature", nargs="?")
    s.add_argument("rest", nargs="*", help="the gate (approve-spec|approve-plan|checkpoint, or approve-tenets for the engineering principles), standards row ids (S-02 ...), or platform rows (cicd, cloud ...)")
    s.add_argument("--note", help="why (required for request-changes, exempt and defer)")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_gate)

    s = sub.add_parser(
        "mvp",
        help=(
            "the delivery roadmap: spar mvp list | select <M1|M2|…> --note | single --note"
        ),
    )
    s.add_argument("action", nargs="?", default="list", choices=["list", "select", "single"])
    s.add_argument("rest", nargs="*", help="the MVP id for select, e.g. M2")
    s.add_argument("--note", help="why this one, or why this is a single deliverable")
    s.add_argument("--withdraw", action="store_true", help="undo the selection or the single-deliverable ruling")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_mvp)

    s = sub.add_parser(
        "impact",
        help=("AI impact and ROI: spar impact begin|end <task> around every task, "
              "backfill [--ai-assisted-fully] from git history, report [--format text|json|md|csv]"),
    )
    isub = s.add_subparsers(dest="icmd")
    ib = isub.add_parser("begin", help="a task starts: open a measured session")
    ib.add_argument("task", help="the task id, e.g. T005")
    ib.add_argument("--feature")
    ib.add_argument("--agent", help="the agent doing the work")
    ib.add_argument("--model")
    ib.add_argument("--tool", help="the host, e.g. claude-code, spar-app, copilot")
    ib.add_argument("--json", action="store_true")
    ie = isub.add_parser("end", help="the task finished: close its session and record what changed")
    ie.add_argument("task")
    ie.add_argument("--feature")
    ie.add_argument("--status", default="done", choices=["done", "failed", "abandoned"])
    ie.add_argument("--json", action="store_true")
    ibf = isub.add_parser("backfill", help="set where measuring starts; derive history from git")
    ibf.add_argument("--ai-assisted-fully", action="store_true",
                     help="AI built this project: every commit so far counts as AI-assisted")
    ibf.add_argument("--since", help="measure from this date (YYYY-MM-DD), classifying commits by evidence")
    ibf.add_argument("--prs", action="store_true", help="also fetch merged pull requests with gh")
    ibf.add_argument("--note")
    ibf.add_argument("--json", action="store_true")
    ir = isub.add_parser("report", help="adoption, output, rework, delivery, spend and ROI")
    ir.add_argument("--format", choices=["text", "json", "md", "csv"], default="text")
    ir.add_argument("--json", action="store_true")
    ir.add_argument("--prs", action="store_true", help="refresh merged pull requests with gh first")
    ir.add_argument("--out", help="write to a file instead of stdout")
    ist = isub.add_parser("status", help="baseline and open sessions")
    ist.add_argument("--json", action="store_true")
    ic = isub.add_parser("config", help="show or set rate_per_hour, human_loc_per_hour, rework_window_days …")
    ic.add_argument("key", nargs="?")
    ic.add_argument("value", nargs="?")
    ip = isub.add_parser("price", help="list model prices, or set one ($ per million tokens)")
    ip.add_argument("model", nargs="?")
    ip.add_argument("--input", type=float)
    ip.add_argument("--output", type=float)
    ip.add_argument("--cache-read", dest="cache_read", type=float)
    ip.add_argument("--cache-write-5m", dest="cache_write_5m", type=float)
    ip.add_argument("--cache-write-1h", dest="cache_write_1h", type=float)
    ip.add_argument("--remove", action="store_true")
    iu = isub.add_parser("usage", help="record one agent turn's measured cost (the SPAR app calls this)")
    iu.add_argument("--cost-usd", dest="cost_usd", type=float, required=True)
    iu.add_argument("--agent")
    iu.add_argument("--model")
    iu.add_argument("--family")
    iu.add_argument("--session")
    iu.add_argument("--start", help="when the turn began (ISO 8601)")
    iu.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_impact)

    s = sub.add_parser("packs", help="compliance policy packs: list, show, apply, remove, guardrails")
    s.add_argument("action", nargs="?", default="list", choices=["list", "show", "apply", "remove", "guardrails"])
    s.add_argument("ids", nargs="*", help="pack id(s): hipaa, pci-dss, soc2, gdpr")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_packs)

    s = sub.add_parser("scan", help="scan added lines for card numbers, identifiers and secrets; audit dependencies")
    s.add_argument("--pan", action="store_true", help="card numbers (Luhn-checked)")
    s.add_argument("--phi", action="store_true", help="health identifiers: SSN, MRN, date of birth")
    s.add_argument("--pii", action="store_true", help="personal data: SSN, e-mail addresses")
    s.add_argument("--secrets", action="store_true", help="private keys, cloud and API tokens")
    s.add_argument("--deps", action="store_true", help="run the dependency auditor that fits the manifests")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_scan)

    s = sub.add_parser("_hook", help=argparse.SUPPRESS)
    s.add_argument("event", choices=["post-tool-use", "stop"])
    s.set_defaults(func=cmd_hook)

    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "func", None):
        parser.print_help()
        return 0
    try:
        return int(args.func(args) or 0)
    except HumanRequired as exc:
        bad(str(exc))
        return 3
    except KeyboardInterrupt:
        print()
        return 130
    except BrokenPipeError:
        return 0


if __name__ == "__main__":
    sys.exit(main())
