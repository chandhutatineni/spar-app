"""The developer side of a hosted gateway.

What runs on a developer's machine is a pipe, not a gateway. It holds no
registry, spawns no upstream process and has no credential of any kind: it
forwards each JSON-RPC frame to the organisation's gateway with that
developer's own access token, and writes the reply back to the editor.

Configuration comes from ``gateway.json`` next to the rest of the host config,
written once by ``spar login``, or from the environment so a container image or
CI job can be provisioned without an interactive step.
"""

from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

from .vault import config_dir

GATEWAY_FILE = "gateway.json"
TIMEOUT = 120.0


def gateway_path() -> Path:
    return config_dir() / GATEWAY_FILE


def remote_config() -> dict | None:
    """``{"url", "token"}`` for the hosted gateway, or None to run locally.

    The environment wins over the file so an image can override a baked-in
    login, and a URL with no token is refused rather than silently falling back
    to local mode -- that fallback would quietly give a developer a different
    set of connectors than the organisation intended.
    """
    url = os.environ.get("AEGIS_GATEWAY_URL", "").strip()
    token = os.environ.get("AEGIS_GATEWAY_TOKEN", "").strip()
    if not url:
        p = gateway_path()
        if p.is_file():
            try:
                data = json.loads(p.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                data = {}
            url = str(data.get("url") or "").strip()
            token = token or str(data.get("token") or "").strip()
    if not url:
        return None
    return {"url": url.rstrip("/"), "token": token}


def save_login(url: str, token: str, label: str = "") -> Path:
    p = gateway_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(str(p), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        json.dump({"url": url.rstrip("/"), "token": token, "label": label}, fh, indent=2)
        fh.write("\n")
    os.chmod(p, 0o600)
    return p


def forget_login() -> bool:
    p = gateway_path()
    if p.is_file():
        p.unlink()
        return True
    return False


def project_root() -> str:
    """The project this developer is working in, as the gateway needs to know it.

    Sent with every call so the gateway applies *this* project's connector
    selection and policy, rather than whatever directory it was started in.
    """
    from .cli import find_spar_root

    root = find_spar_root()
    return str(root.parent) if root else ""


def _post(url: str, body: dict, token: str = "", project: str | None = None) -> dict:
    data = json.dumps(body).encode("utf-8")
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    proj = project if project is not None else project_root()
    if proj:
        headers["X-Aegis-Project"] = proj
    req = urllib.request.Request(url, data=data, headers=headers)
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        raw = resp.read().decode("utf-8", errors="replace")
    return json.loads(raw or "{}")


def enroll(url: str, enrollment_token: str, label: str) -> dict:
    """Exchange the organisation's enrollment token for this machine's own."""
    try:
        return _post(url.rstrip("/") + "/enroll", {"enroll": enrollment_token, "label": label},
                     project="")
    except urllib.error.HTTPError as exc:
        try:
            return json.loads(exc.read().decode("utf-8", errors="replace") or "{}")
        except ValueError:
            return {"error": f"{exc.code} {exc.reason}"}
    except (urllib.error.URLError, OSError) as exc:
        return {"error": f"cannot reach {url}: {exc}"}


def check(cfg: dict) -> dict:
    """Confirm the hosted gateway answers and this token is accepted."""
    try:
        reply = _post(
            cfg["url"] + "/mcp",
            {"jsonrpc": "2.0", "id": 1, "method": "tools/list"},
            cfg.get("token", ""),
        )
    except urllib.error.HTTPError as exc:
        if exc.code == 401:
            return {"ok": False, "error": "this machine's access token was rejected or revoked"}
        return {"ok": False, "error": f"{exc.code} {exc.reason}"}
    except (urllib.error.URLError, OSError) as exc:
        return {"ok": False, "error": f"cannot reach {cfg['url']}: {exc}"}
    tools = (reply.get("result") or {}).get("tools") or []
    return {"ok": True, "tools": [t.get("name") for t in tools]}


def serve_proxy(cfg: dict) -> int:
    """Forward stdio JSON-RPC to the hosted gateway, frame for frame.

    Transport failures are answered as JSON-RPC errors rather than crashing:
    an editor that loses its gateway should say so in the conversation, not
    drop the MCP server and leave the developer wondering.
    """
    endpoint = cfg["url"] + "/mcp"
    token = cfg.get("token", "")
    # Resolved once: the editor does not change directory mid-session.
    project = project_root()

    def out(obj: dict) -> None:
        sys.stdout.write(json.dumps(obj) + "\n")
        sys.stdout.flush()

    if not token:
        sys.stderr.write(
            "spar: AEGIS_GATEWAY_URL is set but no access token is configured. "
            "Run: spar login <url> --enroll <enrollment token>\n"
        )

    for raw in sys.stdin:
        raw = raw.strip()
        if not raw:
            continue
        try:
            msg = json.loads(raw)
        except json.JSONDecodeError:
            continue
        msg_id = msg.get("id")
        try:
            reply = _post(endpoint, msg, token, project)
        except urllib.error.HTTPError as exc:
            if msg_id is None:
                continue
            detail = (
                "access token rejected -- run spar login again"
                if exc.code == 401
                else f"{exc.code} {exc.reason}"
            )
            out({"jsonrpc": "2.0", "id": msg_id,
                 "error": {"code": -32000, "message": f"gateway: {detail}"}})
            continue
        except (urllib.error.URLError, OSError) as exc:
            if msg_id is None:
                continue
            out({"jsonrpc": "2.0", "id": msg_id,
                 "error": {"code": -32000, "message": f"gateway unreachable: {exc}"}})
            continue
        except json.JSONDecodeError:
            if msg_id is None:
                continue
            out({"jsonrpc": "2.0", "id": msg_id,
                 "error": {"code": -32000, "message": "gateway returned a malformed reply"}})
            continue
        if msg_id is None:
            continue  # a notification needs no answer
        out(reply)
    return 0
