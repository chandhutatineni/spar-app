"""Human gates, read from and written to the decision ledger.

Three gates stand between the stages of a feature: approve the brief, approve
the design, and the checkpoint after a build. Each approval records the version
of the artifact it approved, so an approval of a spec that has since changed is
reported as stale rather than silently honoured.

Only a human's record can open a human gate. Agents write to the same ledger
(the analyzer's verdict, the verifier's), and those are surfaced separately.
"""

from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path

from .checks import GATE_FILES, artifact_version
from .cli import append_decision, read_decisions

SCHEMA = "spar.gate/v1"
GATES = ("approve-spec", "approve-plan", "checkpoint", "approve-release")
VERDICTS = ("approved", "changes-requested")

# The rows of the plan's platform table, as ids a person can defer by name.
# They match the `NEEDS CLARIFICATION[platform-*]` marker suffixes, so the
# question the architect raised and the deferral that answers it are the same
# word — you defer the thing you were asked about, not a translation of it.
PLATFORM_ROWS = (
    "language",
    "framework",
    "datastore",
    "cloud",
    "orchestration",
    "cicd",
    "deploy-tooling",
)


def git_identity(root: Path) -> str:
    """Who is approving: git's user.email, else $USER, else "unknown"."""
    try:
        out = subprocess.run(
            ["git", "config", "user.email"],
            cwd=str(root),
            capture_output=True,
            text=True,
            timeout=5,
        )
        if out.returncode == 0 and out.stdout.strip():
            return out.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        pass
    return os.environ.get("USER") or "unknown"


def _matches(record: dict, feature: str) -> bool:
    ctx = record.get("context") or {}
    return ctx.get("feature_id") == feature


def gate_state(spar_root: Path, feature: str) -> dict:
    """Every gate's state for one feature, plus the analyzer's latest verdict."""
    feature_dir = spar_root / "specs" / feature
    records = [r for r in read_decisions(spar_root) if "_malformed" not in r and _matches(r, feature)]

    gates: dict[str, dict] = {}
    for gate in GATES:
        files = GATE_FILES[gate]
        current = artifact_version(feature_dir, files)
        state = {
            "gate": gate,
            "artifacts": list(files),
            "approved": False,
            "changes_requested": False,
            "by": None,
            "at": None,
            "note": None,
            "version": None,
            "current": current,
            "stale": False,
        }
        # Latest human decision wins; a later changes-requested revokes an
        # earlier approval.
        latest = None
        for r in records:
            if (r.get("subject") or {}).get("kind") != "human":
                continue
            if (r.get("action") or {}).get("name") != gate:
                continue
            if r.get("verdict") not in VERDICTS:
                continue
            latest = r
        if latest is not None:
            verdict = latest.get("verdict")
            version = (latest.get("resource") or {}).get("version") or None
            state.update(
                {
                    "approved": verdict == "approved",
                    "changes_requested": verdict == "changes-requested",
                    "by": (latest.get("subject") or {}).get("id"),
                    "at": latest.get("at"),
                    "note": latest.get("explanation") or None,
                    "version": version,
                }
            )
            state["stale"] = bool(state["approved"] and version != current)
            # A changes-requested on an artifact that has since moved has been
            # answered; report it as no longer standing.
            if state["changes_requested"] and version and version != current:
                state["changes_requested"] = False
        gates[gate] = state

    analyze = None
    for r in records:
        if (r.get("subject") or {}).get("kind") != "agent":
            continue
        if "analyze" not in str((r.get("action") or {}).get("name", "")).lower():
            continue
        analyze = {
            "seq": r.get("seq"),
            "verdict": r.get("verdict"),
            "at": r.get("at"),
            "by": (r.get("subject") or {}).get("id"),
            "explanation": r.get("explanation") or "",
        }

    return {
        "schema": SCHEMA,
        "feature": feature,
        "gates": gates,
        "analyze": analyze,
        "exemptions": exemptions(records),
        "deferrals": deferrals(records),
    }


def exemptions(records: list[dict]) -> list[dict]:
    """Standards rows a human has exempted for this feature.

    A `standards.exempt` record approves the exemption; a later one with verdict
    `changes-requested` (written by `spar gate unexempt`) withdraws it. Latest per
    row wins, so the list holds only rows that currently stand exempt.
    """
    latest: dict[str, dict] = {}
    for r in records:
        if (r.get("subject") or {}).get("kind") != "human":
            continue
        action = r.get("action") or {}
        if action.get("kind") != "standards.exempt":
            continue
        row = str(action.get("name") or "").upper()
        if not row:
            continue
        latest[row] = r
    out = []
    for row, r in sorted(latest.items()):
        if r.get("verdict") != "approved":
            continue
        out.append(
            {
                "row": row,
                "seq": r.get("seq"),
                "by": (r.get("subject") or {}).get("id"),
                "at": r.get("at"),
                "note": r.get("explanation") or None,
            }
        )
    return out


ROW_ID = re.compile(r"^S-\d{2,3}$")


def exempt(spar_root: Path, feature: str, rows: list[str], note: str, withdraw: bool = False) -> list[dict]:
    """Record that a standards row does (or, with withdraw, no longer does) not apply here.

    This is the decision path the analyzer and the tenets gate were missing: a
    small project has no containers or CI to scaffold, and without a recorded
    exemption the only honest move for the architect was an open marker, which
    blocked the build for ever.
    """
    feature_dir = spar_root / "specs" / feature
    if not feature_dir.is_dir():
        raise ValueError(f"unknown feature: {feature}")
    if not rows:
        raise ValueError("name at least one standards row, e.g. S-02")
    cleaned = []
    for row in rows:
        row = row.strip().upper()
        if not ROW_ID.match(row):
            raise ValueError(f"not a standards row id: {row} (expected S-NN)")
        cleaned.append(row)
    if not withdraw and not (note or "").strip():
        raise ValueError("an exemption needs --note saying why the row does not apply")
    who = git_identity(spar_root.parent)
    written = []
    for row in cleaned:
        written.append(
            append_decision(
                spar_root,
                subject={"kind": "human", "id": who, "assurance": "asserted"},
                action={"kind": "standards.exempt", "name": row},
                resource={"type": "standard", "id": row, "version": ""},
                context={"feature_id": feature, "phase": "design"},
                verdict="changes-requested" if withdraw else "approved",
                explanation=(note or "")[:400],
            )
        )
    return written


def deferrals(records: list[dict]) -> list[dict]:
    """Platform rows a human has explicitly put off, and not yet come back to.

    Deferring is a decision, which is the whole point of recording it. "We will
    pick a CI system later" is a legitimate and common answer, and the ledger is
    what keeps it from decaying into "nobody ever picked one": the row stays
    visible, the deferral has a name and a date against it, and the build is not
    permitted to quietly fill the hole in the meantime.
    """
    latest: dict[str, dict] = {}
    for r in records:
        if (r.get("subject") or {}).get("kind") != "human":
            continue
        action = r.get("action") or {}
        if action.get("kind") != "platform.defer":
            continue
        row = str(action.get("name") or "").lower()
        if not row:
            continue
        latest[row] = r
    out = []
    for row, r in sorted(latest.items()):
        if r.get("verdict") != "approved":
            continue
        out.append(
            {
                "row": row,
                "seq": r.get("seq"),
                "by": (r.get("subject") or {}).get("id"),
                "at": r.get("at"),
                "note": r.get("explanation") or None,
            }
        )
    return out


def defer(spar_root: Path, feature: str, rows: list[str], note: str, withdraw: bool = False) -> list[dict]:
    """Record that a platform choice is deliberately being left open for now.

    The alternative people actually reach for is worse: asked to choose a CI
    system before there is anything to run in it, they pick one to make the
    question go away, and the throwaway answer is load-bearing by the time
    anyone notices. A deferral says the same "not now" without the lie, and
    unlike a shrug it leaves a row someone can be shown later.

    What it does not do is authorise a guess. Nothing downstream may assume a
    value for a deferred row — the task planner does not task it and the
    executor stops rather than inventing one, which is the difference between
    postponing a decision and skipping it.
    """
    feature_dir = spar_root / "specs" / feature
    if not feature_dir.is_dir():
        raise ValueError(f"unknown feature: {feature}")
    if not rows:
        raise ValueError(f"name at least one platform row: {', '.join(PLATFORM_ROWS)}")
    cleaned = []
    for row in rows:
        row = row.strip().lower()
        if row not in PLATFORM_ROWS:
            raise ValueError(f"not a platform row: {row} (expected one of {', '.join(PLATFORM_ROWS)})")
        cleaned.append(row)
    if not withdraw and not (note or "").strip():
        raise ValueError("a deferral needs --note saying what has to happen before it can be decided")
    who = git_identity(spar_root.parent)
    written = []
    for row in cleaned:
        written.append(
            append_decision(
                spar_root,
                subject={"kind": "human", "id": who, "assurance": "asserted"},
                action={"kind": "platform.defer", "name": row},
                resource={"type": "platform", "id": row, "version": ""},
                context={"feature_id": feature, "phase": "design"},
                verdict="changes-requested" if withdraw else "approved",
                explanation=(note or "")[:400],
            )
        )
    return written


def selected_mvp(records: list[dict]) -> dict | None:
    """Which MVP a human last chose to build, if any.

    Latest wins, and a withdrawal clears it. The ledger is the only place this
    lives: a Status column in the roadmap would be a second answer to the same
    question, and the two would disagree the first time someone edited the table
    by hand.
    """
    latest = None
    for r in records:
        if (r.get("subject") or {}).get("kind") != "human":
            continue
        if (r.get("action") or {}).get("kind") != "mvp.select":
            continue
        latest = r
    if latest is None or latest.get("verdict") != "approved":
        return None
    return {
        "id": str((latest.get("action") or {}).get("name") or "").upper(),
        "seq": latest.get("seq"),
        "by": (latest.get("subject") or {}).get("id"),
        "at": latest.get("at"),
        "note": latest.get("explanation") or None,
    }


def single_deliverable(records: list[dict]) -> dict | None:
    """Whether someone has already ruled that this project is not worth splitting.

    Asked once, remembered for ever. Without this the pipeline would re-open the
    "is this several MVPs?" question every time a brief arrived, and a question
    that keeps coming back after it has been answered trains people to click
    past it — including the time it mattered.
    """
    latest = None
    for r in records:
        # The roadmapper may record this itself (a single deliverable needs no choosing);
        # a person can overrule it either way.
        if (r.get("action") or {}).get("kind") != "roadmap.single":
            continue
        latest = r
    if latest is None or latest.get("verdict") != "approved":
        return None
    return {
        "seq": latest.get("seq"),
        "by": (latest.get("subject") or {}).get("id"),
        "at": latest.get("at"),
        "note": latest.get("explanation") or None,
    }


MVP_ID = re.compile(r"^M\d+$", re.I)


def select_mvp(spar_root: Path, mvp: str, note: str = "", withdraw: bool = False) -> dict:
    """Record which MVP a person chose to build next.

    Which one comes next is not a technical question and the pipeline is the
    wrong thing to answer it. Dependency order says what is *possible*; a
    customer commitment, a contract date or a team that is free in March say
    what is *wanted*, and none of those are written anywhere an agent can read.
    So the agent recommends and this records what the human actually said.

    It is deliberately re-runnable. Choosing again mid-project is a normal thing
    to do — priorities move — and the previous choice stays in the ledger rather
    than being overwritten, so the order things were picked in survives.
    """
    mvp = (mvp or "").strip().upper()
    if not MVP_ID.match(mvp):
        raise ValueError(f"not an MVP id: {mvp or '(empty)'} (expected M1, M2, …)")
    who = git_identity(spar_root.parent)
    return append_decision(
        spar_root,
        subject={"kind": "human", "id": who, "assurance": "asserted"},
        action={"kind": "mvp.select", "name": mvp},
        resource={"type": "mvp", "id": mvp, "version": ""},
        context={"feature_id": "", "phase": "brief"},
        verdict="changes-requested" if withdraw else "approved",
        explanation=(note or "")[:400],
    )


def mark_single(spar_root: Path, note: str, withdraw: bool = False) -> dict:
    """Record that this work is one deliverable and needs no roadmap."""
    if not withdraw and not (note or "").strip():
        raise ValueError("say why this is a single deliverable, with --note")
    from .cli import human_present
    who = git_identity(spar_root.parent)
    kind = "human" if human_present() else "agent"
    return append_decision(
        spar_root,
        subject={"kind": kind, "id": who if kind == "human" else "spar-roadmapper", "assurance": "asserted"},
        action={"kind": "roadmap.single", "name": "single"},
        resource={"type": "roadmap", "id": "single", "version": ""},
        context={"feature_id": "", "phase": "brief"},
        verdict="changes-requested" if withdraw else "approved",
        explanation=(note or "")[:400],
    )


def roadmap_state(spar_root: Path) -> dict:
    """The project-level MVP decisions, which belong to no single feature.

    `gate_state` filters by feature id and these deliberately have none: the
    choice of what to build next is made before the feature it becomes exists,
    and binding it to one would make it invisible from exactly the place it is
    read.
    """
    records = [r for r in read_decisions(spar_root) if "_malformed" not in r]
    return {"selected": selected_mvp(records), "single": single_deliverable(records)}


def decide(spar_root: Path, feature: str, gate: str, verdict: str, note: str = "") -> dict:
    """Record a human decision on a gate, bound to the artifact's current version."""
    if gate not in GATES:
        raise ValueError(f"unknown gate: {gate} (expected one of {', '.join(GATES)})")
    if verdict not in VERDICTS:
        raise ValueError(f"unknown verdict: {verdict} (expected one of {', '.join(VERDICTS)})")
    feature_dir = spar_root / "specs" / feature
    if not feature_dir.is_dir():
        raise ValueError(f"unknown feature: {feature}")
    files = GATE_FILES[gate]
    version = artifact_version(feature_dir, files)
    who = git_identity(spar_root.parent)
    return append_decision(
        spar_root,
        subject={"kind": "human", "id": who, "assurance": "asserted"},
        action={"kind": "artifact.approve", "name": gate},
        resource={"type": "artifact", "id": "+".join(files), "version": version},
        context={"feature_id": feature, "phase": gate},
        verdict=verdict,
        explanation=(note or "")[:400],
    )


# ── The ground-rules gate ────────────────────────────────────────────────────
#
# The governance trio is drafted in one pass and every item starts DRAFT. One
# human decision then accepts the set: approving strips the DRAFT/UNREVIEWED
# markers and records the trio's content hash, so the approval is bound to what
# was actually read. Requesting changes sends the note back to /spar.init.

TENETS_GATE = "approve-tenets"
TENETS_FILES = ["tenets.md", "standards.md", "references.md"]

_MARKER = re.compile(
    r"\s*\*\*\[?(?:DRAFT|UNREVIEWED)\]?\*\*"      # **DRAFT** / **[DRAFT]**
    r"|\s*\[(?:DRAFT|UNREVIEWED)\]"                # [DRAFT]
    r"|\s*\((?:DRAFT|UNREVIEWED)\)"                # (DRAFT)
    r"|\s*`(?:DRAFT|UNREVIEWED)`"                  # `DRAFT`
    r"|<!--\s*(?:DRAFT|UNREVIEWED)\s*-->"          # <!-- DRAFT -->
    r"|\b(?:DRAFT|UNREVIEWED)\s*[:—–-]\s*"         # "DRAFT: ", "DRAFT — "
)


def _strip_markers(text: str) -> str:
    # A table cell holding only the marker keeps its cell, empty.
    out = re.sub(r"\|[ \t]*(?:DRAFT|UNREVIEWED)[ \t]*(?=\|)", "| ", text)
    # "(DRAFT, T-010)" -> "(T-010)"; a cell opening "DRAFT. Local…" -> "Local…".
    out = re.sub(r"\(\s*(?:DRAFT|UNREVIEWED)\s*[,;]\s*", "(", out)
    out = re.sub(r"(?<=\| )(?:DRAFT|UNREVIEWED)\.\s*", "", out)
    out = _MARKER.sub("", out)
    # A status line that said only "DRAFT" now reads "reviewed".
    return re.sub(r"(?im)^(\s*[*_]*status[*_]*\s*:\s*)(?:DRAFT|UNREVIEWED)\b", r"\1Reviewed", out)


def tenets_state(spar_root: Path) -> dict:
    """The latest human decision on the trio, and whether it still matches the files."""
    records = [r for r in read_decisions(spar_root) if "_malformed" not in r]
    latest = None
    for r in records:
        if (r.get("action") or {}).get("name") == TENETS_GATE and (r.get("subject") or {}).get("kind") == "human":
            latest = r
    current = artifact_version(spar_root, TENETS_FILES)
    if latest is None:
        return {"approved": False, "changes_requested": False, "stale": False, "note": None, "by": None, "at": None}
    version = (latest.get("resource") or {}).get("version", "")
    return {
        "approved": latest.get("verdict") == "approved",
        "changes_requested": latest.get("verdict") == "changes-requested",
        "stale": version != current,
        "note": latest.get("explanation") or None,
        "by": (latest.get("subject") or {}).get("id"),
        "at": latest.get("at"),
    }


def decide_tenets(spar_root: Path, verdict: str, note: str = "") -> dict:
    """Approve the engineering principles as a set (clearing DRAFT markers) or send them back."""
    if verdict not in VERDICTS:
        raise ValueError(f"unknown verdict: {verdict} (expected one of {', '.join(VERDICTS)})")
    if not (spar_root / "tenets.md").is_file():
        raise ValueError("there are no engineering principles yet: run /spar.init first")
    who = git_identity(spar_root.parent)
    if verdict == "approved":
        from datetime import date
        stamp = f"> Approved by {who} on {date.today().isoformat()}."
        for name in TENETS_FILES:
            p = spar_root / name
            if p.is_file():
                text = p.read_text(encoding="utf-8")
                cleaned = _strip_markers(text)
                # Say so under the title, replacing an earlier stamp.
                lines = [l for l in cleaned.split("\n") if not l.startswith("> Approved by ")]
                at = next((i for i, l in enumerate(lines) if l.startswith("# ")), -1)
                lines.insert(at + 1, "") if at >= 0 else None
                lines.insert(at + 2 if at >= 0 else 0, stamp)
                cleaned = re.sub(r"\n{3,}", "\n\n", "\n".join(lines))
                if cleaned != text:
                    p.write_text(cleaned, encoding="utf-8")
    return append_decision(
        spar_root,
        subject={"kind": "human", "id": who, "assurance": "asserted"},
        action={"kind": "artifact.approve", "name": TENETS_GATE},
        resource={"type": "artifact", "id": "+".join(TENETS_FILES), "version": artifact_version(spar_root, TENETS_FILES)},
        context={"feature_id": "", "phase": "brief"},
        verdict=verdict,
        explanation=(note or "")[:400],
    )


# ── Bug fixes ────────────────────────────────────────────────────────────────
#
# /spar.fix leaves spar/fixes/<id>.md and stops for one review. The approval is
# bound to the record's content, like every other gate.

FIX_GATE = "approve-fix"


def _fix_version(spar_root: Path, fix_id: str) -> str:
    return artifact_version(spar_root / "fixes", [f"{fix_id}.md"])


def fix_state(spar_root: Path, fix_id: str) -> dict:
    latest = None
    for r in read_decisions(spar_root):
        if "_malformed" in r:
            continue
        if (r.get("action") or {}).get("name") == FIX_GATE and (r.get("resource") or {}).get("id") == fix_id:
            latest = r
    if latest is None:
        return {"approved": False, "changes_requested": False, "stale": False, "note": None}
    return {
        "approved": latest.get("verdict") == "approved",
        "changes_requested": latest.get("verdict") == "changes-requested",
        "stale": (latest.get("resource") or {}).get("version") != _fix_version(spar_root, fix_id),
        "note": latest.get("explanation") or None,
    }


def pending_fixes(spar_root: Path) -> list[tuple[str, dict]]:
    """Fix records nobody has approved yet (oldest first)."""
    d = spar_root / "fixes"
    out = []
    for p in sorted(d.glob("*.md")) if d.is_dir() else []:
        st = fix_state(spar_root, p.stem)
        if not st["approved"]:
            out.append((p.stem, st))
    return out


def decide_fix(spar_root: Path, fix_id: str, verdict: str, note: str = "") -> dict:
    if verdict not in VERDICTS:
        raise ValueError(f"unknown verdict: {verdict} (expected one of {', '.join(VERDICTS)})")
    if not (spar_root / "fixes" / f"{fix_id}.md").is_file():
        raise ValueError(f"unknown fix: {fix_id} (expected spar/fixes/{fix_id}.md)")
    who = git_identity(spar_root.parent)
    return append_decision(
        spar_root,
        subject={"kind": "human", "id": who, "assurance": "asserted"},
        action={"kind": "artifact.approve", "name": FIX_GATE},
        resource={"type": "fix", "id": fix_id, "version": _fix_version(spar_root, fix_id)},
        context={"feature_id": "", "phase": "fix"},
        verdict=verdict,
        explanation=(note or "")[:400],
    )
