"""Who may use the gateway, and what they may reach.

Two ways in, and the second only engages if you configure it:

* **A machine key.** An administrator opens enrollment once; each developer
  machine exchanges that for its own token. This is the default and needs
  nothing but the gateway.
* **A person, via your identity provider.** Put a reverse proxy in front that
  terminates OIDC -- oauth2-proxy, Envoy, nginx ``auth_request`` -- and the
  gateway takes the identity and group claims it passes down. Then access dies
  with the IdP account instead of waiting for someone to click Revoke, and group
  claims can scope which systems a team may reach.

Both are authorisation subjects with the same shape, so everything downstream --
scoping, attribution, the ledger -- treats them identically.

State lives in SQLite. Not for scale: for atomicity. The previous JSON file was
read-modify-written on every single call by a threaded server, so two concurrent
developers lost each other's updates and, worse, a call in flight could write
back a row it had read *before* an administrator revoked it -- silently undoing
the revocation. A single UPDATE cannot do that.

Only SHA-256 digests of tokens are stored. A token is 32 bytes of ``secrets``
entropy, so the digest is not usefully attackable, and plaintext is returned
exactly once, at issue.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import sqlite3
import threading
from contextlib import closing
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .vault import config_dir

ACCESS_DB = "access.db"
LEGACY_FILE = "access.json"
TOKEN_BYTES = 32
DEFAULT_TTL_DAYS = 90

_lock = threading.Lock()


def db_path() -> Path:
    return config_dir() / ACCESS_DB


def _connect() -> sqlite3.Connection:
    p = db_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    fresh = not p.exists()
    conn = sqlite3.connect(str(p), timeout=10.0, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS subjects(
          id        TEXT PRIMARY KEY,
          kind      TEXT NOT NULL DEFAULT 'key',   -- 'key' | 'person'
          label     TEXT NOT NULL,
          sha256    TEXT UNIQUE,                   -- NULL for IdP-backed people
          issuer    TEXT DEFAULT '',
          created   TEXT NOT NULL,
          expires   TEXT DEFAULT '',
          last_seen TEXT DEFAULT '',
          calls     INTEGER NOT NULL DEFAULT 0,
          revoked   INTEGER NOT NULL DEFAULT 0,
          revoked_at TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS enrollment(
          id INTEGER PRIMARY KEY CHECK(id = 1),
          sha256 TEXT NOT NULL,
          created TEXT NOT NULL
        );
        -- No rows for a subject means "everything the organisation enabled".
        CREATE TABLE IF NOT EXISTS subject_scopes(
          subject_id TEXT NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
          connector  TEXT NOT NULL,
          PRIMARY KEY (subject_id, connector)
        );
        CREATE TABLE IF NOT EXISTS group_scopes(
          group_name TEXT NOT NULL,
          connector  TEXT NOT NULL,
          PRIMARY KEY (group_name, connector)
        );
        CREATE TABLE IF NOT EXISTS config(
          key TEXT PRIMARY KEY,
          value TEXT NOT NULL
        );
        """
    )
    if fresh:
        _import_legacy(conn)
    return conn


def _import_legacy(conn: sqlite3.Connection) -> None:
    """Carry an existing access.json across, once, so nobody re-enrols."""
    old = config_dir() / LEGACY_FILE
    if not old.is_file():
        return
    try:
        data = json.loads(old.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return
    e = data.get("enrollment")
    if isinstance(e, dict) and e.get("sha256"):
        conn.execute(
            "INSERT OR REPLACE INTO enrollment(id, sha256, created) VALUES(1, ?, ?)",
            (e["sha256"], e.get("at", _now())),
        )
    for s in data.get("subjects", []) or []:
        if not s.get("id") or not s.get("sha256"):
            continue
        conn.execute(
            "INSERT OR IGNORE INTO subjects"
            "(id, kind, label, sha256, created, last_seen, calls, revoked, revoked_at)"
            " VALUES(?,'key',?,?,?,?,?,?,?)",
            (
                s["id"],
                s.get("label", "developer"),
                s["sha256"],
                s.get("at", _now()),
                s.get("last_seen", ""),
                int(s.get("calls") or 0),
                1 if s.get("revoked") else 0,
                s.get("revoked_at", ""),
            ),
        )
    old.rename(old.with_suffix(".json.migrated"))


def _now() -> str:
    from .cli import now_iso

    return now_iso()


def _digest(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S+00:00")


def _expired(expires: str) -> bool:
    if not expires:
        return False
    try:
        return datetime.now(timezone.utc) > datetime.fromisoformat(expires)
    except ValueError:
        return False


# --------------------------------------------------------------------------- #
# Configuration: the trusted proxy, and how long a machine token lives
# --------------------------------------------------------------------------- #


def get_config() -> dict:
    with _lock, closing(_connect()) as conn:
        rows = conn.execute("SELECT key, value FROM config").fetchall()
    cfg = {r["key"]: r["value"] for r in rows}
    return {
        # OIDC only engages when a proxy is named here. Empty means key-only.
        "proxy_peers": [p for p in (cfg.get("proxy_peers", "") or "").split(",") if p],
        "proxy_user_header": cfg.get("proxy_user_header", "X-Auth-Request-Email"),
        "proxy_groups_header": cfg.get("proxy_groups_header", "X-Auth-Request-Groups"),
        "token_ttl_days": int(cfg.get("token_ttl_days", DEFAULT_TTL_DAYS)),
    }


def set_config(**kw) -> dict:
    allowed = {"proxy_peers", "proxy_user_header", "proxy_groups_header", "token_ttl_days"}
    bad = set(kw) - allowed
    if bad:
        raise ValueError("not a setting: " + ", ".join(sorted(bad)))
    with _lock, closing(_connect()) as conn:
        for key, val in kw.items():
            if key == "proxy_peers" and isinstance(val, list):
                val = ",".join(str(v).strip() for v in val if str(v).strip())
            conn.execute(
                "INSERT INTO config(key, value) VALUES(?,?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, str(val)),
            )
    return get_config()


def oidc_enabled() -> bool:
    return bool(get_config()["proxy_peers"])


# --------------------------------------------------------------------------- #
# Enrollment
# --------------------------------------------------------------------------- #


def rotate_enrollment() -> str:
    """Issue a new enrollment token; the previous one stops enrolling.

    Already-enrolled machines are unaffected -- their own tokens keep working.
    """
    token = secrets.token_urlsafe(TOKEN_BYTES)
    with _lock, closing(_connect()) as conn:
        conn.execute(
            "INSERT INTO enrollment(id, sha256, created) VALUES(1,?,?) "
            "ON CONFLICT(id) DO UPDATE SET sha256=excluded.sha256, created=excluded.created",
            (_digest(token), _now()),
        )
    return token


def enrollment_state() -> dict:
    with _lock, closing(_connect()) as conn:
        row = conn.execute("SELECT created FROM enrollment WHERE id=1").fetchone()
    return {"set": bool(row), "at": row["created"] if row else ""}


def clear_enrollment() -> bool:
    with _lock, closing(_connect()) as conn:
        cur = conn.execute("DELETE FROM enrollment WHERE id=1")
    return cur.rowcount > 0


def enroll(enrollment_token: str, label: str, scope: list[str] | None = None) -> dict:
    """Exchange the org enrollment token for this machine's own token."""
    with _lock, closing(_connect()) as conn:
        row = conn.execute("SELECT sha256 FROM enrollment WHERE id=1").fetchone()
        if not row:
            return {"error": "enrollment is closed; ask an administrator to open it"}
        if not hmac.compare_digest(_digest(enrollment_token or ""), row["sha256"]):
            return {"error": "that enrollment token is not valid"}
        ttl = int(
            (conn.execute("SELECT value FROM config WHERE key='token_ttl_days'").fetchone()
             or {"value": DEFAULT_TTL_DAYS})["value"]
        )
        label = (label or "developer").strip()[:80] or "developer"
        token = secrets.token_urlsafe(TOKEN_BYTES)
        sid = secrets.token_hex(6)
        expires = _iso(datetime.now(timezone.utc) + timedelta(days=ttl)) if ttl > 0 else ""
        conn.execute(
            "INSERT INTO subjects(id, kind, label, sha256, created, expires) "
            "VALUES(?,'key',?,?,?,?)",
            (sid, label, _digest(token), _now(), expires),
        )
        for c in scope or []:
            conn.execute(
                "INSERT OR IGNORE INTO subject_scopes(subject_id, connector) VALUES(?,?)",
                (sid, str(c)),
            )
    return {"id": sid, "token": token, "label": label, "expires": expires}


# --------------------------------------------------------------------------- #
# Authentication
# --------------------------------------------------------------------------- #


def authenticate(token: str) -> dict | None:
    """The subject a machine token belongs to, or None.

    Comparison is constant-time. Expiry and revocation are both checked here, so
    there is one place a stale credential can be turned away.
    """
    if not token:
        return None
    want = _digest(token)
    with _lock, closing(_connect()) as conn:
        row = conn.execute(
            "SELECT id, label, kind, expires, revoked FROM subjects WHERE sha256 = ?", (want,)
        ).fetchone()
        if not row or row["revoked"]:
            return None
        if _expired(row["expires"]):
            return None
        # One statement, so a concurrent revoke cannot be written back over.
        conn.execute(
            "UPDATE subjects SET last_seen=?, calls=calls+1 WHERE id=? AND revoked=0",
            (_now(), row["id"]),
        )
    return {"id": row["id"], "label": row["label"], "kind": row["kind"], "groups": []}


def token_state(token: str) -> str:
    """Why a token was refused, for a message a developer can act on."""
    if not token:
        return "missing"
    with _lock, closing(_connect()) as conn:
        row = conn.execute(
            "SELECT expires, revoked FROM subjects WHERE sha256 = ?", (_digest(token),)
        ).fetchone()
    if not row:
        return "unknown"
    if row["revoked"]:
        return "revoked"
    if _expired(row["expires"]):
        return "expired"
    return "valid"


def identify_person(email: str, groups: list[str], issuer: str = "proxy") -> dict:
    """The subject for an identity a trusted proxy vouched for.

    People are not enrolled in advance: the IdP is the register, so a subject row
    appears the first time someone appears and is kept for attribution. Their
    authorisation comes from group scopes, never from the row itself -- which is
    the point of using the IdP.
    """
    email = (email or "").strip()[:120]
    if not email:
        return {}
    sid = "p" + hashlib.sha256(f"{issuer}|{email}".encode("utf-8")).hexdigest()[:11]
    with _lock, closing(_connect()) as conn:
        row = conn.execute("SELECT revoked FROM subjects WHERE id=?", (sid,)).fetchone()
        if row and row["revoked"]:
            return {}
        conn.execute(
            "INSERT INTO subjects(id, kind, label, sha256, issuer, created, last_seen, calls) "
            "VALUES(?,'person',?,NULL,?,?,?,1) "
            "ON CONFLICT(id) DO UPDATE SET last_seen=excluded.last_seen, calls=calls+1, "
            "label=excluded.label",
            (sid, email, issuer, _now(), _now()),
        )
    return {"id": sid, "label": email, "kind": "person", "groups": list(groups or [])}


# --------------------------------------------------------------------------- #
# Authorisation: which connectors a subject may reach
# --------------------------------------------------------------------------- #


def scopes_for(subject: dict) -> set[str] | None:
    """Connector ids this subject may reach, or None for everything enabled.

    A machine key carries its own scope. A person's comes from the union of their
    group scopes -- so adding someone to a team in your IdP grants access without
    anyone touching this gateway. No matching rows at all means unrestricted,
    which keeps a fresh install working before anyone has scoped anything.
    """
    if not subject:
        return set()
    with _lock, closing(_connect()) as conn:
        rows = conn.execute(
            "SELECT connector FROM subject_scopes WHERE subject_id=?", (subject.get("id", ""),)
        ).fetchall()
        allowed = {r["connector"] for r in rows}
        groups = subject.get("groups") or []
        if groups:
            marks = ",".join("?" for _ in groups)
            grows = conn.execute(
                f"SELECT connector FROM group_scopes WHERE group_name IN ({marks})", tuple(groups)
            ).fetchall()
            allowed |= {r["connector"] for r in grows}
            # A person in a group that has been scoped is bound by it; a person
            # in no scoped group at all is unrestricted rather than locked out.
            any_group_scoped = conn.execute(
                f"SELECT 1 FROM group_scopes WHERE group_name IN ({marks}) LIMIT 1", tuple(groups)
            ).fetchone()
            if not rows and not any_group_scoped:
                return None
        elif not rows:
            return None
    return allowed


def set_subject_scope(subject_id: str, connectors: list[str]) -> bool:
    with _lock, closing(_connect()) as conn:
        if not conn.execute("SELECT 1 FROM subjects WHERE id=?", (subject_id,)).fetchone():
            return False
        conn.execute("DELETE FROM subject_scopes WHERE subject_id=?", (subject_id,))
        for c in connectors or []:
            conn.execute(
                "INSERT OR IGNORE INTO subject_scopes(subject_id, connector) VALUES(?,?)",
                (subject_id, str(c)),
            )
    return True


def set_group_scope(group: str, connectors: list[str]) -> bool:
    group = (group or "").strip()
    if not group:
        return False
    with _lock, closing(_connect()) as conn:
        conn.execute("DELETE FROM group_scopes WHERE group_name=?", (group,))
        for c in connectors or []:
            conn.execute(
                "INSERT OR IGNORE INTO group_scopes(group_name, connector) VALUES(?,?)",
                (group, str(c)),
            )
    return True


def group_scopes() -> dict:
    with _lock, closing(_connect()) as conn:
        rows = conn.execute(
            "SELECT group_name, connector FROM group_scopes ORDER BY group_name, connector"
        ).fetchall()
    out: dict[str, list[str]] = {}
    for r in rows:
        out.setdefault(r["group_name"], []).append(r["connector"])
    return out


# --------------------------------------------------------------------------- #
# Administration
# --------------------------------------------------------------------------- #


def revoke(subject_id: str) -> bool:
    with _lock, closing(_connect()) as conn:
        cur = conn.execute(
            "UPDATE subjects SET revoked=1, revoked_at=? WHERE id=? AND revoked=0",
            (_now(), subject_id),
        )
    return cur.rowcount > 0


def subjects() -> list[dict]:
    """Everyone with access, without any digest."""
    with _lock, closing(_connect()) as conn:
        rows = conn.execute(
            "SELECT s.id, s.kind, s.label, s.issuer, s.created, s.expires, s.last_seen, "
            "s.calls, s.revoked, "
            "(SELECT group_concat(connector) FROM subject_scopes WHERE subject_id=s.id) AS scope "
            "FROM subjects s ORDER BY s.created"
        ).fetchall()
    out = []
    for r in rows:
        out.append(
            {
                "id": r["id"],
                "kind": r["kind"],
                "label": r["label"],
                "issuer": r["issuer"] or "",
                "at": r["created"],
                "expires": r["expires"] or "",
                "expired": _expired(r["expires"] or ""),
                "last_seen": r["last_seen"] or "",
                "calls": int(r["calls"] or 0),
                "revoked": bool(r["revoked"]),
                "scope": [c for c in (r["scope"] or "").split(",") if c],
            }
        )
    return out


def anyone_enrolled() -> bool:
    with _lock, closing(_connect()) as conn:
        row = conn.execute("SELECT 1 FROM subjects WHERE revoked=0 LIMIT 1").fetchone()
    return bool(row)
