"""SPAR impact: what AI-assisted building delivered, and what it cost.

Every number comes from a source that can be checked, and the report names
which one. Nothing is filled in:

* ``spar/impact/events.jsonl``: ``spar impact begin`` and ``end`` around each
  task. They give wall-clock time, the working-tree lines changed (from a shadow
  snapshot, so uncommitted work counts), and the commits made. **measured**
* The git history: commits, lines, authors, AI evidence in commit trailers, and
  rework found with ``git blame``. **measured**
* Claude Code transcripts for this project give tokens per model (**measured**)
  and cost where the model has a published or configured price (**priced**).
* The SPAR app's own per-turn cost from its agent engine. **reported**
* Hours for commits made outside a session come from commit timing (**estimated**).
  Hourly rate and human lines per hour are **assumed** until the person sets them.

A metric with no source is reported as unavailable, never as zero.
"""

from __future__ import annotations

import csv
import io
import json
import os
import re
import shutil
import statistics
import subprocess
import uuid
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

SCHEMA = "spar.impact/v1"

DEFAULTS = {
    "rate_per_hour": 100.0,
    "currency": "USD",
    "human_loc_per_hour": 25.0,
    "rework_window_days": 21,
    "session_gap_minutes": 120,
    "session_lead_minutes": 30,
}


def _std(i: float, o: float) -> dict:
    return {"input": i, "output": o, "cache_read": round(i * 0.1, 4),
            "cache_write_5m": round(i * 1.25, 4), "cache_write_1h": round(i * 2, 4)}


# Anthropic list prices, USD per million tokens (anthropic.com/pricing). Only
# models with a published price are here. Anything else stays unpriced until the
# person sets a price with `spar impact price`. A guessed price would make every
# ROI figure downstream wrong.
PRICES = {
    "claude-opus-4-5": _std(5, 25),
    "claude-opus-4-1": _std(15, 75),
    "claude-opus-4": _std(15, 75),
    "claude-sonnet-4-5": _std(3, 15),
    "claude-sonnet-4": _std(3, 15),
    "claude-3-7-sonnet": _std(3, 15),
    "claude-haiku-4-5": _std(1, 5),
    "claude-3-5-haiku": _std(0.8, 4),
}
# Requests over 200K input tokens on these models are billed at the long-context rate.
LONG_CONTEXT = {"claude-sonnet-4-5": _std(6, 22.5), "claude-sonnet-4": _std(6, 22.5)}

LOCKFILES = {
    "package-lock.json", "npm-shrinkwrap.json", "yarn.lock", "pnpm-lock.yaml", "bun.lockb",
    "Cargo.lock", "poetry.lock", "uv.lock", "Pipfile.lock", "Gemfile.lock", "go.sum",
    "composer.lock", "Package.resolved", "pubspec.lock", "mix.lock", "flake.lock",
}
GENERATED_SEGMENTS = {"node_modules", "dist", "build", "vendor", "target", ".next",
                      "coverage", "__pycache__", ".venv", "venv", ".build"}
DOC_EXT = {".md", ".mdx", ".rst", ".txt", ".adoc"}
CONFIG_EXT = {".json", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".conf", ".xml", ".plist",
              ".properties", ".env", ".lock", ".gradle"}
CONFIG_NAMES = {"Dockerfile", "Makefile", ".gitignore", ".dockerignore", ".editorconfig",
                ".prettierrc", ".eslintrc", "Procfile"}
TEST_DIR = re.compile(r"(^|/)(tests?|__tests__|spec|specs|e2e|cypress|playwright)/", re.I)
TEST_FILE = re.compile(r"([._-](test|spec|e2e)\.[A-Za-z0-9]+$)|(^test_[^/]*$)|(_test\.[A-Za-z0-9]+$)")
DELIVERED = ("code", "test")

# Evidence of an AI tool in a commit: trailers, bot authors, tool conventions.
AI_SIGNS = [
    ("Claude Code", re.compile(r"co-authored-by:\s*claude\b|noreply@anthropic\.com|generated with \[?claude code", re.I)),
    ("GitHub Copilot", re.compile(r"co-authored-by:[^\n]*copilot|copilot-swe-agent", re.I)),
    ("Cursor", re.compile(r"co-authored-by:[^\n]*cursor|cursoragent@cursor\.com", re.I)),
    ("OpenAI Codex", re.compile(r"co-authored-by:[^\n]*codex|chatgpt-codex-connector", re.I)),
    ("Aider", re.compile(r"^aider: |\(aider\)|co-authored-by:[^\n]*aider", re.I | re.M)),
    ("Devin", re.compile(r"devin-ai-integration|co-authored-by:[^\n]*devin", re.I)),
    ("Gemini", re.compile(r"co-authored-by:[^\n]*gemini", re.I)),
    ("Windsurf", re.compile(r"co-authored-by:[^\n]*(windsurf|codeium)", re.I)),
    ("Amp", re.compile(r"ampcode\.com", re.I)),
    ("Junie", re.compile(r"co-authored-by:[^\n]*junie", re.I)),
]
SPAR_TRAILER = re.compile(r"^spar-task:\s*(?:(\S+)/)?(T\d+)\b", re.I | re.M)
_HUNK = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+\d+(?:,\d+)? @@")
_TASK_LINE = re.compile(r"^\s*[-*]\s+\[( |x|X)\]\s+\**(T\d+)\b")


class ImpactError(Exception):
    pass


# --------------------------------------------------------------------------- #
# Time
# --------------------------------------------------------------------------- #


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _parse(s) -> datetime | None:
    if not s or not isinstance(s, str):
        return None
    t = s.strip().replace("Z", "+00:00")
    # Python 3.9 accepts only 3 or 6 fraction digits.
    m = re.match(r"^(.*T\d\d:\d\d:\d\d)\.(\d+)(.*)$", t)
    if m:
        t = f"{m.group(1)}.{(m.group(2) + '000000')[:6]}{m.group(3)}"
    try:
        dt = datetime.fromisoformat(t)
    except ValueError:
        try:
            dt = datetime.fromisoformat(t[:10])
        except ValueError:
            return None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def _week(dt: datetime) -> str:
    y, w, _ = dt.isocalendar()
    return f"{y}-W{w:02d}"


def _hours(seconds: float) -> float:
    return round(seconds / 3600.0, 2)


def _median(xs):
    xs = [x for x in xs if x is not None]
    return round(statistics.median(xs), 2) if xs else None


# --------------------------------------------------------------------------- #
# Storage
# --------------------------------------------------------------------------- #


def impact_dir(spar_root: Path) -> Path:
    return spar_root / "impact"


def cache_dir(spar_root: Path) -> Path:
    return spar_root / "cache" / "impact"


def events_path(spar_root: Path) -> Path:
    return impact_dir(spar_root) / "events.jsonl"


def config_path(spar_root: Path) -> Path:
    return impact_dir(spar_root) / "config.json"


def read_events(spar_root: Path) -> list[dict]:
    p = events_path(spar_root)
    if not p.is_file():
        return []
    out = []
    for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            ev = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(ev, dict) and ev.get("type"):
            out.append(ev)
    return out


def _append(spar_root: Path, ev: dict) -> dict:
    p = events_path(spar_root)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(ev, sort_keys=True) + "\n")
    return ev


def read_config(spar_root: Path) -> dict:
    cfg = {**DEFAULTS, "prices": {}, "baseline": None}
    p = config_path(spar_root)
    if p.is_file():
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                cfg.update(data)
        except json.JSONDecodeError:
            pass
    return cfg


def write_config(spar_root: Path, cfg: dict) -> None:
    """Write the stored settings only: anything left at its default stays absent, so it is labelled assumed."""
    p = config_path(spar_root)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(cfg, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _store_baseline(spar_root: Path, baseline: dict) -> None:
    stored = _read_json(config_path(spar_root), {})
    stored = stored if isinstance(stored, dict) else {}
    stored["baseline"] = baseline
    write_config(spar_root, stored)


def _read_json(p: Path, default):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default


def _write_json(p: Path, data) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(data, sort_keys=True), encoding="utf-8")
    tmp.replace(p)


# --------------------------------------------------------------------------- #
# Git
# --------------------------------------------------------------------------- #


def _git(cwd: Path, *args: str, env: dict | None = None, timeout: int = 600) -> subprocess.CompletedProcess:
    try:
        return subprocess.run(["git", "-c", "core.quotepath=off", *args], cwd=str(cwd), capture_output=True,
                              text=True, encoding="utf-8", errors="replace", env=env, timeout=timeout)
    except (OSError, subprocess.SubprocessError) as exc:
        return subprocess.CompletedProcess(args, 1, "", str(exc))


def git_top(root: Path) -> Path | None:
    out = _git(root, "rev-parse", "--show-toplevel")
    if out.returncode != 0 or not out.stdout.strip():
        return None
    return Path(out.stdout.strip())


def _has_commits(top: Path) -> bool:
    return _git(top, "rev-parse", "--verify", "-q", "HEAD").returncode == 0


def _git_user(root: Path) -> str:
    out = _git(root, "config", "user.email")
    return out.stdout.strip() if out.returncode == 0 else ""


def _shadow(spar_root: Path, root: Path) -> dict:
    gd = cache_dir(spar_root) / "snapshots.git"
    env = {k: v for k, v in os.environ.items() if not k.startswith("GIT_")}
    env.update({"GIT_DIR": str(gd), "GIT_WORK_TREE": str(root),
                "GIT_AUTHOR_NAME": "SPAR impact", "GIT_AUTHOR_EMAIL": "impact@spar.local",
                "GIT_COMMITTER_NAME": "SPAR impact", "GIT_COMMITTER_EMAIL": "impact@spar.local"})
    return env


def snapshot(spar_root: Path, root: Path, label: str) -> str | None:
    """Commit the whole working tree to a shadow repository and return the id.

    The project's own .git is never touched. Its .gitignore rules apply, so
    dependencies and build output stay out.
    """
    env = _shadow(spar_root, root)
    gd = Path(env["GIT_DIR"])
    if not (gd / "HEAD").is_file():
        gd.parent.mkdir(parents=True, exist_ok=True)
        if _git(root, "init", "-q", "--bare", str(gd)).returncode != 0:
            return None
        _git(root, "config", "core.bare", "false", env=env)
        try:
            spar_rel = spar_root.resolve().relative_to(root.resolve()).as_posix()
        except ValueError:
            spar_rel = "spar"
        exclude = [".git", ".DS_Store", "node_modules/", ".build/", "target/", "dist/", ".next/", ".venv/",
                   "venv/", "__pycache__/", ".codegraph/", f"/{spar_rel}/cache/", f"/{spar_rel}/impact/"]
        (gd / "info").mkdir(exist_ok=True)
        (gd / "info" / "exclude").write_text("\n".join(exclude) + "\n", encoding="utf-8")
    if _git(root, "add", "-A", ".", env=env).returncode != 0:
        return None
    _git(root, "-c", "commit.gpgsign=false", "commit", "-q", "--allow-empty", "--no-verify", "-m", label[:200], env=env)
    out = _git(root, "rev-parse", "HEAD", env=env)
    return out.stdout.strip() if out.returncode == 0 and out.stdout.strip() else None


def _parse_z_entries(tokens: list[str]) -> tuple[dict, list]:
    """Parse the NUL-separated --raw and --numstat entries of one commit."""
    raw: dict[str, str] = {}
    nums: list[tuple[str, int | None, int | None]] = []
    i = 0
    while i < len(tokens):
        t = tokens[i].lstrip("\n")
        i += 1
        if not t:
            continue
        if t.startswith(":"):
            fields = t[1:].split(" ")
            status = fields[4] if len(fields) > 4 else "M"
            new_sha = fields[3] if len(fields) > 3 else ""
            if status[:1] in ("R", "C"):
                path = tokens[i + 1] if i + 1 < len(tokens) else ""
                i += 2
            else:
                path = tokens[i] if i < len(tokens) else ""
                i += 1
            raw[path] = new_sha
            continue
        m = re.match(r"^(\d+|-)\t(\d+|-)\t(.*)$", t, re.S)
        if not m:
            continue
        path = m.group(3)
        if path == "":
            path = tokens[i + 1] if i + 1 < len(tokens) else ""
            i += 2
        a = None if m.group(1) == "-" else int(m.group(1))
        d = None if m.group(2) == "-" else int(m.group(2))
        nums.append((path, a, d))
    return raw, nums


def read_commits(top: Path, pathspec: list[str]) -> list[dict]:
    """Every non-merge commit touching *pathspec*, oldest first, with per-file lines."""
    fmt = "%x1e%H%x1f%aN%x1f%aE%x1f%aI%x1f%P%x1f%B%x1d"
    out = _git(top, "log", "--no-merges", "-M", "--raw", "--numstat", "--no-abbrev", "-z",
               f"--format={fmt}", "--", *pathspec, timeout=1800)
    if out.returncode != 0:
        return []
    commits = []
    for rec in out.stdout.split("\x1e"):
        if not rec.strip():
            continue
        head, _, rest = rec.partition("\x1d")
        parts = head.split("\x1f")
        if len(parts) < 6:
            continue
        sha, name, email, when, parents, body = parts[0], parts[1], parts[2], parts[3], parts[4], parts[5]
        raw, nums = _parse_z_entries(rest.split("\0"))
        files = [{"path": p, "added": a, "removed": d, "blob": raw.get(p, "")} for p, a, d in nums]
        commits.append({"sha": sha.strip(), "author": name, "email": email.lower(), "at": _parse(when),
                        "parents": parents.split(), "message": body, "files": files})
    commits.reverse()
    return [c for c in commits if c["at"] is not None]


def read_merges(top: Path, pathspec: list[str]) -> list[dict]:
    out = _git(top, "log", "--merges", "--format=%H%x1f%aI%x1f%s", "--", *pathspec)
    merges = []
    for line in out.stdout.splitlines():
        parts = line.split("\x1f")
        if len(parts) == 3:
            m = re.search(r"Merge pull request #(\d+)", parts[2])
            merges.append({"sha": parts[0], "at": _parse(parts[1]), "pr": int(m.group(1)) if m else None})
    return merges


# --------------------------------------------------------------------------- #
# Files
# --------------------------------------------------------------------------- #


def category(path: str, spar_rel: str = "spar") -> str:
    p = path.replace("\\", "/")
    name = p.rsplit("/", 1)[-1]
    segs = p.split("/")[:-1]
    if name in LOCKFILES or any(s in GENERATED_SEGMENTS for s in segs) or \
            name.endswith((".min.js", ".min.css", ".map", ".snap", ".pb.go", ".g.dart")):
        return "generated"
    if p.startswith(spar_rel + "/") or p.startswith(".spar/"):
        return "spec"
    if TEST_DIR.search(p) or TEST_FILE.search(name):
        return "test"
    ext = os.path.splitext(name)[1].lower()
    if ext in DOC_EXT:
        return "docs"
    if ext in CONFIG_EXT or name in CONFIG_NAMES or name.startswith((".env", "Dockerfile")):
        return "config"
    return "code"


def area(path: str) -> str:
    segs = path.replace("\\", "/").split("/")[:-1]
    return "/".join(segs[:2]) if segs else "(root)"


def summarize_files(files: list[dict], spar_rel: str) -> dict:
    by = defaultdict(lambda: {"files": 0, "added": 0, "removed": 0})
    binary = 0
    for f in files:
        cat = category(f["path"], spar_rel)
        if f.get("added") is None:
            binary += 1
            continue
        b = by[cat]
        b["files"] += 1
        b["added"] += f["added"]
        b["removed"] += f["removed"] or 0
    delivered_added = sum(by[c]["added"] for c in DELIVERED if c in by)
    delivered_removed = sum(by[c]["removed"] for c in DELIVERED if c in by)
    return {"files": len(files), "binary_files": binary, "added": delivered_added, "removed": delivered_removed,
            "by_category": {k: dict(v) for k, v in sorted(by.items())}}


def snapshot_diff(spar_root: Path, root: Path, a: str, b: str) -> tuple[list[dict], dict]:
    env = _shadow(spar_root, root)
    out = _git(root, "diff", "-M", "--raw", "--numstat", "--no-abbrev", "-z", a, b, env=env)
    if out.returncode != 0:
        return [], {}
    raw, nums = _parse_z_entries(out.stdout.split("\0"))
    files = [{"path": p, "added": x, "removed": y, "blob": raw.get(p, "")} for p, x, y in nums]
    return files, raw


# --------------------------------------------------------------------------- #
# Transcripts and spend
# --------------------------------------------------------------------------- #


def claude_projects_dir() -> Path:
    pinned = os.environ.get("SPAR_CLAUDE_PROJECTS")
    if pinned:
        return Path(pinned).expanduser()
    base = os.environ.get("CLAUDE_CONFIG_DIR")
    return (Path(base).expanduser() if base else Path.home() / ".claude") / "projects"


def _escape(p: str) -> str:
    return re.sub(r"[^A-Za-z0-9]", "-", p)


def model_key(model: str) -> str:
    m = (model or "").strip().lower()
    m = re.sub(r"^(anthropic[./]|(us|eu|apac|global)\.anthropic\.)", "", m)
    m = re.sub(r"\[[^\]]*\]$", "", m)
    m = re.sub(r"(-v\d+(:\d+)?)$", "", m)
    m = re.sub(r"[-@]\d{8}$", "", m)
    return m


def prices(cfg: dict) -> dict:
    merged = dict(PRICES)
    for k, v in (cfg.get("prices") or {}).items():
        if isinstance(v, dict) and "input" in v and "output" in v:
            i = float(v["input"])
            merged[model_key(k)] = {
                "input": i, "output": float(v["output"]),
                "cache_read": float(v.get("cache_read", i * 0.1)),
                "cache_write_5m": float(v.get("cache_write_5m", i * 1.25)),
                "cache_write_1h": float(v.get("cache_write_1h", i * 2)),
            }
    return merged


def message_cost(m: dict, table: dict, cfg: dict) -> float | None:
    key = model_key(m["model"])
    p = table.get(key)
    if p is None:
        return None
    context = m["in"] + m["read"] + m["w5"] + m["w1h"]
    if context > 200_000 and key in LONG_CONTEXT and model_key(key) not in {model_key(k) for k in (cfg.get("prices") or {})}:
        p = LONG_CONTEXT[key]
    return (m["in"] * p["input"] + m["out"] * p["output"] + m["read"] * p["cache_read"]
            + m["w5"] * p["cache_write_5m"] + m["w1h"] * p["cache_write_1h"]) / 1_000_000


def _weight(m: dict) -> float:
    """The relative cost of a message: used only to split a measured total."""
    return m["in"] + 5 * m["out"] + 0.1 * m["read"] + 1.25 * m["w5"] + 2 * m["w1h"]


def _tokens(m: dict) -> int:
    return m["in"] + m["out"] + m["read"] + m["w5"] + m["w1h"]


def read_messages(spar_root: Path, root: Path) -> list[dict]:
    """Claude Code assistant messages whose working directory is inside *root*.

    Transcripts carry the same message on several lines while it streams; the
    key is (message id, request id), and the line with the final output count
    wins. A ledger in spar/cache keeps them after Claude Code prunes old
    transcripts (``cleanupPeriodDays``, 30 by default).
    """
    ledger_p = cache_dir(spar_root) / "messages.json"
    ledger: dict = _read_json(ledger_p, {})
    roots = {str(root), str(root.resolve())}
    base = claude_projects_dir()
    found: dict[str, dict] = {}
    if base.is_dir():
        prefixes = {_escape(r) for r in roots}
        for d in sorted(base.iterdir()):
            if not d.is_dir() or not any(d.name == p or d.name.startswith(p + "-") for p in prefixes):
                continue
            files = sorted(d.glob("*.jsonl")) + sorted(d.glob("*/subagents/*.jsonl"))
            for f in files:
                session = f.stem if f.parent == d else f.parent.parent.name
                entry = None
                rows: dict[str, dict] = {}
                try:
                    fh = f.open(encoding="utf-8", errors="replace")
                except OSError:
                    continue
                with fh:
                    for line in fh:
                        try:
                            rec = json.loads(line)
                        except json.JSONDecodeError:
                            continue
                        if not isinstance(rec, dict):
                            continue
                        if entry is None and rec.get("entrypoint"):
                            entry = rec["entrypoint"]
                        if rec.get("type") != "assistant":
                            continue
                        cwd = rec.get("cwd") or ""
                        if not any(cwd == r or cwd.startswith(r + "/") for r in roots):
                            continue
                        msg = rec.get("message") or {}
                        model = msg.get("model") or ""
                        if not model or model.startswith("<"):
                            continue
                        u = msg.get("usage") or {}
                        cc = u.get("cache_creation") or {}
                        w_total = int(u.get("cache_creation_input_tokens") or 0)
                        w1h = int(cc.get("ephemeral_1h_input_tokens") or 0)
                        w5 = int(cc.get("ephemeral_5m_input_tokens") or 0)
                        if w1h + w5 != w_total:
                            w5 = max(0, w_total - w1h)
                        at = _parse(rec.get("timestamp"))
                        if at is None:
                            continue
                        row = {"at": _iso(at), "model": model, "in": int(u.get("input_tokens") or 0),
                               "out": int(u.get("output_tokens") or 0),
                               "read": int(u.get("cache_read_input_tokens") or 0), "w5": w5, "w1h": w1h,
                               "session": session}
                        key = f"{msg.get('id')}|{rec.get('requestId')}"
                        prev = rows.get(key)
                        if prev is None:
                            rows[key] = row
                        elif row["out"] >= prev["out"]:
                            row["at"] = prev["at"]
                            rows[key] = row
                for k, row in rows.items():
                    row["entrypoint"] = entry or "unknown"
                    found[k] = row
    if found:
        changed = any(ledger.get(k) != v for k, v in found.items())
        if changed:
            ledger.update(found)
            _write_json(ledger_p, ledger)
    out = []
    for v in ledger.values():
        at = _parse(v.get("at"))
        if at is not None:
            out.append({**v, "at": at})
    out.sort(key=lambda m: m["at"])
    return out


def _app_windows(events: list[dict]) -> list[dict]:
    wins = []
    for e in events:
        if e.get("type") != "usage":
            continue
        start, end = _parse(e.get("start")), _parse(e.get("at"))
        if end is None:
            continue
        wins.append({"start": start or end, "end": end, "cost": float(e.get("cost_usd") or 0),
                     "agent": e.get("agent") or "", "model": e.get("model") or "", "family": e.get("family") or ""})
    return wins


def _covered(m: dict, wins: list[dict]) -> dict | None:
    if m.get("entrypoint") != "sdk-cli":
        return None
    for w in wins:
        if w["start"] - timedelta(seconds=5) <= m["at"] <= w["end"] + timedelta(seconds=60):
            return w
    return None


def spend_in(messages: list[dict], wins: list[dict], table: dict, cfg: dict,
             start: datetime | None, end: datetime | None) -> dict:
    """Tokens and cost of messages and app turns inside [start, end].

    App turns carry the engine's measured cost. Claude messages inside an app
    turn take their share of that cost (split by relative token cost) instead
    of a priced one, so nothing is counted twice.
    """
    def inside(t: datetime) -> bool:
        return (start is None or t >= start) and (end is None or t <= end)

    by_model: dict[str, dict] = {}
    priced = 0.0
    unpriced: dict[str, int] = defaultdict(int)
    covered_weight: dict[int, float] = defaultdict(float)
    covered_total: dict[int, float] = defaultdict(float)
    for m in messages:
        w = _covered(m, wins)
        if w is not None:
            covered_total[id(w)] += _weight(m)
        if not inside(m["at"]):
            continue
        b = by_model.setdefault(m["model"], {"messages": 0, "input": 0, "output": 0, "cache_read": 0,
                                             "cache_write": 0, "tokens": 0, "cost_usd": 0.0, "basis": set()})
        b["messages"] += 1
        b["input"] += m["in"]
        b["output"] += m["out"]
        b["cache_read"] += m["read"]
        b["cache_write"] += m["w5"] + m["w1h"]
        b["tokens"] += _tokens(m)
        if w is not None:
            covered_weight[id(w)] += _weight(m)
            b["basis"].add("reported")
            continue
        c = message_cost(m, table, cfg)
        if c is None:
            unpriced[m["model"]] += _tokens(m)
            b["basis"].add("unpriced")
        else:
            priced += c
            b["cost_usd"] += c
            b["basis"].add("priced")
    reported = 0.0
    for w in wins:
        if w["cost"] <= 0:
            continue
        total = covered_total.get(id(w), 0.0)
        if total > 0:
            share = covered_weight.get(id(w), 0.0) / total
        else:
            # A turn with no Claude transcript (Copilot, Codex …): share by time.
            lo = max(w["start"], start) if start else w["start"]
            hi = min(w["end"], end) if end else w["end"]
            span = (w["end"] - w["start"]).total_seconds()
            if span <= 0:
                share = 1.0 if inside(w["end"]) else 0.0
            else:
                share = max(0.0, (hi - lo).total_seconds()) / span
        if share > 0:
            reported += w["cost"] * share
            label = w["model"] or w["agent"] or "agent"
            b = by_model.setdefault(label, {"messages": 0, "input": 0, "output": 0, "cache_read": 0,
                                            "cache_write": 0, "tokens": 0, "cost_usd": 0.0, "basis": set()})
            b["cost_usd"] += w["cost"] * share
            b["basis"].add("reported")
    for b in by_model.values():
        b["basis"] = sorted(b["basis"])
        b["cost_usd"] = round(b["cost_usd"], 4)
    tokens = sum(b["tokens"] for b in by_model.values())
    return {
        "tokens": tokens,
        "cost_usd": round(priced + reported, 4),
        "priced_usd": round(priced, 4),
        "reported_usd": round(reported, 4),
        "unpriced_tokens": dict(sorted(unpriced.items())),
        "complete": not unpriced,
        "by_model": dict(sorted(by_model.items())),
    }


# --------------------------------------------------------------------------- #
# Sessions (begin / end)
# --------------------------------------------------------------------------- #


def sessions(events: list[dict]) -> list[dict]:
    ends = {e.get("id"): e for e in events if e.get("type") == "end"}
    out = []
    for b in events:
        if b.get("type") != "begin":
            continue
        e = ends.get(b.get("id"))
        start = _parse(b.get("at"))
        if start is None:
            continue
        finish = _parse(e.get("at")) if e else None
        out.append({
            "id": b.get("id"), "task": b.get("task"), "feature": b.get("feature"),
            "agent": b.get("agent"), "model": b.get("model"), "tool": b.get("tool"), "user": b.get("user"),
            "start": start, "end": finish, "status": (e or {}).get("status", "open"),
            "begin_snapshot": b.get("snapshot"), "end_snapshot": (e or {}).get("snapshot"),
            "changes": (e or {}).get("changes"), "commits": (e or {}).get("commits") or [],
            "blobs": (e or {}).get("blobs") or [], "tokens_at_end": (e or {}).get("tokens"),
        })
    out.sort(key=lambda s: s["start"])
    return out


def _open_for(events: list[dict], task: str, feature: str | None) -> dict | None:
    for s in reversed(sessions(events)):
        if s["end"] is None and s["task"] == task and (feature is None or s["feature"] == feature):
            return s
    return None


def _features(spar_root: Path) -> list[str]:
    d = spar_root / "specs"
    return sorted(p.name for p in d.iterdir() if p.is_dir()) if d.is_dir() else []


def _guess_feature(spar_root: Path, task: str) -> str | None:
    hits = []
    for f in _features(spar_root):
        t = spar_root / "specs" / f / "tasks.md"
        if t.is_file() and re.search(rf"\b{re.escape(task)}\b", t.read_text(encoding="utf-8", errors="replace")):
            hits.append(f)
    feats = _features(spar_root)
    if len(hits) == 1:
        return hits[0]
    if not hits and len(feats) == 1:
        return feats[0]
    return None


def _ensure_baseline(spar_root: Path, cfg: dict) -> dict:
    if not cfg.get("baseline"):
        cfg["baseline"] = {"mode": "from-now", "since": _iso(_now()), "recorded_at": _iso(_now()),
                           "by": _git_user(spar_root.parent) or os.environ.get("USER", ""),
                           "note": "started by the first `spar impact begin`"}
        _store_baseline(spar_root, cfg["baseline"])
    return cfg


def begin(spar_root: Path, task: str, feature: str | None = None, agent: str | None = None,
          model: str | None = None, tool: str | None = None) -> tuple[dict, bool]:
    """Open a session for *task*. Returns (session event, created)."""
    task = task.strip()
    if not task:
        raise ImpactError("a task id is required, e.g. T005")
    root = spar_root.parent
    feature = feature or _guess_feature(spar_root, task)
    _ensure_baseline(spar_root, read_config(spar_root))
    events = read_events(spar_root)
    existing = _open_for(events, task, feature)
    if existing:
        return {"id": existing["id"], "task": task, "feature": existing["feature"], "at": _iso(existing["start"])}, False
    top = git_top(root)
    head = None
    if top and _has_commits(top):
        head = _git(top, "rev-parse", "HEAD").stdout.strip() or None
    ev = {"type": "begin", "id": uuid.uuid4().hex[:12], "at": _iso(_now()), "task": task, "feature": feature,
          "agent": agent, "model": model, "tool": tool or "spar", "user": _git_user(root),
          "snapshot": snapshot(spar_root, root, f"begin {feature or ''} {task}"), "head": head}
    return _append(spar_root, ev), True


def _tick(spar_root: Path, feature: str | None, task: str) -> bool:
    """Ticks `- [ ] T###` in the feature's tasks.md. Only the checkbox changes, so an
    approved plan stays approved. Returns whether a box was ticked."""
    if not feature:
        return False
    p = spar_root / "specs" / feature / "tasks.md"
    if not p.is_file():
        return False
    text = p.read_text(encoding="utf-8")
    pat = re.compile(rf"^(\s*[-*]\s*)\[ \](\s*\**{re.escape(task)}\b)", re.M)
    new, n = pat.subn(r"\1[x]\2", text, count=1)
    if n:
        p.write_text(new, encoding="utf-8")
    return bool(n)


def end(spar_root: Path, task: str, feature: str | None = None, status: str = "done") -> dict:
    task = task.strip()
    root = spar_root.parent
    events = read_events(spar_root)
    s = _open_for(events, task, feature)
    if s is None and feature is None:
        s = _open_for(events, task, _guess_feature(spar_root, task))
    if s is None:
        raise ImpactError(f"no open session for {task}; run `spar impact begin {task}` when the task starts")
    at = _now()
    snap = snapshot(spar_root, root, f"end {s['feature'] or ''} {task}")
    try:
        spar_rel = spar_root.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        spar_rel = "spar"
    changes, blobs = None, []
    if s["begin_snapshot"] and snap:
        files, raw = snapshot_diff(spar_root, root, s["begin_snapshot"], snap)
        changes = summarize_files(files, spar_rel)
        blobs = sorted([p, b] for p, b in raw.items() if b and set(b) != {"0"})[:2000]
    commits = []
    b_ev = next((e for e in events if e.get("type") == "begin" and e.get("id") == s["id"]), {})
    top = git_top(root)
    if top and _has_commits(top):
        rng = f"{b_ev['head']}..HEAD" if b_ev.get("head") else "HEAD"
        out = _git(top, "log", "--format=%H", rng) if b_ev.get("head") else \
            _git(top, "log", "--format=%H", f"--since={_iso(s['start'])}")
        commits = [x for x in out.stdout.split() if x]
    cfg = read_config(spar_root)
    msgs = read_messages(spar_root, root)
    sp = spend_in(msgs, _app_windows(events), prices(cfg), cfg, s["start"], at)
    ev = {"type": "end", "id": s["id"], "at": _iso(at), "task": task, "feature": s["feature"], "status": status,
          "duration_s": int((at - s["start"]).total_seconds()), "snapshot": snap, "changes": changes,
          "blobs": blobs, "commits": commits,
          "tokens": {"total": sp["tokens"], "priced_usd": sp["priced_usd"], "unpriced": sp["unpriced_tokens"]}}
    # A task that ended done is ticked even when the agent forgot to, so the app's
    # build progress follows the work (after the snapshot: the tick is bookkeeping).
    ev["ticked"] = status == "done" and _tick(spar_root, s["feature"], task)
    return _append(spar_root, ev)


def record_usage(spar_root: Path, cost_usd: float, agent: str = "", model: str = "", family: str = "",
                 session: str = "", start: str | None = None) -> dict:
    """One agent turn's cost as the SPAR app's engine measured it."""
    if cost_usd < 0:
        raise ImpactError("cost must not be negative")
    ev = {"type": "usage", "source": "spar-app", "at": _iso(_now()), "start": start, "cost_usd": round(cost_usd, 6),
          "agent": agent, "model": model, "family": family, "session": session}
    return _append(spar_root, ev)


def backfill(spar_root: Path, fully: bool = False, since: str | None = None, note: str = "") -> dict:
    root = spar_root.parent
    top = git_top(root)
    first = None
    if top and _has_commits(top):
        out = _git(top, "log", "--reverse", "--format=%aI", "--max-parents=0")
        first = _parse(out.stdout.split()[0]) if out.stdout.split() else None
    if fully:
        if first is None:
            raise ImpactError("--ai-assisted-fully reads the git history, and this project has no commits")
        baseline = {"mode": "ai-assisted-fully", "since": _iso(first)}
    elif since:
        dt = _parse(since)
        if dt is None:
            raise ImpactError(f"cannot read the date {since!r}; use YYYY-MM-DD")
        baseline = {"mode": "since", "since": _iso(dt)}
    else:
        baseline = {"mode": "from-now", "since": _iso(_now())}
    baseline.update({"recorded_at": _iso(_now()), "by": _git_user(root) or os.environ.get("USER", ""), "note": note})
    _store_baseline(spar_root, baseline)
    _append(spar_root, {"type": "baseline", "at": baseline["recorded_at"], **{k: v for k, v in baseline.items() if k != "recorded_at"}})
    read_messages(spar_root, root)  # capture transcripts into the ledger before Claude Code prunes them
    return baseline


# --------------------------------------------------------------------------- #
# Pull requests (GitHub, through gh)
# --------------------------------------------------------------------------- #


def fetch_prs(spar_root: Path, limit: int = 300) -> dict:
    top = git_top(spar_root.parent) or spar_root.parent
    if not shutil.which("gh"):
        return {"available": False, "reason": "the GitHub CLI (gh) is not installed"}
    fields = "number,title,author,createdAt,mergedAt,additions,deletions,commits,reviews,url"
    try:
        out = subprocess.run(["gh", "pr", "list", "--state", "merged", "--limit", str(limit), "--json", fields],
                             cwd=str(top), capture_output=True, text=True, timeout=180)
    except (OSError, subprocess.SubprocessError) as exc:
        return {"available": False, "reason": str(exc)}
    if out.returncode != 0:
        return {"available": False, "reason": (out.stderr.strip().splitlines() or ["gh failed"])[0]}
    try:
        prs = json.loads(out.stdout)
    except json.JSONDecodeError:
        return {"available": False, "reason": "gh returned something other than JSON"}
    data = {"available": True, "fetched_at": _iso(_now()), "prs": prs}
    _write_json(cache_dir(spar_root) / "prs.json", data)
    return data


# --------------------------------------------------------------------------- #
# Rework
# --------------------------------------------------------------------------- #


def _deleted_ranges(top: Path, sha: str) -> dict[str, list[tuple[int, int]]]:
    out = _git(top, "show", "-U0", "-M", "--no-color", "--format=", sha)
    ranges: dict[str, list[tuple[int, int]]] = defaultdict(list)
    old = None
    for line in out.stdout.splitlines():
        if line.startswith("--- "):
            p = line[4:].strip()
            if p.startswith('"') and p.endswith('"'):
                p = p[1:-1]
            old = p[2:] if p.startswith("a/") else None
        elif line.startswith("@@") and old:
            m = _HUNK.match(line)
            if m:
                start = int(m.group(1))
                count = int(m.group(2)) if m.group(2) is not None else 1
                if count > 0:
                    ranges[old].append((start, count))
    return ranges


def _blame(top: Path, parent: str, path: str, ranges: list[tuple[int, int]]) -> dict[str, list]:
    args = ["blame", "--porcelain"]
    for s, n in ranges:
        args += ["-L", f"{s},+{n}"]
    out = _git(top, *args, parent, "--", path)
    origins: dict[str, list] = {}
    cur = None
    for line in out.stdout.splitlines():
        if line.startswith("\t"):
            if cur:
                origins.setdefault(cur, [0, None])[0] += 1
            continue
        m = re.match(r"^([0-9a-f]{40}) \d+ \d+", line)
        if m:
            cur = m.group(1)
            origins.setdefault(cur, [0, None])
        elif line.startswith("author-time ") and cur:
            origins[cur][1] = int(line.split()[1])
    return {k: v for k, v in origins.items() if v[0] > 0}


def rework_origins(spar_root: Path, top: Path, commits: list[dict], spar_rel: str, limit: int = 3000) -> tuple[dict, int]:
    """For each commit: {path: {origin sha: [lines, epoch]}} for the lines it deleted or changed."""
    cache_p = cache_dir(spar_root) / "rework.json"
    cache: dict = _read_json(cache_p, {})
    done, skipped, dirty = {}, 0, False
    todo = [c for c in commits if c["parents"]]
    if len(todo) > limit:
        skipped = len(todo) - limit
        todo = todo[-limit:]
    for c in todo:
        if c["sha"] in cache:
            done[c["sha"]] = cache[c["sha"]]
            continue
        delivered = {f["path"] for f in c["files"] if category(f["path"], spar_rel) in DELIVERED and (f["removed"] or 0) > 0}
        result = {}
        if delivered:
            for old, ranges in _deleted_ranges(top, c["sha"]).items():
                if category(old, spar_rel) not in DELIVERED:
                    continue
                origins = _blame(top, c["parents"][0], old, ranges)
                if origins:
                    result[old] = origins
        cache[c["sha"]] = done[c["sha"]] = result
        dirty = True
    if dirty:
        _write_json(cache_p, cache)
    return done, skipped


# --------------------------------------------------------------------------- #
# Report
# --------------------------------------------------------------------------- #


def _estimate_hours(times: list[datetime], gap_min: float, lead_min: float) -> float:
    """Commit-timing estimate: commits closer than the gap are one sitting."""
    if not times:
        return 0.0
    ts = sorted(times)
    total = lead_min * 60
    for a, b in zip(ts, ts[1:]):
        d = (b - a).total_seconds()
        total += d if d <= gap_min * 60 else lead_min * 60
    return total / 3600.0


def _union(intervals: list[tuple[datetime, datetime]]) -> list[tuple[datetime, datetime]]:
    out: list[list[datetime]] = []
    for a, b in sorted(intervals):
        if out and a <= out[-1][1]:
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    return [(a, b) for a, b in out]


def _tracker_keys(spar_root: Path) -> dict[tuple[str, str], str]:
    keys = {}
    for f in _features(spar_root):
        p = spar_root / "specs" / f / "issues.md"
        if not p.is_file():
            continue
        for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if len(cells) >= 3 and re.match(r"^[A-Z][A-Z0-9]+-\d+$", re.sub(r"^\[([^\]]+)\].*$", r"\1", cells[2])):
                keys[(f, cells[0])] = re.sub(r"^\[([^\]]+)\].*$", r"\1", cells[2])
    return keys


def _ticked(spar_root: Path) -> dict[str, dict[str, bool]]:
    out = {}
    for f in _features(spar_root):
        p = spar_root / "specs" / f / "tasks.md"
        if p.is_file():
            ticks = {}
            for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
                m = _TASK_LINE.match(line)
                if m:
                    ticks[m.group(2)] = m.group(1).lower() == "x"
            out[f] = ticks
    return out


def _p(xs: list, q: float):
    """The q-quantile (nearest rank) of *xs*, or None."""
    xs = sorted(x for x in xs if x is not None)
    if not xs:
        return None
    return xs[min(len(xs) - 1, max(0, int(round(q * (len(xs) - 1)))))]


def _pr_trends(rows: list[dict]) -> dict:
    """Weekly merged PRs and P50 cycle time, AI vs human, and the median time in each
    stage of a PR's life (first commit → opened → first review → merged)."""
    weeks: dict[str, dict] = {}
    for r in rows:
        m = _parse(r.get("merged_at"))
        if m is None:
            continue
        y, w, _ = m.isocalendar()
        k = f"{y}-W{w:02d}"
        e = weeks.setdefault(k, {"week": k, "start": date.fromisocalendar(y, w, 1).isoformat(),
                                 "merged_ai": 0, "merged_human": 0, "_ai": [], "_human": []})
        side = "ai" if r["ai"] else "human"
        e[f"merged_{side}"] += 1
        e[f"_{side}"].append(r.get("cycle_hours"))
    weekly = []
    for k in sorted(weeks):
        e = weeks[k]
        weekly.append({"week": e["week"], "start": e["start"], "merged_ai": e["merged_ai"], "merged_human": e["merged_human"],
                       "p50_cycle_hours_ai": _median(e["_ai"]), "p50_cycle_hours_human": _median(e["_human"])})

    def stages(rs: list[dict]) -> dict:
        pickup = [r["first_review_hours"] for r in rs]
        return {"prs": len(rs), "coding_hours": _median([r.get("coding_hours") for r in rs]),
                "pickup_hours": _median(pickup), "review_hours": _median([r.get("review_to_merge_hours") for r in rs]),
                "cycle_hours": _median([r["cycle_hours"] for r in rs])}

    return {"weekly": weekly,
            "lifecycle": {"ai": stages([r for r in rows if r["ai"]]), "human": stages([r for r in rows if not r["ai"]]),
                          "stages": ["first commit → PR opened", "opened → first review", "first review → merged"]}}


def _insights(period: list[dict], contributors: list[dict], weekly: list[dict], msgs: list[dict], wins: list[dict],
              table: dict, cfg: dict, sess: list[dict], tasks: list[dict], pr_rows: list[dict], rework: dict,
              added: Counter, loc_per_hour: float, hourly: float, period_start, now: datetime) -> dict:
    """The figures behind the AI Insights, ROI, Agentic and Capacity views.

    All of it comes from the same commits, transcripts and sessions as the rest of
    the report; nothing here is assumed beyond the rate and lines an hour the ROI
    already uses (and says so).
    """
    tracked = [c for c in period if c["class"] in ("ai", "human")]

    # ---- lift: output on developer-days with AI work vs days without ----------
    days: dict[tuple, dict] = {}
    for c in tracked:
        d = days.setdefault((c["email"], c["at"].date()), {"ai": False, "lines": 0, "commits": 0, "ai_commits": 0})
        d["lines"] += c["stats"]["added"]
        d["commits"] += 1
        if c["class"] == "ai":
            d["ai"] = True
            d["ai_commits"] += 1
    ai_days = [d for d in days.values() if d["ai"]]
    hu_days = [d for d in days.values() if not d["ai"]]

    def ratio(a, b):
        return round(a / b, 2) if a is not None and b else None

    lpd_ai, lpd_hu = _median([d["lines"] for d in ai_days]), _median([d["lines"] for d in hu_days])
    cpd_ai, cpd_hu = _median([d["commits"] for d in ai_days]), _median([d["commits"] for d in hu_days])
    by_person: dict[str, dict] = defaultdict(lambda: {"ai": [], "human": []})
    for (email, _), d in days.items():
        by_person[email]["ai" if d["ai"] else "human"].append(d["lines"])
    lift_by = {}
    for email, v in by_person.items():
        if len(v["ai"]) >= 3 and len(v["human"]) >= 3:
            lift_by[email] = ratio(_median(v["ai"]), _median(v["human"]))
    lift = {
        "lines_per_dev_day_ai": lpd_ai, "lines_per_dev_day_human": lpd_hu, "multiple": ratio(lpd_ai, lpd_hu),
        "commits_per_dev_day_ai": cpd_ai, "commits_per_dev_day_human": cpd_hu,
        "ai_dev_days": len(ai_days), "human_dev_days": len(hu_days),
        "ai_commits_per_dev_day": round(sum(d["ai_commits"] for d in ai_days) / len(ai_days), 2) if ai_days else None,
        "by_contributor": lift_by,
        "basis": "median delivered lines per person per day, days with an AI commit vs days without",
    }
    week_days: dict[str, dict] = defaultdict(lambda: {"ai": [], "human": [], "ai_n": 0, "human_n": 0})
    for (email, dd), d in days.items():
        wd = week_days[_week(datetime.combine(dd, datetime.min.time(), timezone.utc))]
        wd["ai" if d["ai"] else "human"].append(d["lines"])
    for w in weekly:
        wd = week_days.get(w["week"])
        w["ai_dev_days"] = len(wd["ai"]) if wd else 0
        w["human_dev_days"] = len(wd["human"]) if wd else 0
        w["lift"] = ratio(_median(wd["ai"]), _median(wd["human"])) if wd else None

    # ---- commit sizes ----------------------------------------------------------
    def size_of(cls: str) -> dict:
        xs = [c["stats"]["added"] for c in tracked if c["class"] == cls]
        return {"commits": len(xs), "median": _median(xs), "p90": _p(xs, 0.9),
                "mean": round(sum(xs) / len(xs), 1) if xs else None,
                "large_share": round(sum(1 for x in xs if x > 400) / len(xs), 4) if xs else None}
    week_sizes: dict[str, dict] = defaultdict(lambda: {"ai": [], "human": []})
    for c in tracked:
        week_sizes[_week(c["at"])][c["class"]].append(c["stats"]["added"])
    for w in weekly:
        ws = week_sizes.get(w["week"], {"ai": [], "human": []})
        w["median_commit_lines_ai"] = _median(ws["ai"])
        w["median_commit_lines_human"] = _median(ws["human"])
    pr_ai = [r["additions"] for r in pr_rows if r["ai"] and r.get("additions") is not None]
    pr_hu = [r["additions"] for r in pr_rows if not r["ai"] and r.get("additions") is not None]
    sizes = {"ai": size_of("ai"), "human": size_of("human"), "large_lines": 400,
             "pr_ai_median": _median(pr_ai), "pr_human_median": _median(pr_hu),
             "basis": "delivered lines (code and tests) added per commit"}

    # ---- daily, last 90 days ---------------------------------------------------
    # The 90 days up to the latest activity, so a project that paused still shows its last stretch.
    last_seen = [c["at"] for c in tracked] + [m["at"] for m in msgs] + [s["start"] for s in sess]
    today = min(now.date(), max(last_seen).date()) if last_seen else now.date()
    first_day = today - timedelta(days=89)
    if period_start and period_start.date() > first_day:
        first_day = period_start.date()
    daily_map: dict[date, dict] = {}
    d0 = first_day
    while d0 <= today:
        daily_map[d0] = {"date": d0.isoformat(), "commits_ai": 0, "commits_human": 0, "lines_ai": 0, "lines_human": 0,
                         "lines_removed": 0, "files": 0, "contributors": set(), "ai_contributors": set(),
                         "messages": 0, "sessions": set(), "tokens_in": 0, "tokens_out": 0,
                         "session_hours": 0.0, "cost_usd": 0.0}
        d0 += timedelta(days=1)
    for c in tracked:
        e = daily_map.get(c["at"].date())
        if e is None:
            continue
        e[f"commits_{c['class']}"] += 1
        e[f"lines_{c['class']}"] += c["stats"]["added"]
        e["lines_removed"] += c["stats"]["removed"]
        e["files"] += len(c["files"])
        e["contributors"].add(c["email"])
        if c["class"] == "ai":
            e["ai_contributors"].add(c["email"])
    for m in msgs:
        e = daily_map.get(m["at"].date())
        if e is None:
            continue
        e["messages"] += 1
        e["sessions"].add(m.get("session") or "")
        e["tokens_in"] += m["in"] + m["read"] + m["w5"] + m["w1h"]
        e["tokens_out"] += m["out"]
    for s in sess:
        if s["end"] and s["start"].date() in daily_map:
            daily_map[s["start"].date()]["session_hours"] += (s["end"] - s["start"]).total_seconds() / 3600.0
    per_line = hourly / loc_per_hour if loc_per_hour > 0 else 0.0
    daily = []
    for dd in sorted(daily_map):
        e = daily_map[dd]
        lo = datetime.combine(dd, datetime.min.time(), timezone.utc)
        cost = spend_in(msgs, wins, table, cfg, lo, lo + timedelta(days=1) - timedelta(microseconds=1))["cost_usd"] \
            if (e["messages"] or wins) else 0.0
        value = e["lines_ai"] * per_line - e["session_hours"] * hourly
        daily.append({**e, "contributors": len(e["contributors"]), "ai_contributors": len(e["ai_contributors"]),
                      "sessions": len(e["sessions"]), "session_hours": round(e["session_hours"], 2),
                      "cost_usd": round(cost, 4), "value_usd": round(value, 2),
                      "roi": round(value / cost, 2) if cost > 0 else None})

    # ---- agent activity (transcripts) -------------------------------------------
    in_period = [m for m in msgs if period_start is None or m["at"] >= period_start]
    entry = Counter(m.get("entrypoint") or "unknown" for m in in_period)
    active = {m["at"].date() for m in in_period}
    agent = {
        "messages": len(in_period), "sessions": len({m.get("session") for m in in_period}),
        "active_days": len(active),
        "tokens_in": sum(m["in"] + m["read"] + m["w5"] + m["w1h"] for m in in_period),
        "tokens_out": sum(m["out"] for m in in_period),
        "by_entrypoint": dict(entry.most_common()),
        "models": dict(Counter(m["model"] for m in in_period).most_common()),
        "messages_per_active_day": round(len(in_period) / len(active), 1) if active else None,
        "basis": "Claude Code transcripts for this folder (assistant messages)",
    }

    # ---- funnel ----------------------------------------------------------------
    ai_shas = {c["sha"]: c for c in tracked if c["class"] == "ai"}
    merged_oids = {o for r in pr_rows for o in r.get("oids") or []}
    finished = [t for t in tasks if t["status"] == "done"]
    funnel = {
        "ai_lines": added["ai"], "ai_lines_standing": max(0, added["ai"] - rework.get("ai", 0)),
        "ai_lines_in_merged_prs": sum(c["stats"]["added"] for s, c in ai_shas.items() if s in merged_oids) if pr_rows else None,
        "tasks_begun": len(tasks), "tasks_done": len(finished),
        "tasks_first_pass": sum(1 for t in finished if t["attempts"] == 1),
        "session_lines": sum(t["lines_added"] for t in tasks),
        "basis": "AI lines committed → not rewritten within the rework window → in a merged pull request",
    }

    # ---- contributor trend (last 28 days vs the 28 before) ----------------------
    recent: Counter = Counter()
    prior: Counter = Counter()
    for c in tracked:
        age = (now - c["at"]).days
        if age < 28:
            recent[c["email"]] += 1
        elif age < 56:
            prior[c["email"]] += 1
    for p in contributors:
        r, q = recent[p["email"]], prior[p["email"]]
        p["recent_commits"], p["prior_commits"] = r, q
        p["trend"] = "up" if r > q * 1.2 and r - q >= 2 else "down" if r < q * 0.8 and q - r >= 2 else "flat"
        p["lift"] = lift_by.get(p["email"])

    # ---- cohort durability --------------------------------------------------------
    person_weeks: dict[str, Counter] = defaultdict(Counter)
    first_ai: dict[str, datetime] = {}
    first_any: dict[str, datetime] = {}
    for c in tracked:
        wk0 = datetime.combine(date.fromisocalendar(*c["at"].isocalendar()[:2], 1), datetime.min.time(), timezone.utc)
        person_weeks[c["email"]][wk0] += 1
        first_any.setdefault(c["email"], wk0)
        if c["class"] == "ai":
            first_ai.setdefault(c["email"], wk0)
    horizon = min(now, max(c["at"] for c in tracked)) if tracked else now
    this_week = datetime.combine(date.fromisocalendar(*horizon.isocalendar()[:2], 1), datetime.min.time(), timezone.utc)
    per_offset: dict[int, list] = defaultdict(list)
    cohort_n = 0
    for email, t0 in first_ai.items():
        pre = [t0 - timedelta(weeks=k) for k in range(1, 9) if t0 - timedelta(weeks=k) >= first_any[email]]
        if len(pre) < 2:
            continue
        base = sum(person_weeks[email][w] for w in pre) / len(pre)
        if base <= 0:
            continue
        cohort_n += 1
        for o in range(-4, 13):
            wk = t0 + timedelta(weeks=o)
            if wk > this_week or wk < first_any[email]:
                continue
            per_offset[o].append(person_weeks[email][wk] / base)
    cohort = {"engineers": cohort_n, "offsets": [
        {"week": o, "index": round(statistics.median(per_offset[o]), 3), "n": len(per_offset[o])}
        for o in sorted(per_offset) if per_offset[o]],
        "basis": "commits per week, each person indexed to their own weekly mean in the (up to) 8 weeks before their first AI commit; median across people"}

    return {"lift": lift, "sizes": sizes, "daily": daily, "agent": agent, "funnel": funnel, "cohort": cohort}


def build_report(spar_root: Path, refresh_prs: bool = False) -> dict:
    root = spar_root.parent
    cfg = read_config(spar_root)
    events = read_events(spar_root)
    table = prices(cfg)
    now = _now()
    try:
        spar_rel = spar_root.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        spar_rel = "spar"
    baseline = cfg.get("baseline")
    mode = (baseline or {}).get("mode", "none")
    period_start = _parse((baseline or {}).get("since"))
    recorded_at = _parse((baseline or {}).get("recorded_at"))
    gap, lead = float(cfg["session_gap_minutes"]), float(cfg["session_lead_minutes"])
    window = timedelta(days=float(cfg["rework_window_days"]))

    # ---- sessions -----------------------------------------------------------
    sess = sessions(events)
    windows = [(s["start"], s["end"] or now, s) for s in sess]
    session_blobs = {(p, b): s for s in sess for p, b in s["blobs"]}
    session_commits = {c: s for s in sess for c in s["commits"]}

    # ---- git ----------------------------------------------------------------
    top = git_top(root)
    git_ok = bool(top and _has_commits(top))
    commits: list[dict] = []
    merges: list[dict] = []
    rel_prefix = ""
    if git_ok:
        rel = os.path.relpath(root.resolve(), top.resolve())
        pathspec = [] if rel == "." else [rel]
        rel_prefix = "" if rel == "." else rel.replace(os.sep, "/") + "/"
        commits = read_commits(top, pathspec)
        merges = read_merges(top, pathspec)
        if rel_prefix:
            for c in commits:
                for f in c["files"]:
                    if f["path"].startswith(rel_prefix):
                        f["path"] = f["path"][len(rel_prefix):]
    if period_start is None and commits:
        period_start = commits[0]["at"]

    for c in commits:
        text = c["message"] + f"\nauthor: {c['author']} <{c['email']}>"
        tool = next((name for name, rx in AI_SIGNS if rx.search(text)), None)
        spar_task = SPAR_TRAILER.search(c["message"])
        in_session = session_commits.get(c["sha"]) or next(
            (s for a, b, s in windows if a <= c["at"] <= b), None)
        blob_session = next((session_blobs[(f["path"], f["blob"])] for f in c["files"]
                             if f.get("blob") and (f["path"], f["blob"]) in session_blobs), None)
        is_bot = "[bot]" in c["author"].lower() or "[bot]@" in c["email"]
        c["task"] = None
        if period_start and c["at"] < period_start:
            cls, basis = "untracked", "before the measurement period"
        elif is_bot and not tool:
            cls, basis = "bot", "bot author"
        elif tool:
            cls, basis = "ai", "commit trailer"
        elif spar_task:
            cls, basis, tool = "ai", "SPAR-Task trailer", "SPAR"
            c["task"] = spar_task.group(2)
        elif in_session:
            cls, basis, tool = "ai", "made during a SPAR session", "SPAR"
            c["task"] = in_session["task"]
        elif blob_session:
            cls, basis, tool = "ai", "content matches a SPAR session", "SPAR"
            c["task"] = blob_session["task"]
        elif mode == "ai-assisted-fully" and recorded_at and c["at"] <= recorded_at:
            cls, basis, tool = "ai", "declared: project built with AI (backfill --ai-assisted-fully)", None
        else:
            cls, basis = "human", "no AI evidence"
        s_for = in_session or blob_session
        if s_for and cls == "ai":
            c["task"] = c["task"] or s_for["task"]
        if cls == "ai" and tool == "SPAR" and s_for and s_for.get("agent"):
            tool = f"SPAR · {s_for['agent']}"
        c["class"], c["basis"], c["tool"] = cls, basis, tool
        c["stats"] = summarize_files(c["files"], spar_rel)
        c["in_session"] = bool(in_session)

    period = [c for c in commits if c["class"] != "untracked"]
    by_sha = {c["sha"]: c for c in commits}

    # ---- rework -------------------------------------------------------------
    rework = {"ai": 0, "human": 0, "bot": 0, "untracked": 0}
    rework_author: Counter = Counter()
    rework_area: Counter = Counter()
    rework_week: dict[str, Counter] = defaultdict(Counter)
    skipped = 0
    if git_ok and period:
        origins, skipped = rework_origins(spar_root, top, period, spar_rel)
        for c in period:
            for path, orig in origins.get(c["sha"], {}).items():
                p = path[len(rel_prefix):] if rel_prefix and path.startswith(rel_prefix) else path
                for o_sha, (n, epoch) in orig.items():
                    if o_sha == c["sha"] or epoch is None:
                        continue
                    age = c["at"] - datetime.fromtimestamp(epoch, timezone.utc)
                    if age < timedelta(0) or age > window:
                        continue
                    oc = by_sha.get(o_sha)
                    ocls = oc["class"] if oc else "untracked"
                    rework[ocls] = rework.get(ocls, 0) + n
                    if oc and ocls != "untracked":
                        rework_author[oc["email"]] += n
                    rework_area[area(p)] += n
                    rework_week[_week(c["at"])][ocls] += n

    # ---- lines and adoption ---------------------------------------------------
    added = Counter()
    removed = Counter()
    count = Counter()
    by_cat: dict[str, Counter] = defaultdict(Counter)
    for c in period:
        count[c["class"]] += 1
        added[c["class"]] += c["stats"]["added"]
        removed[c["class"]] += c["stats"]["removed"]
        for cat, v in c["stats"]["by_category"].items():
            by_cat[cat][c["class"]] += v["added"]
    tracked = count["ai"] + count["human"]

    def rate(cls: str):
        return round(rework[cls] / added[cls], 4) if added[cls] else None

    # ---- tools --------------------------------------------------------------
    tools = Counter(c["tool"] for c in period if c["class"] == "ai" and c["tool"])
    declared_commits = sum(1 for c in period if c["class"] == "ai" and not c["tool"])

    # ---- contributors ---------------------------------------------------------
    people: dict[str, dict] = {}
    for c in period:
        if c["class"] == "bot":
            continue
        p = people.setdefault(c["email"], {"name": c["author"], "email": c["email"], "commits": 0, "ai_commits": 0,
                                           "added": 0, "ai_added": 0, "test_added": 0, "code_added": 0,
                                           "areas": set(), "days": set(), "tools": Counter(),
                                           "first": c["at"], "last": c["at"], "times": [], "ai_times": []})
        p["commits"] += 1
        p["added"] += c["stats"]["added"]
        p["test_added"] += c["stats"]["by_category"].get("test", {}).get("added", 0)
        p["code_added"] += c["stats"]["by_category"].get("code", {}).get("added", 0)
        p["days"].add(c["at"].date().isoformat())
        p["last"] = max(p["last"], c["at"])
        p["first"] = min(p["first"], c["at"])
        p["times"].append(c["at"])
        for f in c["files"]:
            if category(f["path"], spar_rel) in DELIVERED:
                p["areas"].add(area(f["path"]))
        if c["class"] == "ai":
            p["ai_commits"] += 1
            p["ai_added"] += c["stats"]["added"]
            if c["tool"]:
                p["tools"][c["tool"]] += 1
            p["ai_times"].append(c["at"])
    team_rework = (sum(rework_author.values()) / sum(p["added"] for p in people.values())) \
        if people and sum(p["added"] for p in people.values()) else None
    contributors = []
    for p in people.values():
        rr = round(rework_author[p["email"]] / p["added"], 4) if p["added"] else None
        share = round(p["ai_commits"] / p["commits"], 4) if p["commits"] else 0.0
        strengths, growth = [], []
        if share >= 0.5:
            strengths.append(f"AI on {round(share * 100)}% of commits")
        elif p["commits"] >= 5 and share == 0:
            growth.append(f"No AI evidence in {p['commits']} commits")
        if rr is not None and team_rework and p["added"] >= 200:
            if rr <= team_rework * 0.75:
                strengths.append(f"Low rework: {round(rr * 100, 1)}% vs team {round(team_rework * 100, 1)}%")
            elif rr >= team_rework * 1.5:
                growth.append(f"High rework: {round(rr * 100, 1)}% vs team {round(team_rework * 100, 1)}%")
        delivered = p["code_added"] + p["test_added"]
        if delivered >= 200:
            ts = p["test_added"] / delivered
            if ts >= 0.25:
                strengths.append(f"Tests are {round(ts * 100)}% of the lines they add")
            elif ts < 0.05:
                growth.append(f"Tests are {round(ts * 100, 1)}% of the lines they add")
        if len(p["areas"]) >= 3:
            strengths.append(f"Works across {len(p['areas'])} areas")
        contributors.append({
            "name": p["name"], "email": p["email"], "commits": p["commits"], "ai_commits": p["ai_commits"],
            "ai_share": share, "lines_added": p["added"], "ai_lines_added": p["ai_added"],
            "test_lines_added": p["test_added"], "rework_lines": rework_author[p["email"]], "rework_rate": rr,
            "active_days": len(p["days"]), "areas": sorted(p["areas"]), "tools": dict(p["tools"]),
            "first": _iso(p["first"]), "last": _iso(p["last"]),
            "estimated_hours": round(_estimate_hours(p["times"], gap, lead), 2),
            "strengths": strengths, "growth": growth,
        })
    contributors.sort(key=lambda x: (-x["commits"], x["email"]))

    # ---- hotspots -------------------------------------------------------------
    area_added: Counter = Counter()
    area_ai: Counter = Counter()
    area_commits: Counter = Counter()
    for c in period:
        seen = set()
        for f in c["files"]:
            if category(f["path"], spar_rel) not in DELIVERED or f["added"] is None:
                continue
            a = area(f["path"])
            area_added[a] += f["added"]
            if c["class"] == "ai":
                area_ai[a] += f["added"]
            seen.add(a)
        for a in seen:
            area_commits[a] += 1
    hotspots = []
    for a in set(area_added) | set(rework_area):
        hotspots.append({"area": a, "lines_added": area_added[a], "ai_share": round(area_ai[a] / area_added[a], 4) if area_added[a] else None,
                         "commits": area_commits[a], "rework_lines": rework_area[a],
                         "rework_rate": round(rework_area[a] / area_added[a], 4) if area_added[a] else None})
    hotspots.sort(key=lambda h: (-h["rework_lines"], -h["lines_added"], h["area"]))

    # ---- spend ----------------------------------------------------------------
    msgs = read_messages(spar_root, root)
    wins = _app_windows(events)
    spend = spend_in(msgs, wins, table, cfg, period_start, None)
    first_msg = msgs[0]["at"] if msgs else None

    # ---- tasks ----------------------------------------------------------------
    keys = _tracker_keys(spar_root)
    ticked = _ticked(spar_root)
    task_rows: dict[tuple, dict] = {}
    for s in sess:
        k = (s["feature"], s["task"])
        t = task_rows.setdefault(k, {"feature": s["feature"], "task": s["task"], "attempts": 0, "seconds": 0,
                                     "status": "open", "first_start": s["start"], "last_end": None,
                                     "lines_added": 0, "lines_removed": 0, "commits": 0, "tokens": 0,
                                     "cost_usd": 0.0, "cost_complete": True, "agents": set(),
                                     "issue": keys.get((s["feature"], s["task"]))})
        t["attempts"] += 1
        t["status"] = s["status"]
        if s["agent"]:
            t["agents"].add(s["agent"])
        if s["end"]:
            t["seconds"] += (s["end"] - s["start"]).total_seconds()
            t["last_end"] = s["end"]
            ch = s["changes"] or {}
            t["lines_added"] += ch.get("added", 0)
            t["lines_removed"] += ch.get("removed", 0)
            t["commits"] += len(s["commits"])
            sp = spend_in(msgs, wins, table, cfg, s["start"], s["end"])
            if sp["tokens"] == 0 and s["tokens_at_end"]:
                t["tokens"] += int(s["tokens_at_end"].get("total") or 0)
                t["cost_usd"] += float(s["tokens_at_end"].get("priced_usd") or 0)
                t["cost_complete"] = t["cost_complete"] and not s["tokens_at_end"].get("unpriced")
            else:
                t["tokens"] += sp["tokens"]
                t["cost_usd"] += sp["cost_usd"]
                t["cost_complete"] = t["cost_complete"] and sp["complete"]
    tasks = []
    for t in task_rows.values():
        tasks.append({**t, "hours": _hours(t["seconds"]), "cost_usd": round(t["cost_usd"], 4),
                      "agents": sorted(t["agents"]), "first_start": _iso(t["first_start"]),
                      "last_end": _iso(t["last_end"]) if t["last_end"] else None})
    tasks.sort(key=lambda t: t["first_start"])
    finished = [t for t in tasks if t["status"] == "done"]
    ended = [s for s in sess if s["end"]]
    open_sessions = [s for s in sess if s["end"] is None]
    measured_iv = _union([(s["start"], s["end"]) for s in ended])
    measured_h = sum((b - a).total_seconds() for a, b in measured_iv) / 3600.0
    ticked_total = sum(1 for f in ticked.values() for v in f.values() if v)
    measured_keys = {(t["feature"], t["task"]) for t in finished}
    unmeasured = sorted(f"{f}/{t}" for f, tt in ticked.items() for t, v in tt.items() if v and (f, t) not in measured_keys)

    # When the project has no git, session snapshots are the only line source.
    snapshot_lines = sum((s["changes"] or {}).get("added", 0) for s in ended)

    # ---- hours and ROI ----------------------------------------------------------
    ai_outside = defaultdict(list)
    for c in period:
        if c["class"] == "ai" and not c["in_session"]:
            ai_outside[c["email"]].append(c["at"])
    est_ai_h = sum(_estimate_hours(v, gap, lead) for v in ai_outside.values())
    human_by = defaultdict(list)
    for c in period:
        if c["class"] == "human":
            human_by[c["email"]].append(c["at"])
    est_human_h = sum(_estimate_hours(v, gap, lead) for v in human_by.values())

    loc_basis = "assumed" if float(cfg["human_loc_per_hour"]) == DEFAULTS["human_loc_per_hour"] and \
        "human_loc_per_hour" not in _read_json(config_path(spar_root), {}) else "set"
    loc_per_hour = float(cfg["human_loc_per_hour"])
    if count["human"] >= 20 and est_human_h >= 8 and added["human"] > 0 and loc_basis == "assumed":
        loc_per_hour = round(added["human"] / est_human_h, 2)
        loc_basis = "derived from this repository's human commits"
    rate_basis = "set" if "rate_per_hour" in _read_json(config_path(spar_root), {}) else "assumed"
    hourly = float(cfg["rate_per_hour"])

    ai_lines = added["ai"] if git_ok else snapshot_lines
    ai_lines_basis = "git" if git_ok else "session snapshots"
    actual_h = measured_h + est_ai_h
    equiv_h = ai_lines / loc_per_hour if loc_per_hour > 0 else 0.0
    human_rr = rate("human")
    excess = rework["ai"] - (ai_lines * human_rr if human_rr is not None else 0)
    excess = max(0.0, excess)
    quality_h = excess / loc_per_hour if loc_per_hour > 0 else 0.0
    saved_h = equiv_h - actual_h
    value = (saved_h - quality_h) * hourly
    spend_usd = spend["cost_usd"]
    roi = {
        "currency": cfg["currency"],
        "rate_per_hour": {"value": hourly, "basis": rate_basis},
        "human_loc_per_hour": {"value": loc_per_hour, "basis": loc_basis},
        "ai_lines": {"value": ai_lines, "basis": ai_lines_basis},
        "ai_hours": {"value": round(actual_h, 2), "measured": round(measured_h, 2), "estimated": round(est_ai_h, 2),
                     "basis": "measured sessions + commit-timing estimate outside sessions"},
        "human_equivalent_hours": {"value": round(equiv_h, 2), "basis": "ai_lines / human_loc_per_hour"},
        "quality_cost_hours": {"value": round(quality_h, 2), "excess_rework_lines": round(excess),
                               "basis": "AI rework beyond the human rework rate, rewritten at human speed"},
        "hours_saved": round(saved_h, 2),
        "value": round(value, 2),
        "spend": {"value": spend_usd, "complete": spend["complete"]},
        "net": round(value - spend_usd, 2),
        "multiple": round(value / spend_usd, 2) if spend_usd > 0 else None,
        "multiple_is_upper_bound": not spend["complete"],
        "formula": "value = (human_equivalent_hours - ai_hours - quality_cost_hours) x rate; multiple = value / spend",
    }

    # ---- weekly ---------------------------------------------------------------
    weeks: dict[str, dict] = {}

    def wk(dt: datetime) -> dict:
        k = _week(dt)
        if k not in weeks:
            y, w, _ = dt.isocalendar()
            weeks[k] = {"week": k, "start": date.fromisocalendar(y, w, 1).isoformat(), "commits_ai": 0,
                        "commits_human": 0, "lines_ai": 0, "lines_human": 0, "rework_ai": 0, "rework_human": 0,
                        "contributors": set(), "ai_contributors": set(), "sessions": 0, "tasks_done": 0,
                        "session_hours": 0.0, "tokens": 0, "cost_usd": 0.0}
        return weeks[k]

    for c in period:
        if c["class"] not in ("ai", "human"):
            continue
        w = wk(c["at"])
        w[f"commits_{c['class']}"] += 1
        w[f"lines_{c['class']}"] += c["stats"]["added"]
        w["contributors"].add(c["email"])
        if c["class"] == "ai":
            w["ai_contributors"].add(c["email"])
    for k, cnt in rework_week.items():
        if k in weeks:
            weeks[k]["rework_ai"] += cnt.get("ai", 0)
            weeks[k]["rework_human"] += cnt.get("human", 0)
    for s in ended:
        w = wk(s["start"])
        w["sessions"] += 1
        w["session_hours"] += (s["end"] - s["start"]).total_seconds() / 3600.0
        if s["status"] == "done":
            w["tasks_done"] += 1
    for m in msgs:
        if period_start is None or m["at"] >= period_start:
            wk(m["at"])["tokens"] += _tokens(m)
    for k in list(weeks):
        lo = datetime.combine(date.fromisoformat(weeks[k]["start"]), datetime.min.time(), timezone.utc)
        weeks[k]["cost_usd"] = spend_in(msgs, wins, table, cfg, max(lo, period_start) if period_start else lo,
                                        lo + timedelta(days=7) - timedelta(microseconds=1))["cost_usd"]
    weekly = []
    for k in sorted(weeks):
        w = weeks[k]
        weekly.append({**w, "contributors": len(w["contributors"]), "ai_contributors": len(w["ai_contributors"]),
                       "session_hours": round(w["session_hours"], 2)})

    # ---- pull requests --------------------------------------------------------
    pr_rows: list[dict] = []
    prs_data = fetch_prs(spar_root) if refresh_prs else _read_json(cache_dir(spar_root) / "prs.json", None)
    pr_summary: dict = {"available": False, "reason": "not fetched; run `spar impact report --prs`"}
    if prs_data and prs_data.get("available"):
        ai_shas = {c["sha"] for c in commits if c["class"] == "ai"}
        rows = []
        for pr in prs_data.get("prs") or []:
            created, merged = _parse(pr.get("createdAt")), _parse(pr.get("mergedAt"))
            if merged is None or (period_start and merged < period_start):
                continue
            oids = {c.get("oid") for c in pr.get("commits") or []}
            author = (pr.get("author") or {}).get("login")
            reviews = [r for r in pr.get("reviews") or [] if (r.get("author") or {}).get("login") != author]
            first = min((_parse(r.get("submittedAt")) for r in reviews if _parse(r.get("submittedAt"))), default=None)
            text = pr.get("title") or ""
            ai = bool(oids & ai_shas) or any(rx.search(text) for _, rx in AI_SIGNS)
            authored = [t for t in (_parse(c.get("authoredDate")) for c in pr.get("commits") or []) if t]
            first_commit = min(authored) if authored else None
            rows.append({"number": pr.get("number"), "title": pr.get("title"), "author": author, "ai": ai,
                         "cycle_hours": _hours((merged - created).total_seconds()) if created else None,
                         "first_review_hours": _hours((first - created).total_seconds()) if first and created else None,
                         "reviews": len(reviews), "additions": pr.get("additions"), "url": pr.get("url"),
                         "created_at": _iso(created) if created else None, "merged_at": _iso(merged),
                         "coding_hours": _hours(max(0.0, (created - first_commit).total_seconds()))
                         if created and first_commit else None,
                         "review_to_merge_hours": _hours(max(0.0, (merged - first).total_seconds())) if first else None,
                         "oids": sorted(o for o in oids if o)})
        pr_rows = rows
        ai_rows = [r for r in rows if r["ai"]]
        hu_rows = [r for r in rows if not r["ai"]]
        pr_summary = {
            "available": True, "fetched_at": prs_data.get("fetched_at"), "merged": len(rows), "ai_assisted": len(ai_rows),
            "median_cycle_hours_ai": _median([r["cycle_hours"] for r in ai_rows]),
            "median_cycle_hours_human": _median([r["cycle_hours"] for r in hu_rows]),
            "median_first_review_hours": _median([r["first_review_hours"] for r in rows]),
            "reviews_per_pr": round(sum(r["reviews"] for r in rows) / len(rows), 2) if rows else None,
            "unreviewed": sum(1 for r in rows if r["reviews"] == 0),
            "items": [{k: v for k, v in r.items() if k != "oids"} for r in rows[:100]],
            **_pr_trends(rows),
        }
    elif prs_data:
        pr_summary = {"available": False, "reason": prs_data.get("reason", "unavailable")}

    # ---- tickets --------------------------------------------------------------
    tickets: dict[str, dict] = {}
    known = {k.split("-")[0] for k in keys.values()}
    for t in tasks:
        if t["issue"]:
            e = tickets.setdefault(t["issue"], {"key": t["issue"], "tasks": [], "hours": 0.0, "commits": 0, "ai_commits": 0})
            e["tasks"].append(t["task"])
            e["hours"] = round(e["hours"] + t["hours"], 2)
    if known:
        rx = re.compile(r"\b(" + "|".join(sorted(re.escape(k) for k in known)) + r")-\d+\b")
        for c in period:
            for key in set(m.group(0) for m in rx.finditer(c["message"])):
                e = tickets.setdefault(key, {"key": key, "tasks": [], "hours": 0.0, "commits": 0, "ai_commits": 0})
                e["commits"] += 1
                e["ai_commits"] += int(c["class"] == "ai")

    # ---- attention ------------------------------------------------------------
    attention = []

    def note(level: str, title: str, detail: str, next_step: str = "") -> None:
        attention.append({"level": level, "title": title, "detail": detail, "next": next_step})

    if not baseline:
        note("warn", "Not measuring yet",
             "No baseline is recorded, so every commit is classified by evidence alone.",
             "Run `spar impact backfill --ai-assisted-fully` if AI built this project, otherwise `spar impact backfill` to start now.")
    if not git_ok:
        note("warn", "No git history",
             "Lines, rework, contributors and pull requests come from git; only session measurements are available.",
             "Initialise git and commit, then run the report again.")
    stale = [s for s in open_sessions if now - s["start"] > timedelta(hours=12)]
    if stale:
        note("warn", f"{len(stale)} session{'s' if len(stale) != 1 else ''} never ended",
             ", ".join(sorted({f"{s['task']}" for s in stale})) + " began more than 12 hours ago and have no end.",
             "Run `spar impact end <task> --status abandoned` for each.")
    if spend["unpriced_tokens"]:
        names = ", ".join(f"{k} ({v:,} tokens)" for k, v in spend["unpriced_tokens"].items())
        note("warn", "Spend is incomplete",
             f"No price is known for {names}; that spend is not in the totals and the ROI multiple is an upper bound.",
             "Set each with `spar impact price <model> --input <$/MTok> --output <$/MTok>`.")
    ai_rr, hu_rr = rate("ai"), rate("human")
    if ai_rr is not None and hu_rr and added["ai"] >= 200 and ai_rr >= hu_rr * 1.5:
        worst = hotspots[0]["area"] if hotspots and hotspots[0]["rework_lines"] else None
        note("warn", "AI code is reworked more than human code",
             f"{round(ai_rr * 100, 1)}% of AI-written lines were rewritten within {cfg['rework_window_days']} days, "
             f"against {round(hu_rr * 100, 1)}% for human-written lines" + (f"; most rework is in {worst}." if worst else "."),
             "Review the tasks behind the hotspot: unclear acceptance criteria are the usual cause.")
    if unmeasured and baseline and mode != "ai-assisted-fully":
        note("info", f"{len(unmeasured)} finished task{'s' if len(unmeasured) != 1 else ''} not measured",
             "Ticked in tasks.md with no completed begin/end session: " + ", ".join(unmeasured[:8]) + ("…" if len(unmeasured) > 8 else ""),
             "Builds record sessions automatically from now on; older tasks stay unmeasured.")
    if tracked >= 10 and count["ai"] / tracked < 0.2:
        note("info", "Low AI adoption", f"{count['ai']} of {tracked} commits in the period show AI evidence.",
             "Commit with the tool's co-author trailer, or build through SPAR, so AI work is counted.")
    if loc_basis == "assumed":
        note("info", "ROI uses an assumed baseline",
             f"Human-equivalent effort assumes {loc_per_hour:g} delivered lines an hour and ${hourly:g} an hour.",
             "Set yours with `spar impact config human_loc_per_hour N` and `spar impact config rate_per_hour N`.")
    if first_msg and period_start and first_msg - period_start > timedelta(days=31):
        note("info", "Early spend is missing",
             f"The oldest Claude Code transcript for this project is from {first_msg.date()}; earlier ones were pruned.",
             "Spend before then is not in the totals. The ledger keeps everything from now on.")
    if skipped:
        note("info", "Rework sampled", f"Rework was computed for the most recent 3000 commits; {skipped} older ones were skipped.")
    if spend["tokens"] == 0 and spend["cost_usd"] == 0 and count["ai"]:
        note("warn", "No AI spend found",
             "No Claude Code transcript for this folder and no turn recorded by the SPAR app, so the spend is $0 and the ROI multiple cannot be computed.",
             "Spend from other tools (Copilot, Cursor) is not visible to SPAR; build through the SPAR app or Claude Code in this folder from now on.")
    if rework["ai"] and human_rr is None:
        note("info", "No human baseline for rework",
             "There are no human-written lines in the period to compare against, so all AI rework is charged as extra effort in the ROI.",
             "This is the conservative reading; it overstates the quality cost if some rework is normal iteration.")

    delivery = {
        "sessions": len(sess), "open_sessions": len(open_sessions),
        "tasks_measured": len(tasks), "tasks_done": len(finished),
        "first_pass_rate": round(sum(1 for t in finished if t["attempts"] == 1) / len(finished), 4) if finished else None,
        "median_task_hours": _median([t["hours"] for t in finished]),
        "measured_hours": round(measured_h, 2), "tasks_ticked": ticked_total, "unmeasured_tasks": unmeasured,
    }

    extra = _insights(period, contributors, weekly, msgs, wins, table, cfg, sess, tasks, pr_rows, rework, added,
                      loc_per_hour, hourly, period_start, now)

    return {
        "schema": SCHEMA,
        "generated_at": _iso(now),
        "project": root.name,
        "baseline": baseline,
        "period": {"start": _iso(period_start) if period_start else None, "end": _iso(now)},
        "sources": {
            "git": git_ok, "commits": len(commits), "commits_in_period": len(period),
            "sessions": len(sess), "transcript_messages": len(msgs),
            "app_turns": len(wins), "pull_requests": pr_summary.get("available", False),
        },
        "adoption": {
            "commits": dict(count), "ai_share": round(count["ai"] / tracked, 4) if tracked else None,
            "contributors": len(contributors),
            "ai_contributors": sum(1 for p in contributors if p["ai_commits"]),
            "tools": dict(tools.most_common()),
            "declared_commits": declared_commits,
        },
        "output": {
            "lines_added": dict(added), "lines_removed": dict(removed),
            "ai_line_share": round(added["ai"] / (added["ai"] + added["human"]), 4) if (added["ai"] + added["human"]) else None,
            "by_category": {k: dict(v) for k, v in sorted(by_cat.items())},
            "note": "lines are code and tests; lockfiles, generated and vendored files are excluded",
        },
        "quality": {
            "window_days": cfg["rework_window_days"], "rework_lines": rework,
            "rework_rate": {"ai": ai_rr, "human": hu_rr}, "hotspots": hotspots[:15],
            "definition": "a line deleted or changed within the window after the commit that wrote it (git blame)",
        },
        "delivery": delivery,
        "tasks": tasks,
        "spend": spend,
        "roi": roi,
        "weekly": weekly,
        "contributors": contributors,
        "pull_requests": pr_summary,
        "tickets": sorted(tickets.values(), key=lambda t: t["key"]),
        "attention": attention,
        **extra,
        "commits": [{"sha": c["sha"], "at": _iso(c["at"]), "author": c["author"], "email": c["email"],
                     "class": c["class"], "basis": c["basis"], "tool": c["tool"], "task": c["task"],
                     "added": c["stats"]["added"], "removed": c["stats"]["removed"],
                     "subject": c["message"].strip().splitlines()[0] if c["message"].strip() else ""} for c in commits],
    }


# --------------------------------------------------------------------------- #
# Rendering
# --------------------------------------------------------------------------- #


def _pct(x) -> str:
    return "n/a" if x is None else f"{x * 100:.1f}%"


def _money(x, cur: str = "USD") -> str:
    if x is None:
        return "n/a"
    sign = "-" if x < 0 else ""
    return f"{sign}{'$' if cur == 'USD' else cur + ' '}{abs(x):,.2f}"


def render_text(r: dict) -> str:
    L = []
    b = r["baseline"] or {}
    L.append(f"AI impact · {r['project']}")
    L.append(f"  period      {(r['period']['start'] or 'all history')[:10]} → {r['period']['end'][:10]}   baseline: {b.get('mode', 'none')}")
    a, o, q, d, roi, sp = r["adoption"], r["output"], r["quality"], r["delivery"], r["roi"], r["spend"]
    cm = a["commits"]
    L.append(f"  commits     {cm.get('ai', 0)} AI · {cm.get('human', 0)} human · {cm.get('bot', 0)} bot   AI share {_pct(a['ai_share'])}")
    L.append(f"  lines       {o['lines_added'].get('ai', 0):,} AI · {o['lines_added'].get('human', 0):,} human   AI share {_pct(o['ai_line_share'])}")
    L.append(f"  rework      AI {_pct(q['rework_rate']['ai'])} · human {_pct(q['rework_rate']['human'])}  (within {q['window_days']} days)")
    L.append(f"  tasks       {d['tasks_done']} done of {d['tasks_measured']} measured · {d['sessions']} sessions · "
             f"{d['measured_hours']}h measured · median {str(d['median_task_hours']) + 'h' if d['median_task_hours'] is not None else 'n/a'}"
             f" · first pass {_pct(d['first_pass_rate'])}")
    L.append(f"  spend       {_money(sp['cost_usd'], roi['currency'])} · {sp['tokens']:,} tokens" + ("" if sp["complete"] else "  (incomplete: unpriced models)"))
    mult = roi["multiple"]
    L.append(f"  ROI         value {_money(roi['value'], roi['currency'])} · net {_money(roi['net'], roi['currency'])} · "
             f"multiple {('≤ ' if roi['multiple_is_upper_bound'] else '') + (f'{mult}x' if mult is not None else 'n/a')}")
    L.append(f"              {roi['human_equivalent_hours']['value']}h human-equivalent − {roi['ai_hours']['value']}h with AI − "
             f"{roi['quality_cost_hours']['value']}h rework  @ {_money(roi['rate_per_hour']['value'], roi['currency'])}/h ({roi['rate_per_hour']['basis']})")
    if a["tools"] or a["declared_commits"]:
        L.append("  tools       " + " · ".join([f"{k} {v}" for k, v in a["tools"].items()]
                                              + ([f"declared, tool unknown {a['declared_commits']}"] if a["declared_commits"] else [])))
    if r["attention"]:
        L.append("")
        for n in r["attention"]:
            L.append(f"  {'!' if n['level'] == 'warn' else '·'} {n['title']}: {n['detail']}")
            if n["next"]:
                L.append(f"      → {n['next']}")
    return "\n".join(L)


def render_md(r: dict) -> str:
    roi, a, o, q, d, sp = r["roi"], r["adoption"], r["output"], r["quality"], r["delivery"], r["spend"]
    cur = roi["currency"]
    b = r["baseline"] or {}
    L = [f"# AI engineering impact: {r['project']}", "",
         f"Period {(r['period']['start'] or 'all history')[:10]} to {r['period']['end'][:10]} · baseline `{b.get('mode', 'none')}` · generated {r['generated_at']}", "",
         "## Summary", "", "| Metric | Value | Basis |", "|---|---|---|",
         f"| AI share of commits | {_pct(a['ai_share'])} ({a['commits'].get('ai', 0)} of {a['commits'].get('ai', 0) + a['commits'].get('human', 0)}) | git evidence |",
         f"| AI share of delivered lines | {_pct(o['ai_line_share'])} | git |",
         f"| AI productivity lift | {str(r['lift']['multiple']) + 'x' if r.get('lift', {}).get('multiple') is not None else 'n/a'} | {r.get('lift', {}).get('basis', '')} |",
         f"| Rework rate, AI / human | {_pct(q['rework_rate']['ai'])} / {_pct(q['rework_rate']['human'])} | git blame, {q['window_days']}-day window |",
         f"| Tasks done / measured | {d['tasks_done']} / {d['tasks_measured']} | SPAR sessions |",
         f"| Time with AI | {roi['ai_hours']['value']} h ({roi['ai_hours']['measured']} measured, {roi['ai_hours']['estimated']} estimated) | sessions + commit timing |",
         f"| Human-equivalent effort | {roi['human_equivalent_hours']['value']} h | {roi['ai_lines']['value']:,} lines at {roi['human_loc_per_hour']['value']:g}/h ({roi['human_loc_per_hour']['basis']}) |",
         f"| Rework cost | {roi['quality_cost_hours']['value']} h | {roi['quality_cost_hours']['basis']} |",
         f"| AI spend | {_money(sp['cost_usd'], cur)}{'' if sp['complete'] else ' (incomplete)'} | {sp['tokens']:,} tokens |",
         f"| Value | {_money(roi['value'], cur)} | at {_money(roi['rate_per_hour']['value'], cur)}/h ({roi['rate_per_hour']['basis']}) |",
         f"| ROI multiple | {('at most ' if roi['multiple_is_upper_bound'] else '') + (str(roi['multiple']) + 'x' if roi['multiple'] is not None else 'n/a')} | value / spend |",
         "", f"_{roi['formula']}_", ""]
    if r["attention"]:
        L += ["## Needs attention", ""]
        for n in r["attention"]:
            L.append(f"- **{n['title']}.** {n['detail']}" + (f" {n['next']}" if n["next"] else ""))
        L.append("")
    if r["weekly"]:
        L += ["## Weekly", "", "| Week | AI commits | Human commits | AI lines | Human lines | Rework (AI) | Tasks done | Spend |", "|---|---|---|---|---|---|---|---|"]
        for w in r["weekly"][-12:]:
            L.append(f"| {w['week']} | {w['commits_ai']} | {w['commits_human']} | {w['lines_ai']:,} | {w['lines_human']:,} | {w['rework_ai']} | {w['tasks_done']} | {_money(w['cost_usd'], cur)} |")
        L.append("")
    if r["contributors"]:
        L += ["## Contributors", "", "| Contributor | Commits | AI share | Lines | Rework | Strengths | Growth |", "|---|---|---|---|---|---|---|"]
        for p in r["contributors"][:25]:
            L.append(f"| {p['name']} | {p['commits']} | {_pct(p['ai_share'])} | {p['lines_added']:,} | {_pct(p['rework_rate'])} | {'; '.join(p['strengths']) or '-'} | {'; '.join(p['growth']) or '-'} |")
        L.append("")
    if q["hotspots"]:
        L += ["## Rework hotspots", "", "| Area | Lines added | AI share | Rework lines | Rework rate |", "|---|---|---|---|---|"]
        for h in q["hotspots"][:10]:
            L.append(f"| {h['area']} | {h['lines_added']:,} | {_pct(h['ai_share'])} | {h['rework_lines']} | {_pct(h['rework_rate'])} |")
        L.append("")
    if r["tasks"]:
        L += ["## Tasks", "", "| Task | Attempts | Hours | Lines | Tokens | Cost | Status |", "|---|---|---|---|---|---|---|"]
        for t in r["tasks"]:
            L.append(f"| {t['feature'] or ''} {t['task']} | {t['attempts']} | {t['hours']} | +{t['lines_added']}/-{t['lines_removed']} | {t['tokens']:,} | {_money(t['cost_usd'], cur)} | {t['status']} |")
        L.append("")
    return "\n".join(L)


def render_csv(r: dict) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["sha", "date", "author", "email", "class", "basis", "tool", "task", "lines_added", "lines_removed", "subject"])
    for c in r["commits"]:
        w.writerow([c["sha"], c["at"], c["author"], c["email"], c["class"], c["basis"], c["tool"] or "", c["task"] or "",
                    c["added"], c["removed"], c["subject"]])
    return buf.getvalue()


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #

SETTABLE = {"rate_per_hour": float, "currency": str, "human_loc_per_hour": float, "rework_window_days": float,
            "session_gap_minutes": float, "session_lead_minutes": float}


def main(args, spar_root: Path, out) -> int:
    """`spar impact …`. *out* is the CLI's (ok, bad, info) printers."""
    ok, bad, info = out
    cmd = getattr(args, "icmd", None) or "report"
    try:
        if cmd == "begin":
            ev, created = begin(spar_root, args.task, args.feature, args.agent, args.model, args.tool)
            if getattr(args, "json", False):
                print(json.dumps({**ev, "created": created}))
            elif created:
                ok(f"impact: {ev['task']} began {ev['at']}" + (f" ({ev['feature']})" if ev.get("feature") else ""))
            else:
                info(f"impact: {ev['task']} is already open since {ev['at']}")
            return 0
        if cmd == "end":
            ev = end(spar_root, args.task, args.feature, args.status)
            if getattr(args, "json", False):
                print(json.dumps(ev))
            else:
                ch = ev.get("changes") or {}
                ok(f"impact: {ev['task']} {ev['status']} after {round(ev['duration_s'] / 60, 1)} min · "
                   f"+{ch.get('added', 0)}/-{ch.get('removed', 0)} lines · {len(ev['commits'])} commits · "
                   f"{ev['tokens']['total']:,} tokens" + (" · ticked in tasks.md" if ev.get("ticked") else ""))
            return 0
        if cmd == "usage":
            ev = record_usage(spar_root, float(args.cost_usd), args.agent or "", args.model or "", args.family or "",
                              args.session or "", args.start)
            if getattr(args, "json", False):
                print(json.dumps(ev))
            return 0
        if cmd == "backfill":
            b = backfill(spar_root, fully=args.ai_assisted_fully, since=args.since, note=args.note or "")
            if args.prs:
                p = fetch_prs(spar_root)
                (ok if p.get("available") else info)(
                    f"pull requests: {len(p.get('prs') or [])} merged" if p.get("available") else f"pull requests: {p.get('reason')}")
            r = build_report(spar_root)
            if getattr(args, "json", False):
                print(json.dumps(r, indent=2, default=str))
                return 0
            ok(f"baseline: {b['mode']} since {b['since'][:10]}")
            print(render_text(r))
            return 0
        if cmd == "status":
            cfg = read_config(spar_root)
            ss = sessions(read_events(spar_root))
            opened = [s for s in ss if s["end"] is None]
            payload = {"baseline": cfg.get("baseline"), "sessions": len(ss),
                       "open": [{"task": s["task"], "feature": s["feature"], "since": _iso(s["start"])} for s in opened]}
            if getattr(args, "json", False):
                print(json.dumps(payload, indent=2))
                return 0
            b = cfg.get("baseline")
            info(f"baseline: {b['mode']} since {b['since'][:10]}" if b else "baseline: none (run `spar impact backfill`)")
            info(f"sessions: {len(ss)} · open: {len(opened)}")
            for s in opened:
                print(f"    {s['task']} ({s['feature'] or '-'}) since {_iso(s['start'])}")
            return 0
        if cmd == "config":
            cfg = read_config(spar_root)
            if not args.key:
                for k in SETTABLE:
                    print(f"  {k:<22} {cfg[k]}")
                return 0
            if args.key not in SETTABLE:
                bad(f"unknown setting {args.key}; one of {', '.join(SETTABLE)}")
                return 2
            if args.value is None:
                print(cfg[args.key])
                return 0
            try:
                val = SETTABLE[args.key](args.value)
            except ValueError:
                bad(f"{args.key} needs a {SETTABLE[args.key].__name__}")
                return 2
            if isinstance(val, float) and val < 0:
                bad(f"{args.key} must not be negative")
                return 2
            stored = _read_json(config_path(spar_root), {})
            stored = stored if isinstance(stored, dict) else {}
            stored[args.key] = val
            write_config(spar_root, stored)
            ok(f"{args.key} = {val}")
            return 0
        if cmd == "price":
            cfg = _read_json(config_path(spar_root), {})
            cfg = cfg if isinstance(cfg, dict) else {}
            table = cfg.setdefault("prices", {})
            if not args.model:
                merged = prices(cfg)
                for k in sorted(merged):
                    p = merged[k]
                    src = "set" if k in {model_key(x) for x in table} else "published"
                    print(f"  {k:<24} in {p['input']:>7g}  out {p['output']:>7g}  cache read {p['cache_read']:g}  "
                          f"write {p['cache_write_5m']:g}/{p['cache_write_1h']:g}  ({src}, $/MTok)")
                return 0
            key = model_key(args.model)
            if args.remove:
                table.pop(key, None)
                write_config(spar_root, cfg)
                ok(f"price for {key} removed")
                return 0
            if args.input is None or args.output is None:
                bad("usage: spar impact price <model> --input <$/MTok> --output <$/MTok>")
                return 2
            entry = {"input": args.input, "output": args.output}
            for flag, name in (("cache_read", "cache_read"), ("cache_write_5m", "cache_write_5m"), ("cache_write_1h", "cache_write_1h")):
                v = getattr(args, flag, None)
                if v is not None:
                    entry[name] = v
            if any(v < 0 for v in entry.values()):
                bad("prices must not be negative")
                return 2
            table[key] = entry
            write_config(spar_root, cfg)
            ok(f"price for {key}: ${args.input:g} in / ${args.output:g} out per million tokens")
            return 0
        # report
        r = build_report(spar_root, refresh_prs=getattr(args, "prs", False))
        fmt = "json" if getattr(args, "json", False) else (getattr(args, "format", None) or "text")
        text = {"json": lambda: json.dumps(r, indent=2, default=str), "md": lambda: render_md(r),
                "csv": lambda: render_csv(r), "text": lambda: render_text(r)}[fmt]()
        if getattr(args, "out", None):
            Path(args.out).write_text(text + ("\n" if not text.endswith("\n") else ""), encoding="utf-8")
            ok(f"wrote {args.out}")
        else:
            print(text)
        return 0
    except ImpactError as exc:
        bad(str(exc))
        return 1
