"""`spar next`: the one deterministic answer to "what happens now?"

The SPAR app's Continue button and the phase commands (/spar.explore, /spar.design, …) ask this and do what it
says. It reads the artifacts on disk, the human gates in the ledger and the last
check results, and returns exactly one action. It never writes anything and it
never asks a model, so two callers looking at the same `spar/` get the same
answer.
"""

from __future__ import annotations

import os
import re
from datetime import datetime, timezone
from pathlib import Path

from .checks import ANALYZE_FILES, SCOPE_FILES, artifact_version, owner_of_failure, read_cache, read_roadmap
from .cli import scan_feature
from .gates import FIX_GATE, TENETS_FILES, TENETS_GATE, gate_state, pending_fixes, roadmap_state, tenets_state

SCHEMA = "spar.next/v1"

STAGES = (("brief", "Brief"), ("design", "Design"), ("build", "Build"), ("prove", "Deliver"))
FOLLOWONS = ["issues", "retro"]

# What counts as "a codebase" when deciding whether to adopt or to write tenets.
MANIFESTS = {
    "package.json", "pyproject.toml", "setup.py", "requirements.txt", "Cargo.toml", "go.mod",
    "pom.xml", "build.gradle", "build.gradle.kts", "Gemfile", "composer.json", "Package.swift",
    "mix.exs", "Makefile",
}
CODE_EXT = {".py", ".ts", ".tsx", ".js", ".jsx", ".rs", ".go", ".java", ".kt", ".rb", ".cs", ".swift", ".php", ".c", ".cc", ".cpp", ".h"}
SKIP_DIRS = {"node_modules", "target", "dist", "build", "vendor", "__pycache__", ".venv", "venv"}


# A brief given before there was anywhere to put it (a bare folder), kept until
# /spar.explore or /spar.explore turns it into a roadmap or a spec.
PENDING_BRIEF = "pending.md"


DELIVERY_ROUNDS = 3


def _release(feature_dir: Path) -> dict | None:
    """release.md, written by the release step: its status, the live URL, and — when it
    is waiting on the person — what they need to set up."""
    p = feature_dir / "release.md"
    if not p.is_file():
        return None
    text = p.read_text(encoding="utf-8", errors="replace")
    m = re.search(r"\*\*Status:\*\*\s*`?([A-Za-z-]+)", text)
    url = re.search(r"\*\*Live URL:\*\*\s*<?(\S+?)>?\s*$", text, re.M)
    needs = ""
    sec = re.search(r"^## Needs from you\s*\n(.*?)(?=^## |\Z)", text, re.M | re.S)
    if sec:
        needs = " ".join(l.strip().lstrip("-*0123456789. ").strip() for l in sec.group(1).splitlines() if l.strip())[:600]
    why = ""
    fail = re.search(r"^## Failure\s*\n(.*?)(?=^## |\Z)", text, re.M | re.S)
    if fail:
        why = " ".join(l.strip() for l in fail.group(1).splitlines() if l.strip())[:300]
    return {"status": (m.group(1).lower() if m else ""), "url": (url.group(1) if url and url.group(1) not in ("-", "none") else ""),
            "needs": needs, "why": why}


def _delivery(feature_dir: Path) -> dict | None:
    """The "## Delivery fixes" section the end-to-end test appends to tasks.md, if any:
    how many fix tasks are open, and how many rounds of fixing there have been."""
    p = feature_dir / "tasks.md"
    if not p.is_file():
        return None
    text = p.read_text(encoding="utf-8", errors="replace")
    cut = text.find("\n## Delivery fixes")
    if cut < 0:
        return None
    fixes = text[cut:]
    ids = set(re.findall(r"^###\s+(T\d{3,})", fixes, re.M))
    done = set(re.findall(r"^\s*-\s*\[[xX]\]\s*(T\d{3,})", text, re.M))
    rounds = len(re.findall(r"^\*\*Round \d+", fixes, re.M)) or (1 if ids else 0)
    return {"open": len(ids - done), "total": len(ids), "rounds": rounds}


def _has_code(root: Path, depth: int = 2) -> bool:
    count = 0
    base_depth = len(root.parts)
    for dirpath, dirnames, filenames in os.walk(root):
        if len(Path(dirpath).parts) - base_depth >= depth:
            dirnames[:] = []
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".")]
        for name in filenames:
            if name in MANIFESTS or (name.endswith(".csproj")):
                return True
            if Path(name).suffix.lower() in CODE_EXT:
                count += 1
                if count >= 5:
                    return True
    return False


def _tenets_marked(spar_root: Path) -> bool:
    p = spar_root / "tenets.md"
    if not p.is_file():
        return False
    head = p.read_text(encoding="utf-8", errors="replace")[:1200]
    return "UNREVIEWED" in head or "DRAFT" in head


def _tenets_unreviewed(spar_root: Path) -> bool:
    """Still marked DRAFT and nobody has approved the set.

    Once a person approves, later edits (an agent tidying a line, a tenet
    added by an amendment) do not send the whole set back for review: the
    approval stands until someone requests changes.
    """
    if not _tenets_marked(spar_root):
        return False
    t = tenets_state(spar_root)
    return not t["approved"]


# Which phase command owns a step. The app sends /spar.<phase>; the phase
# commands stop when `phase` moves past theirs.
def _phase(stage: str, action: str, command: str | None, gate: str | None) -> str:
    if gate == FIX_GATE or command == "fix":
        return "fix"
    if command == "verify":
        return "build"
    if command in ("init", "tenets", "context") or gate == TENETS_GATE:
        return "init"
    if command == "adopt":
        return "adopt"
    return {"brief": "explore", "design": "design", "build": "build", "prove": "deliver", "done": "deliver"}.get(stage, stage)


def _open_markers(feature_dir: Path, name: str = "spec.md", prefix: str = "") -> int:
    p = feature_dir / name
    if not p.is_file():
        return 0
    return p.read_text(encoding="utf-8", errors="replace").count(f"NEEDS CLARIFICATION[{prefix}")


def _iso_to_ts(value: str | None) -> float | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


def _mtime(path: Path) -> float:
    try:
        return path.stat().st_mtime
    except OSError:
        return 0.0


def latest_feature(spar_root: Path) -> str | None:
    specs = spar_root / "specs"
    if not specs.is_dir():
        return None
    dirs = sorted(p.name for p in specs.iterdir() if p.is_dir())
    return dirs[-1] if dirs else None



REASON_CHARS = 480


def _short(text: str) -> str:
    """A reason is a sentence for a card, not a report; the full text stays in the ledger."""
    text = " ".join(str(text or "").split())
    if len(text) <= REASON_CHARS:
        return text
    cut = text[:REASON_CHARS].rsplit(" ", 1)[0]
    return cut.rstrip(".,;:") + " …"

def _result(
    stage: str,
    action: str,
    reason: str,
    *,
    feature: str | None,
    command: str | None = None,
    scope: str | None = None,
    gate: str | None = None,
    owner: str | None = None,
    rows: list[str] | None = None,
    options: list[dict] | None = None,
) -> dict:
    ids = [s for s, _ in STAGES]
    stages = []
    for sid, label in STAGES:
        if stage == "done":
            state = "done"
        elif ids.index(sid) < ids.index(stage):
            state = "done"
        elif sid == stage:
            state = "current"
        else:
            state = "todo"
        stages.append({"id": sid, "label": label, "state": state})
    phase = _phase(stage, action, command, gate)
    return {
        "schema": SCHEMA,
        "feature": feature,
        "phase": phase,
        "phase_command": f"/spar.{phase}",
        "action": action,
        "command": command,
        "scope": scope,
        "gate": gate,
        "owner": owner,
        "rows": rows or [],
        "options": options or [],
        "stage": stage,
        "reason": _short(reason),
        "stages": stages,
        "followons": FOLLOWONS if stage == "done" else [],
    }


def compute_next(root: Path, spar_root: Path | None, feature: str | None) -> dict:
    """The single next action for *feature* (or the latest one)."""
    # 1. A new project starts with what the person wants to build. The engineering
    # principles are drafted from that brief (or, for existing code, from the code):
    # principles written before anyone knows the product are generic and get
    # rubber-stamped.
    has_pending = spar_root is not None and (spar_root / "briefs" / PENDING_BRIEF).is_file()
    if spar_root is None or not spar_root.is_dir() or not (spar_root / "tenets.md").is_file():
        if _has_code(root):
            return _result(
                "brief", "run",
                "This folder already has code. SPAR reads it and proposes engineering principles based on how it is built.",
                feature=None, command="adopt",
            )
        if not has_pending:
            return _result(
                "brief", "prompt",
                "Describe what you want to build. SPAR sets the project up and proposes its engineering principles "
                "(security, testing, data, technology choices) for you to approve, then writes the spec.",
                feature=None, command="init",
            )
        return _result(
            "brief", "run",
            "Proposing the engineering principles for what you described: security, testing, data and technology choices.",
            feature=None, command="tenets",
        )

    # 1b. The engineering principles are drafted but nobody has accepted them. This is the
    # one stop in setting a project up: the draft is written in a single pass,
    # then a person reads the set and approves it or says what to change.
    if _tenets_unreviewed(spar_root):
        t = tenets_state(spar_root)
        unfinished = [n for n in TENETS_FILES
                      if not (spar_root / n).is_file() or not (spar_root / n).read_text(encoding="utf-8", errors="replace").strip()]
        if unfinished:
            # Never put a half-written set in front of a reviewer.
            return _result(
                "brief", "run",
                f"The engineering principles are only partly drafted ({', '.join(unfinished)} still to write). Finish the set.",
                feature=None, command="tenets",
            )
        if t["changes_requested"] and not t["stale"]:
            return _result(
                "brief", "run",
                f"Changes requested to the engineering principles: {t['note'] or 'see the decision ledger'}. Redraft them with that feedback.",
                feature=None, command="tenets",
            )
        return _result(
            "brief", "gate",
            "SPAR proposed the project's engineering principles: how it handles security, testing, personal data and "
            "technology choices (tenets.md), the checks every change must pass (standards.md) and the sources it trusts "
            "(references.md). Every design and build is checked against them. Approve, or say what to change.",
            feature=None, gate=TENETS_GATE,
        )

    # 1c. A bug fix waiting for its one review comes first: it is small, and the
    # person asked for it moments ago.
    for fix_id, st in pending_fixes(spar_root):
        if st["changes_requested"] and not st["stale"]:
            return _result(
                "build", "run", f"Changes requested on fix {fix_id}: {st['note'] or 'see the ledger'}. Rework it.",
                feature=None, command="fix", scope=fix_id,
            )
        return _result(
            "build", "gate", f"Fix {fix_id} is ready: the failing test now passes and the guard is proven. Review the change and spar/fixes/{fix_id}.md.",
            feature=None, gate=FIX_GATE, scope=fix_id,
        )

    feature = feature or latest_feature(spar_root)
    feature_dir = spar_root / "specs" / feature if feature else None

    plan = roadmap_state(spar_root)
    roadmap = read_roadmap(spar_root)

    # 1a. There is a roadmap, so something on it has to be chosen — by a person.
    # This deliberately stops rather than starting the topmost unshipped MVP.
    # Dependency order says what is possible; a customer commitment or a
    # contract date says what is wanted, and none of that is written anywhere
    # here. Picking for them would be picking wrong in public.
    if roadmap:
        selected = plan["selected"]
        live = [m for m in roadmap if not m["shipped"]]
        chosen = next((m for m in roadmap if selected and m["id"] == selected["id"]), None)
        if live and chosen is None:
            return _result(
                "brief", "select",
                f"{len(live)} MVP{'s' if len(live) != 1 else ''} on the roadmap and none chosen. "
                f"Pick the one to build now — the order on the page is a recommendation, not a queue.",
                feature=None, command="roadmap",
                options=[
                    {
                        "id": m["id"],
                        "label": f"{m['id']} · {m['name']}" if m["name"] else m["id"],
                        "detail": m["delivers"],
                    }
                    for m in live
                ],
            )

    # 2. No brief. Either way this asks for the same thing — the user's words —
    # and only what runs behind them changes.
    #
    # On a project with nothing in it yet, those words go to the roadmapper
    # first, to decide whether this is one deliverable or several. That question
    # is worth asking once, here, because after a spec exists the answer costs a
    # spec to change. It is asked *with* the brief rather than before it, since
    # nobody can split a description that has not been written.
    #
    # The trigger is structural, as everything in this file has to be: no specs
    # and no ruling yet means a project starting. A brief arriving into a
    # workspace that already has features is a change to a product already
    # running, and is never asked.
    if feature_dir is None or not (feature_dir / "spec.md").is_file():
        chosen = plan["selected"]
        # The person already described what they want (saved when they gave it
        # before the engineering principles existed): use it rather than asking again.
        pending = spar_root / "briefs" / PENDING_BRIEF
        if pending.is_file() and pending.read_text(encoding="utf-8", errors="replace").strip():
            if not roadmap and not plan["single"] and latest_feature(spar_root) is None:
                return _result(
                    "brief", "run",
                    f"Your brief is saved in spar/briefs/{PENDING_BRIEF}. Decide whether it is one deliverable or a sequence of MVPs.",
                    feature=None, command="roadmap",
                )
            return _result(
                "brief", "run",
                f"Write the spec from your brief in spar/briefs/{PENDING_BRIEF}.",
                feature=feature, command="specify",
            )
        if not roadmap and not plan["single"] and latest_feature(spar_root) is None:
            return _result(
                "brief", "prompt",
                "Describe what you want built. Before the first spec is written, this is read once "
                "for whether it is one deliverable or a sequence of them — splitting it later means "
                "throwing a spec away.",
                feature=None, command="roadmap",
            )
        why = "Describe what you want built. The brief is written from your words."
        if chosen and roadmap:
            row = next((m for m in roadmap if m["id"] == chosen["id"]), None)
            if row:
                delivers = row["delivers"].rstrip(". ")
                why = (
                    f"{row['id']} is chosen: {delivers}. Write the brief for that alone — "
                    f"everything later on the roadmap stays out of scope."
                )
        return _result(
            "brief", "prompt", why,
            feature=feature, command="specify",
        )

    # 3. Unreviewed tenets block everything past the brief.
    if _tenets_unreviewed(spar_root):
        return _result(
            "design", "blocked",
            "The engineering principles in spar/tenets.md are still marked DRAFT or UNREVIEWED. Approve them first; a design checked against principles nobody has read is not checked.",
            feature=feature,
        )

    scan = scan_feature(feature_dir)
    has = lambda name: (feature_dir / name).is_file()  # noqa: E731
    ledger = gate_state(spar_root, feature)
    gates = ledger["gates"]
    cache = read_cache(spar_root, feature)

    # 4. Open questions, until the plan exists (some markers never close).
    markers = _open_markers(feature_dir)
    if markers and not has("plan.md"):
        return _result(
            "brief", "run",
            f"{markers} open question{'s' if markers != 1 else ''} in the brief. Answer them before it is approved.",
            feature=feature, command="clarify",
        )

    # 5. Gate A — but a reviewer is never handed a brief that fails its own
    # structural checks. Those are cheap and deterministic, so they run first
    # and route a defect back to the specifier rather than to a person.
    g = gates["approve-spec"]
    if not g["approved"] or g["stale"]:
        art = cache["scopes"].get("artifacts")
        art_version = artifact_version(feature_dir, SCOPE_FILES["artifacts"])
        if not art or art.get("version") != art_version:
            return _result(
                "brief", "check", "The brief changed since it was last checked. Run the structural checks.",
                feature=feature, scope="artifacts",
            )
        spec_check = next((c for c in art.get("checks", []) if c.get("name") == "spec.md"), None)
        if spec_check and spec_check.get("status") == "fail":
            return _result(
                "brief", "fix", f"Structural checks failed on the brief ({spec_check.get('summary', '')}). The specifier must fix it.",
                feature=feature, scope="artifacts", owner="specifier", command="specify",
            )
        why = "The brief changed after it was approved; approve it again." if g["stale"] else (
            "Changes were requested on the brief; revise it, then approve." if g["changes_requested"]
            else "The brief is written. Approve it to start the design."
        )
        return _result("brief", "gate", why, feature=feature, gate="approve-spec")

    # 6. Design artifacts.
    if not has("plan.md"):
        return _result("design", "run", "The brief is approved. Design the approach, data and contracts.", feature=feature, command="plan")

    # 6a. Platform questions the architect refused to answer on your behalf.
    # These block here rather than waiting for the analyzer, because every task
    # below inherits them: by the time a residual marker shows up as a BLOCK the
    # plan has already been decomposed against a language and a hosting target
    # nobody chose, and the answer costs a rewrite instead of a click. Unlike the
    # brief's markers at step 4, these always have a human answer available —
    # that is what makes it safe to stop for them.
    platform = _open_markers(feature_dir, "plan.md", "platform-")
    if platform:
        return _result(
            "design", "run",
            f"The plan needs {platform} platform decision{'s' if platform != 1 else ''} — what this is "
            f"built in and where it runs. Answer them before the design is approved.",
            feature=feature, command="clarify",
        )

    if not has("tasks.md"):
        return _result("design", "run", "The plan is written. Break it into ordered, parallel-safe tasks.", feature=feature, command="tasks")

    # 7. Deterministic artifact checks (the cache and version were read at 5;
    # writing plan.md or tasks.md changes the version, so re-derive).
    art = cache["scopes"].get("artifacts")
    art_version = artifact_version(feature_dir, SCOPE_FILES["artifacts"])
    if not art or art.get("version") != art_version:
        return _result(
            "design", "check", "The design artifacts changed since they were last checked. Run the structural checks.",
            feature=feature, scope="artifacts",
        )
    if not art.get("ok"):
        owner = owner_of_failure(art) or "task-planner"
        return _result(
            "design", "fix", f"Structural checks failed on the design artifacts ({art.get('summary', '')}). The owning agent must fix them.",
            feature=feature, scope="artifacts", owner=owner,
            command={"specifier": "specify", "architect": "plan", "task-planner": "tasks"}.get(owner, "tasks"),
        )

    # 8. Analyzer verdict for this design.
    #
    # The record carries no version, so freshness is judged by time. When the
    # harness noted the attempt (`spar check --note-analyze-attempt`) for this
    # very design version, a record written around then counts. Otherwise the
    # record must be newer than the design files — except that once a build has
    # started, tasks.md changes for bookkeeping reasons, so only plan.md counts.
    analyze_version = artifact_version(feature_dir, ANALYZE_FILES)
    rec = ledger.get("analyze")
    rec_at = _iso_to_ts(rec.get("at")) if rec else None
    # A standards exemption recorded after the analyzer spoke changes what it
    # would say, so the verdict is stale. Ledger order, not the clock, decides:
    # two records in the same second still have an order.
    exempt_seq = max((int(e.get("seq") or 0) for e in ledger.get("exemptions", [])), default=0)
    exempt_after_analyze = bool(rec) and exempt_seq > int(rec.get("seq") or 0)
    exempt_ts = max((_iso_to_ts(e.get("at")) or 0.0 for e in ledger.get("exemptions", [])), default=0.0)
    attempted_at = _iso_to_ts(cache.get("analyze_attempted_at")) if cache.get("analyze_attempted_at") else None
    attempt_counts = (
        cache.get("analyze_attempted_for") == analyze_version
        and attempted_at is not None
        and attempted_at >= exempt_ts
    )
    if attempt_counts:
        threshold = (attempted_at or 0.0) - 600.0
    elif has("build-log.md"):
        threshold = _mtime(feature_dir / "plan.md") - 1.0
    else:
        threshold = max(_mtime(feature_dir / "plan.md"), _mtime(feature_dir / "tasks.md")) - 1.0
    fresh = rec_at is not None and rec_at >= threshold and not exempt_after_analyze
    if not fresh:
        if attempt_counts and not exempt_after_analyze:
            return _result(
                "design", "blocked",
                "The analyzer ran against these artifacts but recorded no verdict in the ledger. Run /spar.design by hand and check its output.",
                feature=feature,
            )
        return _result(
            "design", "run", "Check that the spec, plan and tasks agree with each other before anything is built.",
            feature=feature, command="analyze",
        )
    if rec.get("verdict") == "blocked":
        explanation = rec.get("explanation") or "see its report"
        rows = sorted(set(re.findall(r"\bS-\d{2,3}\b", explanation)))
        tail = (
            " If a named standards row does not apply to this project, record that with "
            "`spar gate exempt <feature> <ROW> --note ...` and the analyzer runs again."
            if rows
            else " Fix the named artifacts, then continue."
        )
        return _result(
            "design", "blocked",
            "The analyzer found drift between the artifacts: " + explanation + "." + tail,
            feature=feature, rows=rows,
        )

    # 9. Gate B.
    g = gates["approve-plan"]
    if not g["approved"] or g["stale"]:
        why = "The plan or tasks changed after approval; approve the design again." if g["stale"] else (
            "Changes were requested on the design; revise it, then approve." if g["changes_requested"]
            else f"The design is consistent ({scan['tasks_total']} tasks). Approve it to start building."
        )
        return _result("design", "gate", why, feature=feature, gate="approve-plan")

    # 9b. The end-to-end test found problems and sent them back as fix tasks: build them
    # without another design or checkpoint review, then prove it again. Bounded, so a
    # problem the agents can't fix comes back to a person instead of looping.
    delivery = _delivery(feature_dir)
    if delivery and delivery["open"] > 0:
        if delivery["rounds"] > DELIVERY_ROUNDS:
            return _result(
                "build", "blocked",
                f"{DELIVERY_ROUNDS} rounds of fixes and the end-to-end test still fails ({delivery['open']} open). "
                "Look at the open delivery-fix tasks and the evidence in verification.md.",
                feature=feature,
            )
        return _result(
            "build", "run",
            f"Fixing the {delivery['open']} problem{'s' if delivery['open'] != 1 else ''} the end-to-end test found "
            f"(round {delivery['rounds']} of {DELIVERY_ROUNDS}).",
            feature=feature, command="build",
        )

    # 10-12. Build, project checks, checkpoint.
    open_tasks = scan["tasks_total"] - scan["tasks_done"]
    if not has("build-log.md"):
        return _result("build", "run", f"The design is approved. Build the first phase ({open_tasks} tasks open).", feature=feature, command="build")

    proj = cache["scopes"].get("project")
    proj_version = artifact_version(feature_dir, SCOPE_FILES["project"], raw=True)
    if not proj or proj.get("version") != proj_version:
        return _result(
            "build", "check", "Code was built since the project checks last ran. Run the tests, lint and typecheck.",
            feature=feature, scope="project",
        )
    if not proj.get("ok"):
        return _result(
            "build", "fix", f"Project checks failed ({proj.get('summary', '')}). Fix them before the checkpoint.",
            feature=feature, scope="project", owner="task-executor", command="build",
        )

    # risk_tier decides how often a person is asked to look. A low-risk feature
    # is reviewed once, when every task is done; anything else stops at every
    # phase boundary the executor reaches. This is the one place the tier is
    # read by code rather than displayed.
    low_risk = str(scan.get("risk_tier", "")).lower() == "low"
    g = gates["checkpoint"]
    # Delivery fixes touch the build log after the last checkpoint; that isn't new scope.
    if delivery and g["approved"] and not g["changes_requested"]:
        g = {**g, "stale": False}
    if low_risk and open_tasks > 0 and not g["changes_requested"]:
        return _result(
            "build", "run",
            f"Checks pass; risk tier is low, so the build continues to the next phase without a stop ({open_tasks} tasks open). You review once at the end.",
            feature=feature, command="build",
        )
    if not g["approved"] or g["stale"]:
        why = "The build moved on after the last checkpoint; review it again." if g["stale"] else (
            "Changes were requested at the checkpoint; address them, then approve." if g["changes_requested"]
            else f"Checks pass. Review the changes ({scan['tasks_done']}/{scan['tasks_total']} tasks done) and approve the checkpoint."
        )
        return _result("build", "gate", why, feature=feature, gate="checkpoint")
    if open_tasks > 0:
        return _result("build", "run", f"Checkpoint approved. Build the next phase ({open_tasks} tasks open).", feature=feature, command="build")

    # 13. Test: the suites, then the whole product end to end (part of Develop).
    if not has("verification.md"):
        return _result("build", "run", "Every task is done. Start the app and test it end to end, like a person would.", feature=feature, command="verify")
    # Fixes landed after the last end-to-end run: run it again.
    if delivery and (feature_dir / "tasks.md").stat().st_mtime > (feature_dir / "verification.md").stat().st_mtime:
        return _result(
            "build", "run",
            f"The fixes are in. Start the app and run the end-to-end test again (after round {delivery['rounds']}).",
            feature=feature, command="verify",
        )
    ver = cache["scopes"].get("verification")
    ver_version = artifact_version(feature_dir, SCOPE_FILES["verification"])
    if not ver or ver.get("version") != ver_version:
        return _result(
            "build", "check", "verification.md was written; check that its verdict agrees with its own rows.",
            feature=feature, scope="verification",
        )
    if not ver.get("ok"):
        first = next(
            (f["message"] for c in ver.get("checks", []) for f in c.get("findings", []) if f["severity"] == "error"),
            ver.get("summary", ""),
        )
        return _result(
            "build", "blocked", "Verification is disputed: " + first + ". Fix the gap and run /spar.build again.",
            feature=feature, owner="verifier",
        )

    # 14. Deliver: the person's OK, then push, provision, deploy and check it live.
    g = gates.get("approve-release")
    if g is None or not g["approved"] or g["stale"]:
        why = "It passed its tests again after your OK; approve the release again." if g and g["stale"] else (
            "Changes were requested before release; address them, then approve." if g and g["changes_requested"]
            else "Everything passes locally. Approve to push the code to GitHub, create the infrastructure you "
                 "chose and deploy it."
        )
        return _result("prove", "gate", why, feature=feature, gate="approve-release")
    rel = _release(feature_dir)
    if rel is None or rel["status"] in ("", "in-progress", "planned"):
        return _result(
            "prove", "run",
            "Approved. Push to GitHub, create the infrastructure, deploy, and check the live app.",
            feature=feature, command="release",
        )
    if rel["status"] == "needs-setup":
        return _result(
            "prove", "setup",
            rel["needs"] or "The release needs something only you can set up; see release.md.",
            feature=feature, command="release",
        )
    if rel["status"] == "failed":
        return _result(
            "prove", "blocked", "The release failed: " + (rel["why"] or "see release.md") + ".",
            feature=feature, owner="releaser",
        )

    # 15. Done.
    where = f" Live at {rel['url']}." if rel.get("url") else ""
    return _result("done", "done", f"Delivered.{where} Export the tasks to your tracker or run the retro.", feature=feature)
