---
description: Establish or amend the governance trio: tenets, standards and references.
---

# step `tenets`

Creates `spar/tenets.md`, `spar/standards.md` and `spar/references.md` — the governance trio every later plan is checked against, twice, by a hard gate.

## Prerequisites

None. This is the first command in a new project.

## Usage

```
step `tenets` [--preset=org] [--amend=<file>]
```

- No arguments (or a brief): drafts the trio in one pass from the brief, your existing `CLAUDE.md`,
  README and org sources. Everything is marked DRAFT for your review.
- `--preset=org` starts from the enterprise baseline (~10 tenets, a full standards checklist, the
  connector role table), tailored the same way.
- `--amend=<file>` applies an approved amendment diff, usually one produced by step `retro`.
- `--interview` walks you through each tenet instead, one at a time.
- Feedback from a change request (`spar gate request-changes approve-tenets --note "..."`) is applied
  to the existing draft.

## Steps

1. `spar-tenets-author` mines the brief, existing repo docs and org sources, then drafts or amends the
   trio in one pass, marking every unreviewed item DRAFT. It does not stop to ask questions: where it
   has to guess, it drafts its best guess and says so in the item.
2. The role table in `references.md` is filled from whatever the MCP gateway can reach.
3. It ends with a short table of the tenets. The person reviews the set once, at the
   `approve-tenets` gate: `spar gate approve approve-tenets` (which clears the DRAFT markers), or
   `spar gate request-changes approve-tenets --note "..."` to have it redrafted.

## Output

The three trio files, a change summary, and a count of items still marked DRAFT.

> A preset you have not read is worse than no preset: the tenets gate will BLOCK plans against it.

**Next:** approve the engineering principles (`spar gate approve approve-tenets`), then `the phase loop` carries on with your brief.
