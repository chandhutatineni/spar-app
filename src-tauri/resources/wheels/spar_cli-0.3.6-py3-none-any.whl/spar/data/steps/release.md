---
description: Push to GitHub, provision the chosen infrastructure, deploy and smoke-test the live app, pausing for anything only the person can set up.
---

# step `release`

Takes a verified feature live. Runs only after the person approved the release.

## Prerequisites

`verification.md` passes, and the `approve-release` gate is approved.

## Usage

```
step `release` <feature>
```

## Steps

1. `spar-releaser` preflights everything the release needs — GitHub access, tools (Terraform, the
   cloud CLI), cloud login, app secrets — and, if anything is missing, writes exact instructions under
   **Needs from you** in `release.md`, sets **Status:** `needs-setup` and stops. The person sets it up
   and presses Continue; the step checks again and carries on.
2. It pushes the code to GitHub (creating the repository if needed) and commits the pipeline.
3. It provisions the infrastructure from `infra/` (Terraform plan, then apply; it asks first if
   anything would be destroyed or replaced).
4. It deploys the services in dependency order, directly or through the pipeline.
5. It smoke-tests the live app like a person and records the URL, resources and rollback.

## Output

`release.md` with **Status:** `live` and the live URL — or `needs-setup` / `failed` with what to do.

**Next:** done; offer step `retro` and step `issues`.
