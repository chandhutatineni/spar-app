---
description: Implement tasks, in parallel where safe, with deterministic checks and a controls review on every task.
---

# step `build`

Executes `tasks.md`. Tests first, then code, then the deterministic checks and the controls review. The harness decides when a checkpoint stops the build.

## Prerequisites

step `analyze` passed.

## Usage

```
step `build` <feature> [T###] [--phase N]
```

- No task id: works the next phase in order.
- `T###`: implements exactly one task.
- `--phase N`: works one phase.

## Steps

1. `spar-task-executor` runs per task — many in parallel for `[P]`-tagged tasks with disjoint files. Each task is bracketed for the impact report: `spar impact begin T### --feature <feature>` before any work on it, `spar impact end T### --feature <feature>` right after it is ticked (`--status failed` if it is abandoned). Commits for a task carry the trailer `SPAR-Task: <feature>/T###`.
2. Each executor writes the acceptance test first, confirms it fails, implements the minimum to pass, then re-runs the suite.
3. Each runs `spar check --feature <feature> --for-agent` — the project's declared tests, lint and typecheck plus the artifact lint — and fixes every finding, then `spar-controls-reviewer` reviews the change. BLOCKING findings must be fixed before the task is done.
4. As soon as a task passes its checks and review, tick it (`- [x] T###`) in `tasks.md` — one at a time, never in a batch at the end: the SPAR app shows build progress live from those ticks.
5. Each appends to `build-log.md`.
6. At a **Checkpoint**, ask the harness rather than assuming: run `spar next <feature> --json`.
   - `gate` → stop and ask the person to review the checkpoint (in the SPAR app they approve with the button; in a terminal, give the `spar gate approve <feature> checkpoint` line). This is the human's turn.
   - `run build` → the checkpoint does not stop this feature (a low `risk_tier` is reviewed once, at the end). Record the checkpoint in the build log and continue into the next phase without asking.
   - `fix` or `check` → do that first.
   Never ask the person to approve a checkpoint the harness did not ask for; they are running one Continue and expect it to reach the next real decision.

## Output

Working code in the repo, passing tests, `build-log.md` entries, tasks checked off.

**Next:** step `verify` (<feature>) when the final phase completes.
