---
description: Resolve every NEEDS CLARIFICATION marker, asking them together with a recommendation for each.
---

# step `clarify`

Drives each open question to a recorded decision. Security and data-classification questions go first, because they constrain everything downstream.

## Prerequisites

A spec with markers (step `specify`).

## Usage

```
step `clarify` <feature>
```

## You do the asking

**Run the questioning yourself, in this conversation.**

`spar-clarifier` is a subagent, and a subagent cannot reach the user — its output comes back to you,
not to a person, and it has no way to wait for an answer. Hand it the interrogation and the only
thing it can do is write the questions down; you get a report of thirty-four open items and not one
decision, which is precisely the outcome this command exists to prevent. It researches. You ask.

**Ask with a real control, never by asking someone to type a letter.** In the SPAR app that control
is the fenced ```spar-questions block described in `~/.claude/spar-steps/phase-loop.md` (Asking the
person): every decision and governed question in one block, each with its options and
recommendation. The app renders it as a form and sends back all the answers at once.

- `AskUserQuestion` when your host provides it.
- Otherwise, whatever picker the host describes in your prompt — a headless `claude -p` run carries
  no `AskUserQuestion` in its tool registry, so hosts that drive one describe their own block to
  emit instead.
- Only if neither exists: ask in prose, all questions in one numbered list, each with its
  recommendation, and accept "use your recommendations" as an answer to all of them.

"Reply with a, b, or c" is the failure mode, not the fallback. It turns a two-click decision into
transcription, and it is how twenty-one questions become a chore nobody finishes.

## Steps

1. Call `spar-clarifier` **once** to build the agenda: every marker, researched against the org,
   classified, and ordered by how much it constrains later work. It resolves nothing and edits
   nothing — it has no write tools.
2. It returns each marker as one of three kinds. These are not the same thing and must not share a
   queue:
   - **decision** — a real choice. Ask it, with the options and the recommendation.
   - **governed** — the tenets or standards already answer it. Ask once, as confirm-or-override.
     An override is a tenet violation and needs a recorded justification.
   - **fact** — nobody can decide it, because it is not a choice. It needs production state, a
     document that has not arrived, a job nobody has run. **Do not ask it.** A question whose
     answer is "go and find out" cannot be answered by the person reading it, and putting it in a
     decision queue wastes their attention on something no amount of thinking will settle. Give it
     an owner and a date, and record it as an action.
3. Ask the **decision** and **governed** markers **together**, in the order given — `AskUserQuestion`
   takes up to four questions per call, so batch them four at a time within the same turn rather
   than one per turn. For each: state the question so a non-author can answer it, give the options
   with honest tradeoffs, and put your recommendation first. Governed ones are confirm-or-override
   with the tenet's answer preselected.
4. As each batch comes back, write the answers into `spec.md` before asking the next batch — replace
   each marker inline, and fill the Open questions row with the resolution and today's date. A
   session that is interrupted must not lose the decisions already made.
5. Stop when no decision or governed markers remain. Report the fact items with their owners.

## When this conversation resumes with answers

The resumed message is the human answer to questions you already asked. Do not call
`spar-clarifier` again and do not rebuild or repeat the agenda.

1. Match every `Question:` / `Answer:` pair to its open marker.
2. Edit the artifact containing that marker immediately. Most are in `spec.md`; platform markers
  are in `plan.md`, and a marker in `tasks.md` stays in `tasks.md`.
3. Re-read the edited artifact and verify each answered `NEEDS CLARIFICATION[...]` marker is gone.
4. Only then ask the next unresolved question or report completion.

Acknowledging, summarizing or remembering an answer without changing the artifact is a failed
clarification turn. If the answer cannot be mapped uniquely or the write fails, say exactly that
and stop. Never claim the question is resolved while its marker remains.

## When an answer is not yours to give

Some markers need Product, Legal, a data owner, or the vendor. Say so when you ask, rather than
letting someone answer on their behalf and discovering it later. If the org has no policy at all,
record the resolution as a **local decision made in the absence of a standard**, with the condition
that supersedes it — never as conformance to a policy nobody has read.

## Output

Updated `spec.md`, a dated resolution log, and the fact-finding actions with owners.

> The pipeline does not proceed on silence, but it asks everything at once: one sitting, not one question per turn.

**Next:** **Human gate** — read `spec.md` and approve it. Then step `plan` (<feature>).
