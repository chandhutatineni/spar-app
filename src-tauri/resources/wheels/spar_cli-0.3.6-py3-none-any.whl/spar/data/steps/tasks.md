---
description: Decompose the approved plan into ordered, parallel-safe tasks.
---

# step `tasks`

Produces `tasks.md`: tasks an executor can implement without asking a question, ordered into phases with human checkpoints between them.

## Prerequisites

An approved plan.

## Usage

```
step `tasks` <feature>
```



## Steps

1. `spar-task-planner` writes phased tasks — Setup, Foundational, per-story (P1 first), Polish — each with exact files and a Given/When/Then acceptance test path.
2. It creates a task for **every applicable standards row**: Dockerfile, CI, scans, healthcheck, dashboards, per-environment manifests, runbook.
3. `[P]` is tagged only where file sets are genuinely disjoint.
4. `spar-estimator` optionally attaches advisory complexity estimates and flags mega-tasks.
5. It closes with the traceability table — `PRD | Spec item | Task(s) | Code | Test` — citing the ids the spec defined rather than ids of its own.
6. `spar-critic` reviews.

## Output

`tasks.md` with the task count, parallel-safe count and traceability table.

**Next:** step `analyze` (<feature>)
