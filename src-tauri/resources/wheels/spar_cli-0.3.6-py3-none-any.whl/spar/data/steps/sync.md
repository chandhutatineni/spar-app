---
description: Reconcile spec artifacts after someone else changed the code.
---

# step `sync`

Inbound reconciliation. Detects code changes made outside the pipeline and proposes spec amendments. **Never touches code.**

## Prerequisites

An adopted or in-progress project.

## Usage

```
step `sync` [--since <ref>]
```



## Steps

1. `spar-syncer` determines the base ref from `spar/last-sync`, or `HEAD@{1}`, and says which it used.
2. It maps changed files to owning specs and proposes a specific amendment per affected feature — you approve each individually.
3. Orphan files get three options: adopt, reverse-specify, or ignore.
4. New tenet violations are blocked or grandfathered with a recorded reason — never silently accepted.
5. It appends a `## Sync Log` entry and updates `spar/last-sync`.

## Output

Proposed amendments, an orphan report, a tenet-violation report, and a Sync Log entry.

**Next:** step `converge` (<feature>) if gaps need tasks, else ``spar status``.
