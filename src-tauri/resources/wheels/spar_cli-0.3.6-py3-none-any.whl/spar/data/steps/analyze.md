---
description: Cross-artifact drift check. Blocks the build on inconsistency.
---

# step `analyze`

Catches drift between spec, plan, data model, contracts and tasks **before** any code is written — roughly a hundred times cheaper than catching it in review.

## Prerequisites

`tasks.md` exists.

## Usage

```
step `analyze` <feature>
```



## Steps

`spar-analyzer` runs eight checks and reports each with a location:

1. Spec → tasks traceability (unmapped spec item = BLOCKING)
2. Plan → tasks alignment
3. Contradictions across artifacts (field names, types, endpoints, error shapes)
4. Residual `NEEDS CLARIFICATION` markers (BLOCKING)
5. Priority ordering — P1 must not depend on P2/P3
6. Test-coverage promises
7. Parallel-safety — no two `[P]` tasks sharing files
8. Standards coverage

## Output

Per-check PASS/BLOCKED with locations, and an overall verdict in the decision ledger (action `gate.evaluate`, name `analyze`), which `spar next` reads before allowing the build.

**Next:** If BLOCKED, fix the named artifacts. If PASS, step `build` (<feature>).
