---
description: Run the real suites, start the whole app and test it end to end like a person, and send failures back as fix tasks.
---

# step `verify`

Independently establishes whether the feature is actually done. It runs the tests itself rather than trusting the build log, then starts the whole product — backend, frontend, dependencies — and uses it like a person would. Anything that doesn't work goes back to the build as a fix task, and this step runs again once the fixes are in.

## Prerequisites

The build has completed at least one phase.

## Usage

```
step `verify` <feature>
```



## Steps

1. `spar-verifier` runs the real test suite and records the exact command and counts.
2. It builds the spec → task → code → test matrix. A row without a passing test is a FAIL.
3. Skipped and xfail tests are called out and do not count as passing.
4. It re-checks every tenet against the built code, quoting `file:line`, and re-checks BLOCKING control findings.
5. It confirms every required standards artifact actually exists in the repo.
6. **End to end, like a person:** it starts every service the product needs (dependencies, backend,
   frontend), waits until each is healthy, and for every user story performs each acceptance
   criterion through the real interface — in a real browser via the Playwright MCP tools for a UI,
   as a client for an API — watching console errors and failed requests, with a screenshot per
   criterion in `evidence/`. Then it stops everything it started.
7. Every failure becomes a fix task under `## Delivery fixes` in `tasks.md` (repro, evidence,
   criterion, acceptance) and the verdict is FAIL. The harness builds the fixes without another
   review and runs this step again — up to three rounds, then a person decides.
8. `spar-controls-reviewer` runs a final sweep.

## Output

`verification.md` with an explicit PASS or FAIL, the traceability matrix and a gap list;
`test-report.md` with all four pillars; screenshots and logs under `evidence/`; fix tasks on FAIL.

**Next:** the `approve-release` gate, then step `release` (`/spar.deliver`).
