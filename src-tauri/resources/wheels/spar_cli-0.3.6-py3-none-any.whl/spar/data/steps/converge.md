---
description: Append tasks for spec-versus-code gaps.
---

# step `converge`

Outbound reconciliation: diffs current code against the spec and appends `[CONVERGE]` tasks for what is missing.

## Prerequisites

A feature whose code and spec have diverged.

## Usage

```
step `converge` <feature>
```



## Steps

1. `spar-converger` categorises each gap: missing implementation, undocumented behaviour, contract drift, or abandoned scope.
2. It appends `[CONVERGE]`-tagged tasks in the standard format. Existing tasks are never deleted or renumbered.
3. Abandoned scope is recommended for removal from the spec rather than implementation — your call.

## Output

Updated `tasks.md` with `[CONVERGE]` tasks and a categorised gap report.

**Next:** step `build` (<feature>)
