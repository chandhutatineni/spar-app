---
description: Review changed files against real organisational control procedures.
---

# step `controls`

Reviews code against your organisation's actual control procedures, citing them. Runs per-task during build and as a final sweep in verify.

## Prerequisites

Changed code, and ideally a `role=security` connector configured.

## Usage

```
step `controls` [<feature>]
```



## Steps

1. `spar-controls-reviewer` discovers applicable controls through the gateway and records their ids.
2. It reviews authentication, authorisation, secrets, audit logging, crypto, container config, network exposure, input validation, PII and dependencies.
3. Findings are BLOCKING (cites a real control), WARNING, or INFO (no citable control — flagged for manual verification).

## Output

Findings by severity, each with a citation or an explicit "no citable control found", plus unreachable sources.

> The reviewer never fabricates a control id. An invented citation would poison trust in every real finding.

**Next:** Fix BLOCKING findings before the task is considered done.
