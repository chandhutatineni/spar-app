---
description: Onboard an existing codebase. Read-only; changes nothing.
---

# step `adopt`

Makes a brownfield codebase adoptable without changing a line of it. Drafts tenets from what the code **actually does**, not from aspiration.

## Prerequisites

An existing repository. Run this once.

## Usage

```
step `adopt` [--paths <glob>]
```



## Steps

1. `spar-adopter` scans read-only: languages, build, tests and real coverage, dependencies, error handling, observability, layering, security posture, deployment.
2. It drafts the governance trio from observed practice and compares it against org standards found through the gateway.
3. Divergences become candidate **Known Violations (Grandfathered)** — permitted in existing code, forbidden in new code.
4. It proposes feature boundaries ranked by how likely they are to be touched next.
5. `spar-reverse-specifier` documents every discovered boundary as `[LEGACY]` artifacts with `file:line` citations — or exactly the subset you named with `--paths`. A non-interactive run has nobody to ask, so it specifies all of them rather than none.

## Output

A codebase report, a drafted trio, a grandfathered-violations appendix, and ranked feature boundaries.

> Specs for rarely-touched code drift from it; each artifact says so where that applies. Use the full pipeline for every new feature from here, and re-specify as you touch them.

**Next:** step `tenets` to review the drafted trio, then the normal pipeline for your next feature.
