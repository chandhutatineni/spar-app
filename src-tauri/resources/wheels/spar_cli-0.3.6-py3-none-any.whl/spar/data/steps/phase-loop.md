---
description: The loop every SPAR phase command runs. Not a command of its own.
---

# The phase loop

Every phase command (`/spar.init`, `/spar.explore`, `/spar.design`, `/spar.build`, `/spar.deliver`,
`/spar.adopt`, `/spar.reconcile`, `/spar.sync`) runs this loop. Nothing here is decided by you or by
any agent: what comes next is code (`spar next`), whether an artifact is right is code
(`spar check`), and whether a person approved it is the ledger (`spar gate`). You dispatch what they
say, and keep going until a person is genuinely needed.

## Steps are playbooks

A **step** is a playbook in `~/.claude/spar-steps/<step>.md` (`specify`, `clarify`, `plan`, `tasks`,
`analyze`, `build`, `verify`, …). "Run step X" means: read that file and do what it says, using the
`spar-*` agents it names. A step's closing **Next:** line is for reference only; the loop below
decides what comes next.

## The loop

Repeat, at most fifteen times:

1. Run `spar next <feature> --json` with Bash (omit the feature when there is none yet).
2. If `phase` is past the one you were asked for, your phase is finished: say so in one line and stop
   — the app (or the person) starts the next phase. (In `/spar.deliver`, a `build` action for
   delivery fixes is part of delivery: keep going.)
3. Act on `action`:
   - `run` — run step `command` for the feature.
     - `tenets` / `adopt`: pass the brief (if any) so the engineering principles fit the product, plus any
       change-request note in `reason`. Draft in one pass; never interview.
     - `roadmap` / `specify` with no brief in hand: the brief is `spar/briefs/pending.md`. When the
       step succeeds, move that file to `spar/briefs/<YYYY-MM-DD>-brief.md` so it is used once.
     - `analyze`: afterwards run `spar check --feature <feature> --note-analyze-attempt`.
   - `check` — run `spar check --feature <feature> --scope <scope> --json`. No model involved.
   - `fix` — run `spar check --feature <feature> --scope <scope> --for-agent` and hand the output to the
     `owner` agent with "Fix every finding. Do not start new tasks." At most two fix rounds per
     scope; then stop and show the findings.
   - `prompt` — the brief needs the person's words. Use the brief you were given, else
     `spar/briefs/pending.md`; run step `command` with it. Only with no brief anywhere, stop and ask
     what to build.
   - `gate` — stop. In a few lines, summarise what to review (for `approve-tenets`, a short table of
     the tenets; otherwise the key decisions), name the files, and ask the person to approve it or say
     what to change. In the SPAR app they decide with the buttons under your message, so show no
     commands. Only in a plain terminal, add the decision line:
     `spar gate approve <feature> <gate>` / `spar gate request-changes <feature> <gate> --note "..."`
     (project-level gates drop the feature: `spar gate approve approve-tenets`).
   - `select` — stop and ask which of `options` to build first.
   - `setup` — the release is waiting on something only the person can provide (`reason` says what).
     If they say it's done, re-run the step's preflight; if it now passes, carry on with step
     `release`, otherwise stop and restate exactly what is still missing.
   - `blocked` — stop and print `reason`. Do not work around it.
   - `done` — stop. Offer the retrospective (step `retro`) and issue export (step `issues`).
4. Report progress briefly in the person's terms ("Drafted the spec", "Answered the open
   questions"), not as a list of commands.

## Asking the person

Whenever you need the person to decide something (open questions, platform choices, anything the
harness can't decide), ask **every** question at once in one fenced block, then stop and wait:

```spar-questions
[{"id": "auth", "question": "How do people sign in?",
  "options": [{"label": "Email and password", "detail": "simplest; no third party"},
              {"label": "Google sign-in", "detail": "fewer passwords to manage"}],
  "recommended": 0}]
```

Put your recommendation first and point `recommended` at it; add `"multi": true` when several
options can be picked. The SPAR app shows this as a form — the options, room for their own answer,
"Use all recommendations" and Submit — and sends back one line of answers. In a plain terminal, the
same block still reads fine. Never ask the same question in prose as well.

## Keep going

The only stops are: `gate`, `select`, `setup`, `blocked`, `done`, a `prompt` with no brief anywhere,
a fix round that failed twice, and reaching the end of your phase.

- Never pause to ask "shall I continue?", to announce the next step, or because a later step
  "should" wait for a review — `spar next` already knows which reviews block what.
- Run subagents in the foreground and wait for them: never pass `run_in_background` to the Agent/Task
  tool. Never end your turn while one is still working, and never let a gate be shown while a file it
  covers is still being written.
- In the SPAR app, a gate is decided with the Approve / Request changes buttons it shows under your
  message: point to them instead of printing `spar gate` commands.
- Never hand the person a step they cannot decide (a file to create, a folder to make, a command to
  type that you could run).
