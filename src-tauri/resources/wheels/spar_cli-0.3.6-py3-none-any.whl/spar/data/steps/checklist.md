---
description: Write binary quality checks for an artifact — unit tests for English.
---

# step `checklist`

Produces `checklists/<artifact>.md`: checks a reviewer can answer yes or no from the artifact alone.

## Prerequisites

The target artifact exists.

## Usage

```
step `checklist` <feature> [spec|plan|tasks]
```



## Steps

1. `spar-checklist-author` writes blocking checks for mandatory structure and advisory checks for quality.
2. It runs the checklist and fills the result table with evidence, or with what is missing.

## Output

`checklists/<artifact>.md` with a PASS or BLOCKED verdict.

**Next:** Fix blocking items, then continue the pipeline.
