---
description: Export tasks to the org issue tracker, idempotently.
---

# step `issues`

Exports the task tree as Epic → Stories → Sub-tasks. Optional stage; safe to re-run.

## Prerequisites

`tasks.md` exists and a `role=issues` connector is configured and not read-only.

## Usage

```
step `issues` <feature> [--dry-run]
```



## Steps

1. `spar-issues-exporter` checks for existing issue keys in `issues.md` and updates those instead of creating duplicates.
2. It generates each issue's description from the task and a Definition of Done from its acceptance criteria.
3. It asks you for an assignee rather than guessing.
4. It records the returned keys in `issues.md` (`| Item | Type | Key | URL |`), never in `tasks.md`: editing the approved tasks would reopen the design approval.

## Output

Created or updated issue keys, recorded in `specs/<feature>/issues.md`.

**Next:** step `build` (<feature>)
