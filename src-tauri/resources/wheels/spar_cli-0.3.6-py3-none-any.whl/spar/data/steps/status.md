---
description: Where every feature is, and what to run next.
---

# `spar status`

The oracle when you are lost. A filesystem scan — no agent, no tokens.

## Prerequisites

None.

## Usage

```
`spar status` [<feature>]
```



## Steps

1. Scans `spar/` and infers each feature's phase from which artifacts exist.
2. Reports task completion, risk tier and verification state per feature, plus a portfolio roll-up.
3. Names the single next command to run.

## Output

A per-feature table and the next command.

> Also available outside Claude Code as `spar status`, `spar metrics` and `spar dashboard`.

**Next:** Whatever it tells you.
