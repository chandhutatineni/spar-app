---
description: Post-verification retrospective proposing governance amendments.
---

# step `retro`

Closes the learning loop: turns what happened into an approvable diff against `tenets.md` and `standards.md`.

## Prerequisites

step `verify` has run.

## Usage

```
step `retro` <feature>
```



## Steps

1. `spar-retrospective` compares shipped against planned and notes checkpoints that slipped.
2. It mines `build-log.md` for recurring review findings — a category appearing three or more times is a missing tenet or standard.
3. It records honestly where the pipeline added friction.
4. It proposes amendments as a diff you accept or decline.
5. If a `role=memory` connector is configured, it offers to persist the durable lessons so the next feature starts with them.

## Output

`retro.md` with the variance analysis, recurring findings, a proposed diff, and your decision.

**Next:** step `tenets` (--amend=retro) if you accepted the amendments.
