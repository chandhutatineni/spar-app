---
description: STRIDE threat model that writes findings back into the spec.
---

# step `threat-model`

Produces `threat-model.md` — and pushes its serious findings back into the gated pipeline, which is the part that makes it more than a document.

## Prerequisites

`spar/architecture/architecture.md` is current (step `architecture`): the threat model is drawn on the architecture's
components, data flows and trust boundaries. Runs after step `architecture` and before step `tasks`.

## Usage

```
step `threat-model` <feature>
```



## Steps

1. `spar-threat-modeler` enumerates assets, trust boundaries and data flows.
2. It walks STRIDE per boundary, rating likelihood × impact, grounding control selection in real org security standards via the gateway.
3. **Every high or critical threat with no mitigation is written back into `spec.md`** as a `NEEDS CLARIFICATION[security-*]` marker or a new `NFR-S*` requirement.
4. `spar-critic` reviews.

## Output

`threat-model.md`, updated spec markers, and a count of findings written back.

> Findings that stay in a side document change nothing. This command deliberately reopens the spec.

**Next:** step `clarify` (<feature>) to resolve the new security markers.
