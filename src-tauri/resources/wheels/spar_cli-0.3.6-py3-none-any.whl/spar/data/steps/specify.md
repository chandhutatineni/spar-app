---
description: Turn a brief, BRD, PRD or ticket key into a governed spec.
---

# step `specify`

Creates `spar/specs/<NNN-slug>/spec.md`: what and why, never how.

## Prerequisites

The governance trio exists (step `tenets`).

## Usage

```
step `specify` "<brief text | path to BRD/PRD | ticket key>"
```

A ticket key is hydrated from your issue tracker through the gateway before anything is written.

## Steps

1. `spar-specifier` grounds the brief in org sources and writes the spec — user stories as vertical slices, priority tagged, with Given/When/Then criteria.
2. It completes the mandatory Non-Functional Requirements section, including all eight Security rows, and assigns a `risk_tier`.
3. Anything unknown is either a stated, numbered **assumption** (a sensible default the reviewer can
   overturn) or, for the few decisions that need a person (scope, security, personal data, money,
   legal — about eight at most), an inline `NEEDS CLARIFICATION[topic]` marker. Never a silent guess.
4. `spar-critic` reviews it adversarially before you see it.

## Output

`spec.md`, the clarification-marker count, and the assigned risk tier.

**Next:** step `clarify` (<feature>)
