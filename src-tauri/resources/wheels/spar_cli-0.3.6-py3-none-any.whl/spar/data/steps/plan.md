---
description: Research and architect the feature, with the tenets gate running twice.
---

# step `plan`

The gated heart of the pipeline. Produces `research.md`, `plan.md`, `data-model.md` and `contracts/*.md` with a hard governance gate on either side of the design.

## Prerequisites

An approved spec with no open markers.

## Usage

```
step `plan` <feature>
```



## Steps

1. **`spar-tenets-gate` (pre-research)** checks the spec against the trio. Unjustified violations BLOCK here, before effort is spent.
2. `spar-researcher` resolves technical unknowns from org sources — memory, docs, existing code, catalog, CI — before the open web. Every finding carries a source, date and confidence level.
3. `spar-architect` designs: components, interfaces, dependencies with timeout/retry/fallback, the data model with a classification per field, and contracts. It also fills the **platform table** — language, framework, datastore, cloud, orchestration, deployment tooling — but it does not choose those: each row cites governance a human already ratified, or becomes a `NEEDS CLARIFICATION[platform-*]` question with options and a recommendation.
4. **If the plan carries platform markers, stop and ask them here** — all of them in one
   ```spar-questions form (see `~/.claude/spar-steps/phase-loop.md`), each with the concrete options
   and your recommendation first. Never answer a platform row yourself: hosting, CI/CD, deployment
   tooling, language and datastore are the person's call unless a tenet or recorded decision settles
   them. When the answers come back, record each with `spar decision --subject-kind agent --action-kind platform.select
   --name platform-<row> --resource plan.md --verdict approved --explanation "<their exact words>"`
   — an agent record quoting them, never one claiming to be the person — and write it into the Platform
   table with Source `your answer (decision #N)`, N being that record's number. These outrank every other open question: every task, every Dockerfile and every manifest below inherits them, so an answer given after the decomposition costs a rewrite rather than a click. `spar next` routes back here until they are closed.
5. **`spar-tenets-gate` (post-design)** re-checks plan + data-model + contracts. Vague compliance BLOCKS. Missing required scaffolding BLOCKS.
6. `spar-critic` reviews the result.

## Output

`research.md`, `plan.md`, `data-model.md`, `contracts/*.md`, and both gate verdicts in the decision ledger.

> The gate is the point. If it blocks, the design changes — not the gate.

**Next:** **Human gate** — approve the plan. Then step `tasks` (<feature>).
