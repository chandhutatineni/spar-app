---
description: Build the organisation-context digest from the MCP gateway.
---

# step `context`

Produces `spar/context/org-map.md` — what this organisation actually runs, so later agents propose the house pattern instead of a generic one. This is the single biggest accuracy lever in SPAR.

## Prerequisites

The MCP gateway registered (`spar mcp install`) and at least one connector configured. Works without them, but will mostly report gaps.

## Usage

```
step `context` [--refresh]
```

- `--refresh` regenerates from scratch instead of updating.

## Steps

1. `spar-context-mapper` calls `org_connectors` to see which roles are reachable.
2. It searches memory first (if a `role=memory` connector exists), so prior lessons carry forward.
3. It maps the estate role by role: catalog, scm, ci/cd, docs, security, observability, db, issues.
4. It writes the digest with a citation on every row, and a **Gaps in grounding** section naming what is missing and what that costs.

## Output

`spar/context/org-map.md`, plus a ranked list of the connectors that would most improve accuracy for this project.

> Re-run this when the estate changes. A stale digest is worse than none, because agents trust it.

**Next:** step `specify` ("<brief>")
