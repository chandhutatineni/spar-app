---
description: Update the project's living architecture document — arc42 structure, Domain-Driven Design, real diagrams — for this iteration.
---

# step `architecture`

Keeps `spar/architecture/architecture.md` current. There is one architecture document per project,
not one per feature: the first iteration creates it, every later one updates it and logs the change.

## Prerequisites

This iteration's `plan.md`, `data-model.md` and `contracts/` exist, and the plan's Platform rows are
settled.

## Usage

```
step `architecture` <feature>
```

## Steps

1. `spar-architecture-writer` reads this iteration's design and the current architecture document.
2. It designs the domain first — domain vision, subdomains (core, supporting, generic), bounded
   contexts and the context map, the ubiquitous language — then the tactical design inside each
   context: aggregates and their invariants, entities, value objects, domain events, repositories,
   services, and the layered code layout.
3. It updates every arc42 section (goals, constraints, context, strategy, building blocks, runtime,
   deployment, cross-cutting concepts, decisions as ADRs, quality, risks, glossary), adds a Change
   log row and bumps the version.
4. Diagrams go in `spar/architecture/diagrams/`: context, building blocks and deployment in the
   architecture tool; the context map, one diagram per aggregate, the domain model and a sequence
   per primary scenario generated with `spar_drawio` (never hand-written draw.io XML).
5. `spar-critic` reviews it against the inputs: a context, aggregate, entity or interface in the
   plan but missing here, an invariant with no owner, a term used but not in the glossary, a
   placeholder left in.

## Output

The updated `spar/architecture/architecture.md` and its diagrams.

**Next:** step `threat-model` (on the architecture) when the feature needs one, then step `tasks`.
