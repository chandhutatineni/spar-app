---
description: Decide whether a brief is one deliverable or a sequence of MVPs, and record the plan.
---

# step `roadmap`

Creates `spar/roadmap.md`: the MVPs this gets built as, in the order they should be delivered.

An MVP here means a version of the product someone could use, not a phase of the work. If the
project stopped the day after one shipped, somebody would still be better off than before it
started. That test is what separates this from a task list.

## Prerequisites

The governance trio exists (step `tenets`).

## Usage

```
step `roadmap` "<brief text | path to a case.md | BRD/PRD path | ticket key>"
```

## Steps

1. `spar-roadmapper` reads the brief and first decides whether there is anything to split at all. A
   bug fix, a new field or an enhancement to something that already ships is one deliverable, and it
   says so.
2. If it recommends a single deliverable, record that with `spar mvp single --note "<why>"` and go
   straight on to step `specify` with the same brief — no stop. Mention it in one line; the person
   sees it again at the spec review and can split it then with `spar mvp single --withdraw`.
3. Otherwise it writes the MVP sequence — each row naming a person and what they can now do — with
   In, Out and Proves for each, and a recommended starting point.
4. `spar-critic` reviews the split, in particular whether any row is a phase pretending to be a
   release.
5. **Stop and let the person choose which MVP to build first.** Say which you recommend and why in
   one or two lines, then stop: `spar next` returns `select` with every unshipped MVP, and the SPAR
   app shows them as buttons that record the choice (`spar mvp select <id>`). Do not ask the question
   in prose as well, and do not pick for them because the order looks obvious — the person knows
   about customer commitments and contract dates that are not written down anywhere you can read.
   If they answer in the chat instead ("go with M1", "use the order you proposed"), record it
   yourself with `spar mvp select <id> --note "<their words>"` and carry on.
6. step `specify` then writes a spec for the selected MVP alone, scoped to its In list.

## Output

`roadmap.md`, the MVP count, and the selected MVP.

**Next:** step `specify` for the selected MVP (or the single deliverable), or `spar mvp select <id>` to choose a different one.
