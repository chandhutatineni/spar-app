---
description: Design — plan (asks where to deploy and which CI/CD), a full architecture document with diagrams, a threat model on it, tasks and a cross-check; one review.
---

# /spar.design

The Design phase: from an approved spec to an approved plan and task list.

## Usage

```
/spar.design [<feature>] [feedback]
```

## What it does

Runs the phase loop (`~/.claude/spar-steps/phase-loop.md`) for phase `design`:

1. `plan` — research and architecture (`plan.md`, `data-model.md`, `contracts/`), with the tenets gate
   run before and after. Its Platform table always asks the person, together and with a
   recommendation for each: **where to deploy** (local with Docker, Render, Fly.io, Vercel, AWS, Azure,
   GCP, …) with the concrete services each would use, **which CI/CD** (GitHub Actions, GitLab CI,
   Jenkins, Spinnaker, Azure DevOps, …), and the **deployment tooling** (Terraform by default for a
   cloud) — unless the engineering principles already settle a row.
2. Once `plan.md` exists and before `tasks`, two steps `spar next` doesn't track, in this order:
   - step `architecture` first, once the plan's Platform rows are settled (the deployment target and CI/CD
     are the person's choice, asked with recommendations in the `plan` step) — it updates the project's
     living `spar/architecture/architecture.md` (arc42, Domain-Driven Design, with a change log per
     iteration) — the complete technical architecture
     document (context, decisions, components, flows, data, interfaces, deployment, security,
     performance, reliability, observability, stack, risks, traceability), with its diagrams in the
     project's diagram tools embedded in it;
   - then step `threat-model`, on that architecture — its components, data flows, trust boundaries
     and interfaces — when the feature handles personal data, authentication, money or external
     input and there is no `threat-model.md` yet. High-severity findings go back into the spec and
     into the architecture's Security section.
3. `tasks` — ordered, parallel-safe tasks with a checkpoint between phases.
4. `analyze` and the deterministic checks — spec, plan and tasks must agree; findings go back to
   their owner (two rounds at most).
5. Stops at the **approve-plan** gate.

**Next:** `/spar.build`.
