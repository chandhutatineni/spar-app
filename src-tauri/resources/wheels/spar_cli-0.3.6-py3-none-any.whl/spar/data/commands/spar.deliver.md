---
description: Deliver — with your OK, push to GitHub, create the infrastructure you chose, deploy and check the live app.
---

# /spar.deliver

The Deliver phase.

## Usage

```
/spar.deliver [<feature>]
```

## What it does

Testing already happened in Develop. Deliver ships what passed:

1. The **approve-release** gate: the person's OK to push and deploy. Nothing leaves the machine
   without it.
2. Step `release`:
   - **Preflight.** Checks GitHub access, the tools (Terraform, the cloud CLI), the cloud login and
     the app's secrets. Anything missing stops the step with exact instructions ("run `az login` in
     the SPAR terminal, then press Continue"); after the person sets it up, it checks again and goes on.
   - **Push to GitHub** (creating the repository if needed), with the CI/CD pipeline committed.
   - **Provision** the infrastructure from `infra/` — Terraform plan, then apply; it asks first if
     anything would be destroyed or replaced.
   - **Deploy** the services in order (data, backend, frontend), directly or through the pipeline.
   - **Smoke-test the live app** like a person and record the URL, the resources and how to roll back.
3. Stops at `done` with the live URL, and offers the retrospective (step `retro`) and issue export
   (step `issues`).
