---
description: Fix a bug — reproduce it, prove it with a failing test, fix it, guard against regression; one review.
---

# /spar.fix

A small, governed path for a defect. No roadmap, no plan document.

## Usage

```
/spar.fix "<what is broken, how to reproduce it, or an issue key>"
```

## What it does

1. **Reproduce.** Find the smallest input that shows the bug. If it cannot be reproduced, stop and
   say what you tried.
2. **Failing test first.** Write a test that fails for exactly this reason, next to the code's
   existing tests. Run it; it must fail.
3. **Fix** the cause, not the symptom, within the engineering principles (`spar/tenets.md`,
   `spar/standards.md`). Keep the change as small as it can be.
4. **Prove it.** The new test passes, the rest of the suite still passes, and `spar verify-guard`
   shows the test fails without the fix.
5. **Record** `spar/fixes/<NNN-slug>.md` from what happened: symptom, root cause, the change, the test
   (`path::name`), and anything left for later. Commit nothing.
6. Stop at the **approve-fix** gate — one review of the diff and the record:
   `spar gate approve approve-fix <NNN-slug>` or
   `spar gate request-changes approve-fix <NNN-slug> --note "..."`.

Changes requested: apply the note, re-run step 4, update the record, and stop at the gate again.
