---
description: Build — implement the tasks, tests first, with a controls review on each; stops at each checkpoint.
---

# /spar.build

The Develop phase.

## Usage

```
/spar.build [<feature>] [feedback]
```

## What it does

Runs the phase loop (`~/.claude/spar-steps/phase-loop.md`) for phase `build` — the whole of Develop,
including testing:

1. Step `build` — the next phase of tasks, in parallel where their files are disjoint. Each task:
   tests first, then code, then the per-change review (step `controls` when org controls apply).
   The tasks include the **infrastructure as code** for the deployment target chosen in Design
   (Terraform under `infra/`, or `render.yaml`, or `docker-compose.yml` for local) and the
   **CI/CD pipeline** for the chosen system (`.github/workflows/`, `Jenkinsfile`, a Spinnaker
   pipeline) — written and validated (`terraform fmt -check`, `terraform validate`), never applied.
2. Deterministic checks after each phase; findings go back to the task executor (two rounds at most).
3. Stops at each **checkpoint** gate (a low-risk feature is reviewed once, at the end).
4. When every task is done, step `verify` — the unit and integration suites, then the whole product
   started locally and **tested end to end like a person** (a real browser for the UI), with
   screenshots. Every failure becomes a `## Delivery fixes` task that goes straight back to step
   `build`, then the end-to-end test runs again — up to three rounds, then a person decides.

When the project asked for UI first, the first phase builds the interface with realistic mock data
and stops for a UI review before integrating real services.

Stay in this command across the fix rounds: `build` and `verify` actions are both part of Develop.

**Next:** `/spar.deliver` once it passes end to end.
