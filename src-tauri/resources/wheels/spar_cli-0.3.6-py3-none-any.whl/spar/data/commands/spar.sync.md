---
description: Update the specs after someone changed the code outside SPAR; one review.
---

# /spar.sync

Inbound reconciliation: the code changed (a hotfix, another tool, a teammate), and the spec
artifacts should say what the code now does.

## Usage

```
/spar.sync [<feature>] ["<what changed, or a commit range>"]
```

## What it does

1. Step `sync` — reads the change and updates `spec.md`, `plan.md` and `tasks.md` to match.
   It touches spec artifacts only, never code.
2. The deterministic checks on what changed.
3. A changed spec or plan reopens its gate (**approve-spec** or **approve-plan**): stop there for the
   person to confirm the specs now describe reality.
