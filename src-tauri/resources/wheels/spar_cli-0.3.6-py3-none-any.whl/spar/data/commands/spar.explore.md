---
description: Discover — turn the brief into a roadmap and a spec, answering open questions in one sitting; one review.
---

# /spar.explore

The Discover phase: from your words to an approved spec.

## Usage

```
/spar.explore ["<brief>" | <feature>] [feedback]
```

No argument: the brief saved by `/spar.init` (`spar/briefs/pending.md`), or the latest feature.

## What it does

Runs the phase loop (`~/.claude/spar-steps/phase-loop.md`) for phase `explore`. The steps it
dispatches, as `spar next` names them:

1. `roadmap` — one deliverable or a sequence of MVPs? A single deliverable is recorded and it goes
   straight on; several MVPs stop once for you to pick the first.
2. `specify` — writes `spec.md` for that deliverable.
3. `clarify` — asks every open question together, each with a recommendation (answer "use your
   recommendations" to take them all).
4. Stops at the **approve-spec** gate.

Feedback (from "Request changes") goes to the specifier, and the spec is revised before the gate
reopens.

**Next:** `/spar.design`.
