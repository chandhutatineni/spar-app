---
description: Bring an existing codebase into SPAR — map it, draft engineering principles from what it does, one review.
---

# /spar.adopt

`/spar.init` for a project that already has code.

## Usage

```
/spar.adopt ["<what you want to build next>"]
```

## What it does

1. `spar init` (with the brief, if given) — creates `spar/`.
2. Step `adopt` — a read-only scan: stack, tests, error handling, security, deployment; feature
   boundaries proposed for reverse-specification. Changes no code.
3. Step `tenets` — the engineering principles drafted from observed practice (with a Known Violations appendix),
   every item DRAFT.
4. The phase loop (`~/.claude/spar-steps/phase-loop.md`) for phase `init`, stopping at the
   **approve-tenets** gate.

Afterwards `/spar.explore` for new work, `/spar.reconcile` to line specs up with the code, or
reverse-specify a feature with the `spar-reverse-specifier` agent.
