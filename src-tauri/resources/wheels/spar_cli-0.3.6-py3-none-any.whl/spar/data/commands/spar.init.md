---
description: Start a new project — set up spar/, draft the engineering principles and keep your brief; one review.
---

# /spar.init

Sets a new project up in one go and stops once, for you to approve the engineering principles.

## Usage

```
/spar.init ["<what you want to build>"] [--preset=org]
```

## What it does

1. `spar init "<brief>"` — creates `spar/` (specs, briefs, ledger, gitignore entries) and saves the
   brief to `spar/briefs/pending.md`, so it is never asked for twice.
2. Step `tenets` — drafts `tenets.md`, `standards.md` and `references.md` in one pass from the brief,
   the repo's docs and org sources (`--preset=org` starts from the enterprise baseline). Every item is
   marked DRAFT. No interview.
3. Step `context` — if the org gateway is connected, builds the organisation-context digest.
4. Then the phase loop (`~/.claude/spar-steps/phase-loop.md`) for phase `init`, which stops at the
   **approve-tenets** gate with a short table of the tenets.

Only when all three files are complete does the gate appear.

## After you approve

`spar gate approve approve-tenets` clears the DRAFT markers. Then `/spar.explore` turns the saved
brief into the roadmap and the spec.

An existing codebase? Use `/spar.adopt` instead.
