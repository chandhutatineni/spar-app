---
description: Line the specs up with the code — find the gaps and add the tasks that close them; one review.
---

# /spar.reconcile

For brownfield work, or after the code has moved on from what the spec says.

## Usage

```
/spar.reconcile [<feature>]
```

## What it does

1. Step `converge` — compares the spec and plan with the code and appends `[CONVERGE]` tasks for every
   real gap (behaviour the spec promises that the code lacks, and code behaviour the spec never
   mentions).
2. The deterministic checks on the updated `tasks.md`.
3. Changing `tasks.md` reopens the **approve-plan** gate: stop there so the person approves the new
   tasks. After approval, `/spar.build` builds them.
