# Verification — {{FEATURE_TITLE}}

<!-- guidance: /spar.deliver writes this AFTER actually running the test suite. Do not populate it
from build-log.md: the whole point of this artifact is that it independently re-checks reality.
Skipped and expected-fail tests do not count as passing. -->

**Feature:** {{NNN-slug}} · **Date:** {{DATE}} · **Verdict:** {{PASS | FAIL}}

## Test execution

- **Command run.** `{{exact command}}`
- **Result.** {{N}} tests run, {{N}} passed, {{N}} failed, {{N}} skipped, {{N}} xfail
- **Coverage.** {{N}}% against a threshold of {{N}}%

<!-- guidance: the phrase "N tests run" is parsed by `spar metrics`; keep the wording. -->

## Traceability matrix

<!-- guidance: MANDATORY, and the whole chain: PRD requirement -> spec item -> task -> code ->
passing test. A row without a passing test is a FAIL, whatever the build log claims.

Copy the rows from tasks.md rather than re-deriving them, and add the Result. Re-deriving is how
a row quietly changes meaning between planning and verification. -->

| PRD | Spec item | Task(s) | Code | Test | Result |
| --- | --- | --- | --- | --- | --- |
| FR-1 | US1-AC1 | {{T005}} | `{{src/x.py:handle}}` | `{{tests/test_x.py::test_ac1}}` | {{pass}} |
| NFR-1 | NFR-S1 | {{T003}} | `{{src/auth.py:require_user}}` | `{{tests/test_auth.py::test_rejects_anonymous}}` | {{pass}} |

## Guard verification

<!-- guidance: For each regression fix, run `spar verify-guard` after the fix and guard are
committed together. VERIFIED means the guard failed when SPAR restored the named production paths
from HEAD^. DECORATION and INCONCLUSIVE require a FAIL verdict. If this was not a regression fix,
keep one explicit not-applicable row. A worktree protects the checkout; it is not a sandbox. -->

| Guard command | Reverted production path(s) | Outcome | Evidence |
| --- | --- | --- | --- |
| {{test command}} | {{src/x.py}} | {{VERIFIED / DECORATION / INCONCLUSIVE / not applicable}} | {{exit code or reason}} |

## Unaccounted

<!-- guidance: MANDATORY, and it may be empty — but it must be present and explicit, because an
absent section reads as "nothing was missed" whether or not anyone looked.

Both directions matter and they fail differently. A requirement with no test is work believed done
that nothing proves. A test or code path no requirement asked for is scope nobody agreed to, and
is where unreviewed behaviour enters a system that is otherwise governed. -->

| Kind | Id | What is missing |
| --- | --- | --- |
| Requirement with no spec item | {{FR-7}} | {{never carried into the spec}} |
| Spec item with no task | {{US2-AC3}} | {{planned, never broken down}} |
| Task with no requirement | {{T014}} | {{built, nothing asked for it}} |
| Code with no test | {{src/y.py:sync}} | {{written, unproven}} |

## Tenets re-check

| Tenet | Compliant in built code | Evidence |
| --- | --- | --- |
| T-001 | {{yes/no}} | {{file:line or test name}} |

## Controls re-check

| Control | Severity | Status | Evidence |
| --- | --- | --- | --- |
| {{}} | {{BLOCKING}} | {{met / not met}} | {{citation from the security connector}} |

## Gaps

| Gap | Severity | Consequence | Recommendation |
| --- | --- | --- | --- |
| {{}} | {{}} | {{}} | {{}} |

## Verdict

**{{PASS | FAIL}}** — {{one paragraph: what is provably done, and what is not.}}
