# Threat Model — {{FEATURE_TITLE}}

<!-- guidance: STRIDE per trust boundary. The point of this artifact is NOT to be a document — it is
to push findings back into the gated pipeline. Every high-severity threat without a mitigation MUST
be written into spec.md as a NEEDS CLARIFICATION[security-*] marker or an NFR-S requirement so it
re-enters clarify -> plan -> tasks. A threat model that only lives here has failed. -->

**Feature:** {{NNN-slug}} · **Date:** {{DATE}} · **Inputs:** spec.md, plan.md, data-model.md, contracts/

## Assets

| Asset | Classification | Why an attacker wants it |
| --- | --- | --- |
| {{}} | {{confidential}} | {{}} |

## Trust boundaries

| # | Boundary | From | To | Authenticated how |
| --- | --- | --- | --- | --- |
| B-1 | {{internet -> API}} | {{untrusted client}} | {{service}} | {{}} |
| B-2 | {{service -> datastore}} | {{service identity}} | {{data}} | {{}} |

## Data flows

| Flow | Data | Classification | Boundary | Protection in transit |
| --- | --- | --- | --- | --- |
| {{}} | {{}} | {{}} | {{B-1}} | {{}} |

## STRIDE analysis

<!-- guidance: one table per boundary. Do not skip categories — write "no credible threat" and why. -->

### B-1 · {{boundary name}}

| Category | Threat | Asset | Likelihood | Impact | Severity | Existing mitigation | Proposed control |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Spoofing | {{}} | {{}} | {{low/med/high}} | {{low/med/high}} | {{low/med/high/critical}} | {{}} | {{}} |
| Tampering | {{}} | | | | | | |
| Repudiation | {{}} | | | | | | |
| Information disclosure | {{}} | | | | | | |
| Denial of service | {{}} | | | | | | |
| Elevation of privilege | {{}} | | | | | | |

## Findings written back into the spec

<!-- guidance: MANDATORY for every high or critical threat with no existing mitigation. Name the
exact marker or requirement id added to spec.md. This is the row an auditor checks. -->

| Threat | Severity | Written back as | Location in spec.md |
| --- | --- | --- | --- |
| {{}} | {{high}} | {{NEEDS CLARIFICATION[security-authz] | NFR-S9}} | {{section}} |

## Accepted risks

| Threat | Severity | Why accepted | Accepted by | Date |
| --- | --- | --- | --- | --- |
| {{}} | {{}} | {{}} | {{}} | {{}} |

## Sources consulted

| Source | Connector | Retrieved | Used for |
| --- | --- | --- | --- |
| {{org secure coding standard}} | {{security}} | {{DATE}} | {{control selection}} |
