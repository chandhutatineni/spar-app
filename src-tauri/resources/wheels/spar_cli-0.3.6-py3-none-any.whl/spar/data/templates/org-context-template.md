# Organisation Context — {{PROJECT}}

<!-- guidance: Built by /spar.init from the MCP gateway. This is the "what does this organisation
actually run" digest every later agent reads first. It is a map, not a copy: link and cite, never
paste large documents. Regenerate it when stale rather than editing by hand. -->

**Generated:** {{DATE}} · **Connectors used:** {{list}} · **Regenerate:** `/spar.init`

## Summary

{{Five to eight sentences an engineer new to this organisation could read to understand the
landscape: what the platform is, how services are built and shipped, where the standards live.}}

## Systems of record

| Role | System | Connector | Authoritative for |
| --- | --- | --- | --- |
| docs | {{}} | {{}} | {{}} |
| issues | {{}} | {{}} | {{}} |
| scm | {{}} | {{}} | {{}} |
| ci | {{}} | {{}} | {{}} |
| cd | {{}} | {{}} | {{}} |
| catalog | {{}} | {{}} | {{}} |
| security | {{}} | {{}} | {{}} |
| observability | {{}} | {{}} | {{}} |

## Technology baseline

<!-- guidance: from the scm and catalog connectors. What the org already uses, so agents propose the
house pattern instead of a novel one. Cite the evidence. -->

| Layer | Predominant choice | Evidence | Notes |
| --- | --- | --- | --- |
| Languages | {{}} | {{repo count / catalog query}} | {{}} |
| Frameworks | {{}} | {{}} | {{}} |
| Datastores | {{}} | {{}} | {{}} |
| Messaging | {{}} | {{}} | {{}} |
| Deployment | {{}} | {{}} | {{}} |
| CI / CD | {{}} | {{}} | {{}} |
| Observability | {{}} | {{}} | {{}} |
| Identity | {{}} | {{}} | {{}} |

## Delivery pipeline reality

| Stage | What actually runs | Blocking | Source |
| --- | --- | --- | --- |
| {{build}} | {{}} | {{yes}} | {{ci connector}} |
| {{scan}} | {{}} | {{}} | {{}} |
| {{change approval}} | {{}} | {{}} | {{}} |
| {{deploy}} | {{}} | {{}} | {{}} |

## Standards and controls that apply

| Standard | Where it lives | Enforced by | Citation |
| --- | --- | --- | --- |
| {{}} | {{}} | {{gate / review / honour system}} | {{connector + id + date}} |

## Adjacent services and owners

| Service | Owner | Relevance to this project |
| --- | --- | --- |
| {{}} | {{}} | {{integrate rather than duplicate?}} |

## Data landscape

| Dataset / schema | Classification | Owner | Connector |
| --- | --- | --- | --- |
| {{}} | {{}} | {{}} | {{db / catalog}} |

## Prior lessons from memory

<!-- guidance: if a memory connector is configured, what did previous SPAR runs learn about this
codebase and org? This is how the pipeline compounds instead of restarting each feature. -->

| Lesson | Source | Still true? |
| --- | --- | --- |
| {{}} | {{memory connector}} | {{}} |

## Gaps in grounding

<!-- guidance: MANDATORY, and the most valuable section. Every role with no connector, every source
that could not be reached. Agents must declare these gaps in artifacts rather than filling them with
plausible text. -->

| Missing | Consequence for design | Suggested fix |
| --- | --- | --- |
| {{no security connector}} | {{controls reviewer cannot cite real controls; findings degrade to INFO}} | {{configure a security-role connector}} |
