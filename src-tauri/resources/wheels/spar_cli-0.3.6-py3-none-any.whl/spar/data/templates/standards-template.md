# Required Scaffolding Standards — {{PROJECT}}

<!-- guidance: This file lists the artifacts every service must ship to be called complete.
The task planner MUST create a task for each applicable row. The tenets gate BLOCKS if any
required artifact has no planned task. Keep it to things you can check for mechanically. -->

**Version:** {{VERSION}} · **Applies to:** {{scope, e.g. all backend services}}

| # | Required artifact | Applies when | Verified by | Blocking |
| --- | --- | --- | --- | --- |
| S-00 | Code follows the language's conventional project layout (see Project layout); nothing but configuration in the root | always | plan.md Project structure + controls review | yes |
| S-DDD | Code organised by bounded context, with DDD layers inside each (domain, application, infrastructure, interfaces); domain code has no framework or infrastructure imports; aggregates enforce their invariants | always | plan.md Domain design + controls review | yes |
| S-IAC | Infrastructure as code for every environment of the chosen target (infra/, Terraform unless the plan's Platform table says otherwise), validated in CI, applied only on release | deployed | terraform validate in CI | yes |
| S-01 | {{Dockerfile with non-root user and pinned base}} | {{service is containerised}} | {{CI lint stage}} | yes |
| S-02 | {{CI pipeline definition}} | always | {{presence + green run}} | yes |
| S-03 | {{Healthcheck endpoint}} | {{service serves traffic}} | {{integration test}} | yes |
| S-04 | {{Unit tests with coverage threshold}} | always | {{coverage gate}} | yes |
| S-05 | {{Integration tests against real dependencies}} | {{service has dependencies}} | {{CI stage}} | yes |
| S-06 | {{Dependency + container vulnerability scan}} | always | {{scan gate}} | yes |
| S-07 | {{Secrets sourced from the platform secret store}} | always | {{controls review}} | yes |
| S-08 | {{Structured logging with correlation ids}} | always | {{controls review}} | no |
| S-09 | {{Metrics + dashboard + alert}} | {{service serves traffic}} | {{observability review}} | no |
| S-10 | {{Deployment manifests per environment}} | {{service is deployed}} | {{GitOps sync}} | yes |

## Project layout

Code lives in the conventional structure for its language and framework, never loose in the
repository root. The root holds only configuration, the README, licence, CI and container files, and
the top-level folders below. The plan names the exact tree (plan.md → Project structure) and every
task's **Files.** use those paths.

| Stack | Layout |
| --- | --- |
| Domain-Driven layout (any stack) | per bounded context: `<context>/domain/` (aggregates, entities, value objects, events, repository interfaces), `<context>/application/` (use cases), `<context>/infrastructure/` (persistence, adapters), `<context>/interfaces/` (HTTP, UI) — placed inside the stack's source folder, e.g. `backend/src/hiring/domain/` |
| Full-stack app | `frontend/` (the UI app), `backend/` (the API/service), `shared/` (types or schemas both use), `infra/` (deployment), `docs/`, `e2e/` (end-to-end tests) |
| Web frontend (React, Vue, Svelte, plain JS) | `src/` (components/, pages or routes/, lib/, styles/), `public/` for static assets, `tests/` or tests beside the code, `index.html` only where the tool expects it |
| Node / TypeScript service | `src/` (routes or controllers/, services/, models/, lib/, `index.ts`), `tests/`, `package.json` at the service root |
| Python | `src/<package>/` (package code, `__main__.py` for a CLI), `tests/`, `pyproject.toml` |
| Go | `cmd/<app>/main.go`, `internal/` (private packages), `pkg/` (public packages), `go.mod` |
| Java / Kotlin | Maven or Gradle layout: `src/main/java` (or `kotlin`), `src/main/resources`, `src/test/java` |
| Rust | `src/` (`main.rs` / `lib.rs`), `tests/`, `benches/`, a Cargo workspace for several crates |
| Swift | SwiftPM: `Sources/<Target>/`, `Tests/<Target>Tests/`, `Package.swift` |
| .NET | `src/<Project>/`, `tests/<Project>.Tests/`, a `.sln` at the root |

## Environment matrix

<!-- guidance: name every environment a change must be expressible in. Missing overlays are a
classic late-discovered blocker. -->

| Environment | Required | Notes |
| --- | --- | --- |
| {{dev}} | yes | {{}} |
| {{test}} | yes | {{}} |
| {{prod}} | yes | {{}} |
| {{prod-dr}} | {{yes/no}} | {{}} |

## Language / stack tooling

| Stack | Formatter | Linter | Type checker | Test runner |
| --- | --- | --- | --- | --- |
| {{python}} | {{}} | {{}} | {{}} | {{}} |
