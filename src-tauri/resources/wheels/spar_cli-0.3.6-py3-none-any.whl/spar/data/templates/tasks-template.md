# Tasks — {{FEATURE_TITLE}}

<!-- guidance: STRICT FORMAT. Each task is `T### [P] [US#]` where [P] means parallel-safe
(touches files no other concurrently-runnable task touches) and [US#] is the owning user story.
Phase order: Setup -> Foundational -> per-story -> Polish, with a Checkpoint between phases.
A task an executor cannot complete without asking a question is under-specified.

Every task carries the fields an issue tracker needs, so `the issues step (offered by /spar.deliver)` can export it
without a human rewriting it first: the heading is the summary, **What**/**Context** are the
description, **Definition of done** is the acceptance checklist, and **Type**/**Estimate**/
**Labels** map to tracker fields directly. Do not drop a field because it seems obvious —
an empty field is a question the exporter has to ask a person later. -->

**Feature:** {{NNN-slug}} · **Date:** {{DATE}} · **Tasks:** {{N}} · **Parallel-safe:** {{N}}

## Phase 1 · Setup

### T001 [P] [US0] {{Task title — reads as an issue summary, imperative, under 80 chars}}

- **What.** {{one sentence: the change, stated as an outcome}}
- **Context.** {{why, and which plan section it implements}}
- **Type.** {{feature | chore | spike | bugfix}}
- **Implementation.**
  1. {{concrete step}}
  2. {{concrete step}}
- **Files.** `{{exact/path/one.py}}`, `{{exact/path/two.py}}`
- **Definition of done.**
  - [ ] {{observable condition a reviewer can check without reading the diff}}
  - [ ] {{the test named below passes}}
  - [ ] {{docs / config / migration updated, or "n/a"}}
- **Acceptance.** Given {{}} when {{}} then {{}} — `{{tests/test_x.py::test_name}}`
- **Estimate.** {{XS | S | M | L}} — {{one clause on what drives the size}}
- **Depends on.** {{none | T00N}}
- **Labels.** {{comma-separated, e.g. backend, security}}
- **Notes.** {{standards row this satisfies, e.g. S-02}}

- [ ] T001

<!-- guidance: repeat. Keep the checkbox list at the end of each phase so completion is countable
by `spar metrics`. -->

**Checkpoint 1.** {{What a human should verify before the next phase begins.}}

## Phase 2 · Foundational

<!-- guidance: work every story depends on. Nothing here may be [P] with a story task that needs it.
When plan.md's Presentation section applies, the design tokens and the base stylesheet belong here
and nowhere else: a screen built before them invents its own palette, and the second palette never
gets removed. -->

- [ ] T00N …

**Checkpoint 2.** {{}}

## Phase 3 · US1 — {{title}} (P1)

- [ ] T0NN …

**Checkpoint 3.** {{US1 is independently demonstrable here.}}

## Phase 4 · US2 — {{title}} (P2)

- [ ] T0NN …

## Phase 5 · Polish

<!-- guidance: docs, dashboards, alerts, runbook. Frequently dropped; keep it as real tasks. -->

- [ ] T0NN …

## Traceability

<!-- guidance: MANDATORY, and the spine of the whole method. One row per spec item, carrying
the chain end to end: the PRD requirement it came from, the spec item, the tasks that build
it, where it lives in the code, and the test that proves it.

/spar.design BLOCKS the build if a spec item has no task; /spar.deliver re-checks the whole
row and reports both kinds of orphan — a requirement nothing implements, and a task no
requirement asked for.

`Code` is filled in during the build, not now: at planning time it is a prediction. Leave it
`—` and let /spar.build write what it actually touched, as `path:symbol`. Implementations move,
so a line number is worthless a week later where a function name survives a refactor. -->

| PRD | Spec item | Task(s) | Code | Test |
| --- | --- | --- | --- | --- |
| FR-1 | US1-AC1 | {{T005, T006}} | {{—}} | `{{tests/test_us1.py::test_ac1}}` |
| NFR-1 | NFR-S1 | {{T003}} | {{—}} | `{{tests/test_auth.py::test_rejects_anonymous}}` |
| — | S-01 | {{T001}} | {{—}} | `{{ci lint stage}}` |
