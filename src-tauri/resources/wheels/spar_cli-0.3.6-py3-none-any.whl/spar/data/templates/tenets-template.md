# Engineering Tenets — {{PROJECT}}

<!-- guidance: Tenets are commitments, not aspirations. Each must be specific enough that a
reviewer can say "this plan violates T-004" and be objectively right. If a tenet cannot BLOCK
anything, it is a value statement, not a tenet — delete it. -->

**Version:** {{VERSION}} · **Last amended:** {{DATE}} · **Amendments require:** {{APPROVER_ROLE}}

## T-001 · {{TENET_TITLE}}

- **Stance.** {{The commitment, stated as an imperative. e.g. "Every service exposes /healthz returning 200 only when its dependencies are reachable."}}
- **Why.** {{The failure this prevents. Reference a real incident class if you have one.}}
- **How to apply.** {{What a plan must contain to comply, and what a violation looks like.}}

<!-- guidance: repeat T-002 … T-0NN. Ten to fifteen tenets is a healthy ceiling; beyond that
they stop being read. -->

## Known Violations (Grandfathered)

<!-- guidance: /spar.adopt fills this for brownfield repos. A grandfathered violation is
explicitly permitted in existing code and forbidden in new code. Empty is fine for greenfield. -->

| Location | Tenet | Why grandfathered | Planned remediation |
| --- | --- | --- | --- |
| {{path}} | {{T-00N}} | {{reason}} | {{ticket or "none"}} |

## Amendment log

| Version | Date | Change | Source |
| --- | --- | --- | --- |
| {{VERSION}} | {{DATE}} | {{what changed}} | {{the retro step (offered by /spar.deliver) or manual}} |
