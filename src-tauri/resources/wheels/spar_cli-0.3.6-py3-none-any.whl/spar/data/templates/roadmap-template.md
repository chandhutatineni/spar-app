# Roadmap — {{PROJECT}}

<!-- guidance: The order in which this gets delivered, and nothing else. Not a design, not a
schedule, not a task list. Each row is one MVP: a version of the product that could be put in
front of a real user and would do something useful for them, on its own, if everything after it
were cancelled that afternoon.

That last clause is the whole test. "Set up the database" is not an MVP, because cancelling
everything after it leaves a database and no user. "An operator can export one warehouse's SKUs
by hand" is an MVP, because someone can do something they could not do yesterday. If a row's
Delivers cell does not name a person and something they can now do, it is a phase of work wearing
an MVP's clothes, and it belongs inside a spec rather than on this page.

You propose this. You do not choose it. Which MVP gets built next is a human's call and is
recorded with `spar mvp select`. -->

**Created:** {{DATE}} · **Source:** {{brief path / BRD / PRD}}

## MVPs

<!-- guidance: In delivery order, which is not the same as dependency order — dependencies say
what is possible, this table says what is worth having first. Depends on names earlier MVP ids or
`—`; a row may only depend on rows above it. Status is `planned` or `shipped`, and nothing else:
which one is selected lives in the decision ledger, not here, so that a table nobody re-read
cannot disagree with what a person actually chose. -->

| MVP | Name | Delivers | Depends on | Status |
| --- | --- | --- | --- | --- |
| M1 | {{short name}} | {{who can now do what, in one sentence}} | — | planned |
| M2 | {{}} | {{}} | {{M1 / —}} | planned |

## M1 · {{short name}}

**Delivers.** {{One sentence, in the user's language, describing what someone can do at the end of
this that they could not do at the start. No component names.}}

**In.** {{The smallest set of capabilities that makes the sentence above true.}}

**Out.** {{What a reasonable person would expect here and will not get yet, and which later MVP
covers it. This is where scope creep is stopped.}}

**Proves.** {{What shipping this teaches that no amount of planning would. If the honest answer is
"nothing, it is just the first chunk", the split is wrong — merge it with the next one.}}

## M2 · {{short name}}

**Delivers.** {{}}

**In.** {{}}

**Out.** {{}}

**Proves.** {{}}
