# Authoritative References — {{PROJECT}}

<!-- guidance: Agents consult these BEFORE the open web. Reference systems by ROLE so the same
prompts work in any organisation; `spar mcp install` wires roles to real connectors. If a role
has no connector, agents must say "no internal source available" rather than guess. -->

**Version:** {{VERSION}} · Generated from `spar/org-registry.yaml` by `spar mcp install`

## Connector roles available

| Role | Connector | What to use it for |
| --- | --- | --- |
| docs | {{connector id or "none"}} | Architecture standards, runbooks, ADRs, platform docs |
| issues | {{}} | Ticket hydration and task export |
| scm | {{}} | How the org already implements this pattern; existing interfaces |
| ci | {{}} | The real build gates a plan must satisfy |
| db | {{}} | Schema introspection for data-model design (schema-first) |
| catalog | {{}} | Service ownership, dependencies, lifecycle |
| security | {{}} | Control procedures the controls reviewer cites |
| observability | {{}} | The monitoring baseline new services must match |

## Named documents

| Ref | Title | Where | Use it for |
| --- | --- | --- | --- |
| R-01 | {{Platform architecture standard}} | {{docs connector, space/page}} | {{}} |
| R-02 | {{Secure coding standard}} | {{security connector}} | {{}} |

## Paste-back sources

<!-- guidance: For docs behind browser SSO that an agent cannot authenticate to. The agent
formulates a specific query, you run it logged in, you paste the excerpt, the agent cites the
excerpt. Never let an agent claim what an unreachable doc says. -->

| Source | Why unreachable | Query to run |
| --- | --- | --- |
| {{}} | {{browser SSO only}} | {{}} |

## Rules

1. Internal sources outrank the open web for anything about how *this* organisation builds.
2. Every design decision cites its source: connector, document id, retrieved date.
3. An assistant's synthesis is a lead, not a citation. Confirm load-bearing claims in a docs source.
4. No source found is a finding to write down, not a gap to fill with plausible text.
