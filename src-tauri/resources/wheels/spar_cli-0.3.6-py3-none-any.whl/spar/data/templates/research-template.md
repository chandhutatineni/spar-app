# Research — {{FEATURE_TITLE}}

<!-- guidance: Phase 0 of /spar.design. Purpose: eliminate unknowns BEFORE architecture. Prefer org
sources over the open web; cite everything. An uncited claim about internal systems is a defect. -->

**Feature:** {{NNN-slug}} · **Date:** {{DATE}}

## Unknowns entering this phase

| # | Unknown | Why it blocks design |
| --- | --- | --- |
| U-1 | {{}} | {{}} |

## Findings

### U-1 · {{The unknown, restated}}

- **What we found.** {{}}
- **Source.** {{connector}} · {{document id or path}} · retrieved {{DATE}}
- **Confidence.** {{high — read the authoritative doc | medium — inferred from code | low — assistant synthesis, unconfirmed}}
- **Implication for design.** {{}}

<!-- guidance: repeat per unknown. If a source could not be reached, record it: -->

### Unreachable sources

| Source | Why | Fallback used |
| --- | --- | --- |
| {{}} | {{browser SSO}} | {{paste-back excerpt / none — recorded as risk}} |

## Existing org patterns to reuse

<!-- guidance: from the scm and catalog connectors. Reusing an existing pattern beats inventing
one, and reviewers will ask. -->

| Pattern | Where it lives | Why it fits |
| --- | --- | --- |
| {{}} | {{repo/path}} | {{}} |

## Decisions this enables

| Decision | Chosen | Rejected alternatives | Rationale |
| --- | --- | --- | --- |
| {{}} | {{}} | {{}} | {{}} |

## Residual risks

| Risk | Likelihood | Impact | Mitigation or acceptance |
| --- | --- | --- | --- |
| {{}} | {{}} | {{}} | {{}} |
