# Checklist — {{ARTIFACT}} — {{FEATURE_TITLE}}

<!-- guidance: These are unit tests for English. Every item must be binary (a reviewer cannot
answer "sort of"), verifiable from the artifact alone, and non-trivial (an item nobody could fail
is noise). Mark each blocking or advisory. -->

**Feature:** {{NNN-slug}} · **Target:** {{spec.md | plan.md | tasks.md}} · **Date:** {{DATE}}

## Blocking

- [ ] C-01 · {{Every user story has at least one Given-When-Then acceptance criterion.}}
- [ ] C-02 · {{No NEEDS CLARIFICATION marker remains unresolved.}}
- [ ] C-03 · {{Every NFR-S row is either a concrete requirement or an open marker — none blank.}}
- [ ] C-04 · {{Every tenet has an evidence entry that names a specific section, not a paraphrase.}}
- [ ] C-05 · {{Every applicable standards.md row has a planned task id.}}
- [ ] C-06 · {{Every spec item appears in the traceability table with a test path.}}

## Advisory

- [ ] C-20 · {{Out-of-scope list is explicit enough to prevent scope creep.}}
- [ ] C-21 · {{Rejected alternatives are recorded with reasons.}}

## Result

**Verdict:** {{PASS | BLOCKED}} · **Blocking failures:** {{N}}

| Item | Verdict | Evidence / what is missing |
| --- | --- | --- |
| C-01 | {{pass/fail}} | {{}} |
