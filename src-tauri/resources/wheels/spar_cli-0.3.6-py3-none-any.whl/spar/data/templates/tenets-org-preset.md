# Engineering Tenets — Enterprise Baseline (preset)

<!-- guidance: A generic starting set for a regulated enterprise. Review every one, delete what
does not apply, and make the vague ones specific to your platform before relying on them.
A preset you have not read is worse than no preset. -->

**Version:** 1.0.0 (preset) · **Status:** DRAFT — requires review before enforcement

## T-001 · Health and readiness are explicit

- **Stance.** Every deployed service exposes a liveness and a readiness endpoint; readiness returns success only when its required dependencies are reachable.
- **Why.** Orchestrators cannot route around a service that lies about being ready; false readiness turns one slow dependency into a cascading outage.
- **How to apply.** The plan names the endpoints and lists which dependencies gate readiness. An integration test asserts unready when a dependency is down.

## T-002 · No direct data access from request handlers

- **Stance.** HTTP handlers call an application or repository layer; they never construct queries or open connections directly.
- **Why.** Inline data access makes authorisation, auditing and caching impossible to enforce in one place.
- **How to apply.** The plan shows the layering. A handler containing a query string or connection call is a violation.

## T-003 · Secrets come from the platform secret store

- **Stance.** No credential is committed, baked into an image, or passed as a plaintext environment default. Secrets are fetched at run time from the platform store.
- **Why.** Committed credentials are the single most common cause of preventable breach.
- **How to apply.** The plan names each secret and its store path. Any literal credential is a BLOCKING violation.

## T-004 · Every external call has a timeout, a retry policy and a fallback

- **Stance.** No unbounded outbound call. Timeouts, bounded retries with backoff, and a defined behaviour when the dependency is unavailable.
- **Why.** Unbounded calls convert a partial dependency failure into total thread exhaustion.
- **How to apply.** Contracts state timeout and retry per dependency; a test exercises the fallback path.

## T-005 · Errors are structured, correlated and never swallowed

- **Stance.** Log structured events with a correlation id propagated across service boundaries. Never catch an exception without either handling or re-raising it.
- **Why.** Uncorrelated logs make multi-service incidents unsolvable.
- **How to apply.** The plan names the correlation header. A bare except that continues is a violation.

## T-006 · Input is validated at the boundary against an explicit schema

- **Stance.** Every external input is validated against a declared schema before use, and rejected with a typed error.
- **Why.** Boundary validation is the cheapest defence against both bugs and injection.
- **How to apply.** Contracts declare request and response schemas; tests include malformed input cases.

## T-007 · Tests accompany the change, and they run in CI

- **Stance.** Behaviour changes ship with tests that would fail without the change, executing in the pipeline. Skipped and expected-fail tests do not count.
- **Why.** Untested behaviour is undefined behaviour once the author moves on.
- **How to apply.** Every task states its acceptance test path and function. `/spar.deliver` re-runs them.

## T-008 · Data is classified before it is stored or logged

- **Stance.** Every persisted or logged field has a known classification. Sensitive data is never written to logs and is encrypted at rest.
- **Why.** You cannot honour retention, residency or deletion obligations for data you have not classified.
- **How to apply.** `data-model.md` carries a classification column. Logging sensitive fields is BLOCKING.

## T-009 · Changes are backward compatible or explicitly versioned

- **Stance.** Published interfaces change additively. Breaking changes require a new version and a documented migration.
- **Why.** Consumers you do not know about are relying on the shape you are about to change.
- **How to apply.** Contracts mark each field added/deprecated/removed; removals need a migration note.

## T-010 · Operability ships with the feature

- **Stance.** A feature is not complete until it emits the metrics needed to tell whether it is working, and an alert fires when it is not.
- **Why.** Features without signals fail silently and are discovered by customers.
- **How to apply.** The plan names the metrics, the dashboard and at least one alert condition.

## Known Violations (Grandfathered)

| Location | Tenet | Why grandfathered | Planned remediation |
| --- | --- | --- | --- |

## Amendment log

| Version | Date | Change | Source |
| --- | --- | --- | --- |
| 1.0.0 | preset | Initial enterprise baseline | `--preset=org` |
