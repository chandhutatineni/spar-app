# Spec — {{FEATURE_TITLE}}

<!-- guidance: WHAT and WHY only. No technology choices, no library names, no schema design —
those belong in plan.md. If you cannot answer something, write a NEEDS CLARIFICATION marker
instead of guessing. Silent guessing is the single most expensive failure mode in this pipeline. -->

**Feature id:** {{NNN-slug}} · **Status:** draft · **Created:** {{DATE}}
**Source:** {{brief | BRD | PRD | ticket key}} · **risk_tier:** {{low | limited | high}}

<!-- guidance: risk_tier drives how much governance applies. high = handles money, personal data,
or a regulated decision. It is read by `spar metrics` and lands in manifest.json. -->

## Problem

{{Two to four sentences. What is broken or missing today, for whom, and what it costs.}}

## Outcome

{{What is measurably different once this ships. Prefer a number.}}

## Grounding

<!-- guidance: What did you learn from org sources before writing this? Cite connector + id +
date. If nothing was reachable, say so explicitly — that is a finding, not an omission. -->

| Source | Connector | Retrieved | What it told us |
| --- | --- | --- | --- |
| {{doc/repo/ticket}} | {{docs/scm/issues}} | {{DATE}} | {{}} |

## Scope

**In scope.** {{bulleted}}

**Out of scope.** {{bulleted — be explicit; this is where scope creep is prevented}}

## User stories

### US1 · {{Title}} — priority P1

**Satisfies.** {{FR-1, FR-3 | none — new in this spec}}

<!-- guidance: The PRD requirement ids this story delivers, or `none` when the story
originates here. This is the second link in the chain PRD → spec → tasks → code → test:
without it, a requirement can be dropped between the PRD and the spec and nothing notices.
Every FR and NFR in the PRD must appear against at least one story or in Out of scope with a
reason — /spar.design blocks on an unaccounted requirement. -->

**As a** {{role}} **I want** {{capability}} **so that** {{benefit}}.

<!-- guidance: Every story is a full vertical slice: independently testable AND independently
deployable. P1 stories together form the MVP. If a story cannot ship alone, it is a task, not a
story. -->

**Acceptance criteria**

<!-- guidance: Numbered `US1-AC1`, `US1-AC2`. These ids are what tasks and tests cite, so
they are permanent once written — renumbering breaks every link pointing at them. -->

- **US1-AC1** — **Given** {{precondition}} **when** {{action}} **then** {{observable result}}
- **US1-AC2** — **Given** {{}} **when** {{}} **then** {{}}

**Edge cases**

- {{what happens when the input is empty / the dependency is down / the user lacks permission}}

### US2 · {{Title}} — priority P2

{{same shape}}

## Non-Functional Requirements

<!-- guidance: This whole section is mandatory. The specifier must fill every subsection or leave
a NEEDS CLARIFICATION marker. `/spar.design` writes new NFR-S items back here. -->

### Security

| Id | Requirement | Notes |
| --- | --- | --- |
| NFR-S1 | **Authentication.** {{who may call this, and how they are authenticated}} | |
| NFR-S2 | **Authorisation.** {{what distinguishes a permitted from a forbidden request}} | |
| NFR-S3 | **Data classification.** {{what classes of data are touched, stored, logged}} | |
| NFR-S4 | **Network exposure.** {{internal only / partner / public; ingress and egress}} | |
| NFR-S5 | **Secrets.** {{which credentials are needed and where they come from}} | |
| NFR-S6 | **Audit logging.** {{which actions must be recorded, and for how long}} | |
| NFR-S7 | **Regulatory obligations.** {{which regimes apply, or "none identified"}} | |
| NFR-S8 | **Threat surface.** {{the two or three attacks that would hurt most}} | |

### Performance and scale

| Id | Requirement |
| --- | --- |
| NFR-P1 | {{latency target at a stated percentile and load}} |
| NFR-P2 | {{throughput / volume expectation}} |

### Reliability

| Id | Requirement |
| --- | --- |
| NFR-R1 | {{availability target and what degraded mode looks like}} |
| NFR-R2 | {{recovery expectation after a dependency failure}} |

### Operability

| Id | Requirement |
| --- | --- |
| NFR-O1 | {{the signal that tells an operator this feature is healthy}} |

## Assumptions

<!-- guidance: Every default chosen so the spec could be written without asking: stated, numbered and
visible at the spec review, where the reviewer can overturn any of them. An assumption is never
silent — this table is how a guess becomes a reviewable decision. -->

| Id | Assumption | Why this default |
| --- | --- | --- |
| A-01 | {{the default chosen}} | {{the reason it is the sensible default}} |

## Open questions

<!-- guidance: Only decisions that genuinely need a person — scope, security, personal data, money,
legal, or anything with no sensible default. About eight at most; the rest are Assumptions above.
Mirror every inline NEEDS CLARIFICATION marker here so they are countable. /spar.explore asks them
together, each with a recommendation, and records the resolution with a date. -->

| Marker | Question | Resolution | Date |
| --- | --- | --- | --- |
| NEEDS CLARIFICATION[{{topic}}] | {{question}} | | |

## Success criteria

- [ ] {{binary, checkable statement that this feature works}}
- [ ] {{another}}
