# {{PROJECT}} — Architecture

<!-- guidance: The project's living architecture document, in the arc42 structure (arc42.org),
designed with Domain-Driven Design — strategic (domains, subdomains, bounded contexts, context map)
and tactical (aggregates, entities, value objects, domain events, repositories, services) — even
for a small app with one domain and one bounded context. It lives at spar/architecture/architecture.md
with its diagrams in spar/architecture/diagrams/, and every iteration (feature) updates it rather than
starting another one: add what the iteration adds, revise what it changes, and record both in the
Change log. Use the exact names from the specs, plans and data models. No section may be left as a
placeholder: write "Not applicable — <why>" instead. -->

**Version:** {{0.1.0}} · **Updated:** {{DATE}} · **Last iteration:** {{NNN-slug}} · **Diagram tools:** {{architecture tool}}, {{other tool}}

## Change log

| Version | Date | Iteration | What changed |
| --- | --- | --- | --- |
| {{0.1.0}} | {{DATE}} | {{001-slug}} | {{first version: …}} |

## 1. Introduction and goals

### 1.1 Requirements overview

{{What the system does, for whom, in a few sentences; the main use cases with their spec ids (US1, FR-001 …) per iteration.}}

### 1.2 Quality goals

| Priority | Quality goal | Scenario that shows it | Source |
| --- | --- | --- | --- |
| 1 | {{e.g. Security}} | {{a seeker can never read another seeker's résumé}} | {{NFR-S2}} |

### 1.3 Stakeholders

| Role | Expectation of the architecture |
| --- | --- |
| {{Product owner / developers / operations / users}} | {{what they need from it}} |

## 2. Architecture constraints

| Constraint | Kind (technical, organisational, convention) | Source |
| --- | --- | --- |
| {{e.g. deploy on Render; TypeScript}} | {{technical}} | {{T-00x / decision #N}} |

## 3. Context and scope

### 3.1 Business context

![Business context](diagrams/context.{{ext}})

| Partner (person or system) | Input to the system | Output from the system |
| --- | --- | --- |
| {{Job seeker}} | {{searches, applications}} | {{results, confirmations}} |

### 3.2 Technical context

| Channel | Protocol / format | Partner | Notes |
| --- | --- | --- | --- |
| {{HTTPS REST}} | {{JSON, JWT}} | {{browser SPA}} | {{…}} |

## 4. Solution strategy

### 4.1 Domain vision

{{One paragraph: the problem space, what makes the core domain valuable, and what the system must be best at.}}

### 4.2 Subdomains (strategic design)

| Subdomain | Type (core, supporting, generic) | Why | Build, buy or reuse |
| --- | --- | --- | --- |
| {{Hiring}} | {{core}} | {{differentiates the product}} | {{build}} |

### 4.3 Bounded contexts and context map

![Context map](diagrams/context-map.drawio)

| Bounded context | Subdomain | Responsibility | Owns (aggregates) | Team / owner |
| --- | --- | --- | --- | --- |
| {{Hiring}} | {{Hiring (core)}} | {{postings and applications}} | {{JobPosting, Application}} | {{…}} |

| Upstream | Downstream | Relationship (partnership, shared kernel, customer–supplier, conformist, anticorruption layer, open host service / published language) | How it is integrated |
| --- | --- | --- | --- |
| {{Identity}} | {{Hiring}} | {{open host service / published language}} | {{JWT claims}} |

(A single bounded context is still named and drawn: its boundary is where the ubiquitous language holds.)

### 4.4 Key technology and approach decisions

{{The few decisions that shape everything — architecture style, persistence, integration style, deployment — each linked to its ADR in section 9.}}

## 5. Building block view

### 5.1 Level 1 — the system and its bounded contexts

![Building blocks](diagrams/architecture.{{ext}})

| Building block | Bounded context | Responsibility | Interfaces | Depends on |
| --- | --- | --- | --- | --- |
| {{Hiring API}} | {{Hiring}} | {{…}} | {{REST /postings}} | {{PostgreSQL}} |

### 5.2 Level 2 — inside each bounded context (tactical design)

#### {{Bounded context}}

![{{Aggregate}} aggregate](diagrams/aggregate-{{name}}.drawio)

| Building block | Kind (aggregate root, entity, value object, domain event, repository, domain service, application service, factory, policy) | Responsibility and invariants |
| --- | --- | --- |
| {{JobPosting}} | {{aggregate root}} | {{a closed posting accepts no applications}} |
| {{Salary}} | {{value object}} | {{immutable; currency + range}} |
| {{ApplicationSubmitted}} | {{domain event}} | {{raised when …; consumed by …}} |

**Layers and code layout:** {{interfaces/ (controllers, DTOs) → application/ (use cases) → domain/ (aggregates, value objects, events, repository interfaces) ← infrastructure/ (repository implementations, adapters); the exact folders under the project structure}}

## 6. Runtime view

### 6.1 {{Primary scenario}} ({{US id}})

![{{Scenario}}](diagrams/sequence-{{story}}.drawio)

{{Step by step, naming the aggregates and domain events involved, with validation, timeouts and what the user sees.}}

### 6.2 Failure scenarios

| Failure | Detection | Behaviour | What the user sees |
| --- | --- | --- | --- |
| {{…}} | {{…}} | {{retry, fallback, abort}} | {{…}} |

## 7. Deployment view

![Deployment](diagrams/deployment.{{ext}})

| Environment | Purpose | Runs on | Building blocks deployed | Configuration and secrets |
| --- | --- | --- | --- | --- |
| {{dev / test / prod}} | {{…}} | {{platform, region}} | {{…}} | {{where they come from}} |

**Infrastructure as code and pipeline:** {{infra/ layout, CI/CD stages, promotion, rollback}}

## 8. Cross-cutting concepts

### 8.1 Domain model

![Domain model](diagrams/data-model.drawio)

{{How aggregates map to storage; consistency boundaries (one aggregate per transaction); how domain events are published (in-process, outbox, broker); identifiers.}}

### 8.2 Security

{{Authentication, authorisation (per aggregate operation), input validation, secrets, data protection; the top threats from the threat model and their mitigations.}}

### 8.3 Persistence and transactions · 8.4 Error handling · 8.5 Observability · 8.6 Configuration · 8.7 Testing strategy · 8.8 User interface

{{One short paragraph each: the rule every building block follows.}}

## 9. Architecture decisions

| ADR | Date | Iteration | Decision | Alternatives | Status | Consequences |
| --- | --- | --- | --- | --- | --- | --- |
| ADR-001 | {{DATE}} | {{001-slug}} | {{…}} | {{…}} | {{accepted / superseded by ADR-00n}} | {{…}} |

## 10. Quality requirements

### 10.1 Quality tree

| Quality | Refinement | Scenario id |
| --- | --- | --- |
| {{Performance}} | {{search latency}} | {{Q-1}} |

### 10.2 Quality scenarios

| Id | Scenario (source, stimulus, environment, response, measure) | Requirement |
| --- | --- | --- |
| {{Q-1}} | {{95% of searches with 50 concurrent users return in < 500 ms}} | {{NFR-P1}} |

## 11. Risks and technical debt

| Id | Risk or debt | Impact | Likelihood | Mitigation or next step | Owner |
| --- | --- | --- | --- | --- | --- |
| R-1 | {{…}} | {{H/M/L}} | {{H/M/L}} | {{…}} | {{role}} |

## 12. Glossary (ubiquitous language)

| Term | Meaning | Bounded context | Code name |
| --- | --- | --- | --- |
| {{Posting}} | {{a job offer an employer publishes}} | {{Hiring}} | {{JobPosting}} |
