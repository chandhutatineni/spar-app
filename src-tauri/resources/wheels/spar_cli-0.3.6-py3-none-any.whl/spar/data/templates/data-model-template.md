# Data Model — {{FEATURE_TITLE}}

<!-- guidance: Every persisted field carries a classification. This column is what makes retention,
residency and deletion obligations answerable later — leave none blank. /spar.design builds the
erDiagram from this file, so keep entity and field names exact. -->

**Feature:** {{NNN-slug}} · **Date:** {{DATE}}

## Entities

### {{EntityName}}

{{One sentence: what this represents in the domain.}}

| Field | Type | Required | Classification | Notes |
| --- | --- | --- | --- | --- |
| {{id}} | {{uuid}} | yes | {{internal}} | {{primary key}} |
| {{}} | {{}} | {{}} | {{public / internal / confidential / restricted}} | {{}} |

**Keys and indexes.** {{primary key, natural keys, indexes and the query each serves}}

**Lifecycle.** {{created when, updated by what, deleted or archived how, retention period}}

## Relationships

| From | To | Cardinality | On delete |
| --- | --- | --- | --- |
| {{}} | {{}} | {{1:N}} | {{cascade / restrict / set null}} |

## Existing schema touched

<!-- guidance: from the db connector's introspection. Name what already exists so reviewers can
see what changes versus what is new. -->

| Object | Change | Backward compatible | Migration |
| --- | --- | --- | --- |
| {{}} | {{add column}} | {{yes}} | {{}} |

## Validation rules

| Field | Rule | Enforced where |
| --- | --- | --- |
| {{}} | {{}} | {{boundary schema / database constraint / both}} |

## Data handling obligations

| Class present | Obligation | How this design meets it |
| --- | --- | --- |
| {{restricted}} | {{encrypt at rest, never log, deletable on request}} | {{}} |
