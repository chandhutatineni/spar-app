# Retrospective — {{FEATURE_TITLE}}

<!-- guidance: the retro step (offered by /spar.deliver) runs after /spar.deliver. Its output is not a feelings document: it is a
concrete, approvable diff to tenets.md and standards.md. The learning loop only closes if a
governance amendment is proposed and then either accepted or explicitly declined. -->

**Feature:** {{NNN-slug}} · **Date:** {{DATE}} · **Inputs:** spec.md, tasks.md, build-log.md, verification.md

## Shipped versus planned

| Planned | Shipped | Variance | Why |
| --- | --- | --- | --- |
| {{N}} tasks | {{N}} completed | {{N}} | {{}} |

## Where the pipeline helped

- {{specific, with evidence — e.g. "the tenets gate caught a missing DR overlay at plan time"}}

## Where the pipeline added friction

- {{specific and honest — this is the part that improves the tool}}

## Checkpoints that slipped

| Checkpoint | Expected | Actual | Cause |
| --- | --- | --- | --- |
| {{}} | {{}} | {{}} | {{}} |

## Recurring review findings

<!-- guidance: mined from build-log.md. A finding appearing three or more times is a tenet or a
standard waiting to be written. -->

| Finding category | Occurrences | Root cause | Governance implication |
| --- | --- | --- | --- |
| {{}} | {{N}} | {{}} | {{new tenet / new standard / training / none}} |

## Proposed amendments

<!-- guidance: MANDATORY. Present as a diff the user accepts or declines. Never edit tenets.md or
standards.md without that approval. -->

### To `tenets.md`

```diff
+ ## T-0NN · {{Title}}
+
+ - **Stance.** {{}}
+ - **Why.** {{cite the finding count from this feature}}
+ - **How to apply.** {{}}
```

### To `standards.md`

```diff
+ | S-NN | {{required artifact}} | {{applies when}} | {{verified by}} | {{blocking}} |
```

**Approval.** {{pending | accepted by {{name}} on {{DATE}} | declined because {{reason}}}}

## Durable lessons

<!-- guidance: if a memory connector (role: memory, e.g. Hindsight) is configured, persist these
so the NEXT feature starts with them. One sentence each, no secrets, no customer data. -->

| Lesson | Persisted to memory |
| --- | --- |
| {{}} | {{yes/no}} |

## Metrics snapshot

| Metric | Value |
| --- | --- |
| Task completion | {{N}}% |
| Checkpoints | {{N}} |
| Blocking findings | {{N}} |
| Verification | {{PASS/FAIL}} |
