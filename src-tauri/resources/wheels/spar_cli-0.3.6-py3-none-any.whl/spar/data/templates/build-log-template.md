# Build Log — {{FEATURE_TITLE}}

<!-- guidance: Append-only. One entry per task, written by the executor as it finishes. This file
is what `spar metrics` mines for recurring review findings, and what the retro step (offered by /spar.deliver) reads to propose
governance amendments. Never rewrite history here. -->

**Feature:** {{NNN-slug}}

## {{T001}} · {{task title}}

- **Started / finished.** {{DATE TIME}} / {{DATE TIME}}
- **Files changed.** `{{path}}` (+{{N}}/-{{N}}), `{{path}}`
- **Tests written first.** `{{tests/test_x.py::test_name}}` — failing before, passing after
- **Test result.** {{N}} passed, {{N}} failed, {{N}} skipped
- **Review findings.**
  - BLOCKING: {{finding, and how it was resolved}}
  - IMPORTANT: {{}}
  - NIT: {{}}
- **Deviation from plan.** {{none | what changed and why}}
- **Standards satisfied.** {{S-01, S-04}}

<!-- guidance: the BLOCKING / IMPORTANT / NIT prefixes are parsed by `spar metrics` — keep the
wording exactly so finding categories aggregate across features. -->

---
