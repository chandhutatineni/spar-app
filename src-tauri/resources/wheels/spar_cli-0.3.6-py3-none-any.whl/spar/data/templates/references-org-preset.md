# Authoritative References — Org Preset

<!-- guidance: `spar mcp install` regenerates the role table below from your
spar/org-registry.yaml. Do not hand-maintain it; do hand-maintain the named documents. -->

**Version:** 1.0.0 (preset) · Regenerate with `spar mcp install`

## Connector roles available

<!-- SPAR:ROLES:BEGIN — generated, do not edit by hand -->
| Role | Connector | What to use it for |
| --- | --- | --- |
| docs | {{none configured}} | Architecture standards, runbooks, ADRs |
| issues | {{none configured}} | Ticket hydration and task export |
| scm | {{none configured}} | Existing implementations and interfaces |
| ci | {{none configured}} | The real build gates |
| db | {{none configured}} | Schema introspection (schema-first) |
| catalog | {{none configured}} | Ownership, dependencies, lifecycle |
| security | {{none configured}} | Control procedures to cite |
| observability | {{none configured}} | The monitoring baseline |
<!-- SPAR:ROLES:END -->

## Named documents

| Ref | Title | Where | Use it for |
| --- | --- | --- | --- |
| R-01 | {{Platform architecture standard}} | {{docs}} | Layering, service boundaries |
| R-02 | {{Secure coding standard}} | {{security}} | Controls the reviewer cites |
| R-03 | {{Deployment and release standard}} | {{docs}} | Environment matrix, rollback |
| R-04 | {{Data classification policy}} | {{docs}} | Classification vocabulary |

## Rules

1. Internal sources outrank the open web for anything organisation-specific.
2. Cite connector + document id + retrieved date for every design decision.
3. Assistant answers are leads, not citations.
4. "No internal source found" is a finding to record, not a gap to fill with plausible text.
