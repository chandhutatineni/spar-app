# Release — {{FEATURE_TITLE}}

<!-- guidance: Written and kept current by step `release`. `spar next` reads the Status line:
in-progress while working, needs-setup when only the person can unblock it (then "Needs from you"
says exactly what to do), failed with a "Failure" section, live once the smoke test passes. -->

**Status:** in-progress
**Live URL:** -
**Target:** {{cloud or hosting from plan.md Platform}} · **CI/CD:** {{system}} · **Infrastructure:** {{Terraform / render.yaml / docker compose}}

## Needs from you

<!-- guidance: Only while Status is needs-setup. Numbered, exact steps: the command to run in the
SPAR terminal, the setting to add, the secret to paste and where. End with "then press Continue". -->

## Steps

| Step | Result | Details |
| --- | --- | --- |
| Push to GitHub | {{pending / done / skipped}} | {{repository URL, branch, commit}} |
| Pipeline | {{pending / done / skipped}} | {{workflow run or pipeline URL}} |
| Provision infrastructure | {{pending / done}} | {{terraform plan summary: resources added/changed}} |
| Deploy | {{pending / done}} | {{service, version, region}} |
| Smoke test | {{pending / passed / failed}} | {{URL checked, health endpoint, the user story walked}} |

## Resources

| Resource | Where | Notes |
| --- | --- | --- |
| {{service / database / bucket}} | {{account, region, id}} | {{cost notes, size}} |

## Rollback

{{How to roll back this release and tear the infrastructure down (exact commands).}}
