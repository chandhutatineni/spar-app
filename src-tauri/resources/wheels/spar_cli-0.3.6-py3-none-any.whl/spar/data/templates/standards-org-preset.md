# Required Scaffolding Standards — Enterprise Baseline (preset)

<!-- guidance: DRAFT. Replace the bracketed tool names with your actual platform tooling before
enforcing. `spar mcp install` can populate the "Verified by" column from your CI connector. -->

**Version:** 1.0.0 (preset) · **Status:** DRAFT — requires review

| # | Required artifact | Applies when | Verified by | Blocking |
| --- | --- | --- | --- | --- |
| S-00 | Code follows the language's conventional project layout (see Project layout); nothing but configuration in the root | always | plan.md Project structure + controls review | yes |
| S-DDD | Code organised by bounded context, with DDD layers inside each (domain, application, infrastructure, interfaces); domain code has no framework or infrastructure imports; aggregates enforce their invariants | always | plan.md Domain design + controls review | yes |
| S-IAC | Infrastructure as code for every environment of the chosen target (infra/, Terraform unless the plan's Platform table says otherwise), validated in CI, applied only on release | deployed | terraform validate in CI | yes |
| S-01 | Dockerfile: pinned digest base, non-root user, no build secrets | containerised | image lint stage | yes |
| S-02 | CI pipeline definition committed in-repo | always | pipeline exists and is green | yes |
| S-03 | Liveness + readiness endpoints | serves traffic | integration test | yes |
| S-04 | Unit tests meeting the coverage threshold | always | coverage gate | yes |
| S-05 | Integration tests against real or contract-faked dependencies | has dependencies | CI stage | yes |
| S-06 | Dependency vulnerability scan, no unwaived criticals | always | scan gate | yes |
| S-07 | Container/image vulnerability scan | containerised | scan gate | yes |
| S-08 | Static analysis / SAST clean at the org threshold | always | quality gate | yes |
| S-09 | Secrets read from the platform secret store at run time | always | controls review | yes |
| S-10 | Structured logs with a propagated correlation id | always | controls review | yes |
| S-11 | Metrics endpoint, dashboard and at least one alert | serves traffic | observability review | no |
| S-12 | Deployment manifests for every required environment | deployed | GitOps sync | yes |
| S-13 | Runbook: how to diagnose, roll back and escalate | serves traffic | doc review | no |
| S-14 | Data classification recorded for every persisted field | persists data | controls review | yes |
| S-15 | API contract published in the org catalog | exposes an API | catalog entry | no |

## Project layout

Code lives in the conventional structure for its language and framework, never loose in the
repository root. The root holds only configuration, the README, licence, CI and container files, and
the top-level folders below. The plan names the exact tree (plan.md → Project structure) and every
task's **Files.** use those paths.

| Stack | Layout |
| --- | --- |
| Domain-Driven layout (any stack) | per bounded context: `<context>/domain/` (aggregates, entities, value objects, events, repository interfaces), `<context>/application/` (use cases), `<context>/infrastructure/` (persistence, adapters), `<context>/interfaces/` (HTTP, UI) — placed inside the stack's source folder, e.g. `backend/src/hiring/domain/` |
| Full-stack app | `frontend/` (the UI app), `backend/` (the API/service), `shared/` (types or schemas both use), `infra/` (deployment), `docs/`, `e2e/` (end-to-end tests) |
| Web frontend (React, Vue, Svelte, plain JS) | `src/` (components/, pages or routes/, lib/, styles/), `public/` for static assets, `tests/` or tests beside the code, `index.html` only where the tool expects it |
| Node / TypeScript service | `src/` (routes or controllers/, services/, models/, lib/, `index.ts`), `tests/`, `package.json` at the service root |
| Python | `src/<package>/` (package code, `__main__.py` for a CLI), `tests/`, `pyproject.toml` |
| Go | `cmd/<app>/main.go`, `internal/` (private packages), `pkg/` (public packages), `go.mod` |
| Java / Kotlin | Maven or Gradle layout: `src/main/java` (or `kotlin`), `src/main/resources`, `src/test/java` |
| Rust | `src/` (`main.rs` / `lib.rs`), `tests/`, `benches/`, a Cargo workspace for several crates |
| Swift | SwiftPM: `Sources/<Target>/`, `Tests/<Target>Tests/`, `Package.swift` |
| .NET | `src/<Project>/`, `tests/<Project>.Tests/`, a `.sln` at the root |

## Environment matrix

| Environment | Required | Notes |
| --- | --- | --- |
| dev | yes | Ephemeral; may use fakes |
| test | yes | Integration tests run here |
| test-dr | no | Required for tier-1 services |
| prod | yes | |
| prod-dr | yes for tier-1 | Must be provably deployable, not just defined |

## Language / stack tooling

| Stack | Formatter | Linter | Type checker | Test runner |
| --- | --- | --- | --- | --- |
| Python | {{black or ruff format}} | {{ruff}} | {{mypy}} | {{pytest}} |
| TypeScript | {{prettier}} | {{eslint}} | {{tsc}} | {{vitest or jest}} |
| Java | {{spotless}} | {{checkstyle}} | {{n/a}} | {{junit}} |
| Go | {{gofmt}} | {{golangci-lint}} | {{n/a}} | {{go test}} |
