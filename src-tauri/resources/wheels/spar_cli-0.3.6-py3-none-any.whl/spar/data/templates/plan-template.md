# Plan — {{FEATURE_TITLE}}

<!-- guidance: Phase 1 of /spar.design. Interfaces, not implementation. No function bodies. The
tenets gate reads this file twice: once before research, once after design. Every standards.md
required artifact must appear as a planned task or the gate BLOCKS. -->

**Feature:** {{NNN-slug}} · **Date:** {{DATE}} · **Tenets version:** {{X.Y.Z}}

## Approach

{{Three to six sentences: the shape of the solution and why this shape.}}

## Platform

<!-- guidance: MANDATORY, and none of it is yours to decide. What this is written in, where it runs
and what deploys it are commitments someone else has to staff, fund and operate long after this
feature ships. Every row's Source is a tenet, a standard, a recorded decision, `deferred (decision
#N)`, or a NEEDS CLARIFICATION[platform-*] marker. A cited org document is evidence for a
recommendation, not a source: put the recommendation in the marker. "The house already uses it" and
"it is the obvious choice" are both reasons to propose, and neither is a reason to have skipped
asking. Add rows the feature needs; do not delete rows by deciding they are obvious.

"Later" is a real answer. A row nobody can decide yet is deferred with `spar gate defer <feature>
<row> --note "..."`, and the Selection cell reads `deferred`. It is not a way to get moving with a
placeholder: nothing downstream may assume a value for a deferred row, so the planner does not task
it and the executor stops rather than inventing one. Rows: language, framework, datastore, cloud,
orchestration, cicd, deploy-tooling. -->

| Choice | Selection | Source |
| --- | --- | --- |
| Language and runtime | {{}} | {{T-00N / S-0N / decision #N / NEEDS CLARIFICATION[platform-language]}} |
| Application framework | {{}} | {{}} |
| Datastore | {{}} | {{}} |
| Cloud or hosting target | {{}} | {{}} |
| Compute and orchestration | {{}} | {{}} |
| CI/CD system | {{GitHub Actions / Jenkins / Spinnaker / GitLab CI / Argo CD / deferred}} | {{}} |
| Deployment tooling | {{Terraform / Helm / Pulumi / CDK / plain manifests / deferred}} | {{}} |

## Architecture

<!-- guidance: components, responsibilities, and how requests flow. /spar.design turns this into
diagrams; keep the component names stable so the diagram matches. -->

| Component | Responsibility | New or existing |
| --- | --- | --- |
| {{}} | {{}} | {{}} |

**Request flow.** {{numbered walk-through of the primary story}}

## Domain design

<!-- guidance: Domain-Driven Design, always — even for one domain and one bounded context. Which
bounded contexts this iteration touches (new or existing, from spar/architecture/architecture.md
§4.3), the aggregates it adds or changes with their invariants, the value objects and domain events,
and new terms for the ubiquitous language. The architecture document is updated from this. -->

| Bounded context | New or changed | Aggregates (root → invariants) | Value objects | Domain events |
| --- | --- | --- | --- | --- |
| {{Hiring}} | {{new}} | {{JobPosting → a closed posting accepts no applications}} | {{Salary, Location}} | {{PostingPublished, ApplicationSubmitted}} |

**New terms:** {{term — meaning}}

## Project structure

<!-- guidance: The exact source tree this feature creates or changes, in the language's conventional
layout (spar/standards.md → Project layout), organised by bounded context with DDD layers inside each
(interfaces/, application/, domain/, infrastructure/). Nothing but configuration in the repository root; a
full-stack app splits frontend/ and backend/. Every task's Files. line uses these paths. Include how
to run it locally: the command for each service, its port and health check. -->

```
{{project-root}}/
├── {{frontend/ or src/ …}}
├── {{backend/ …}}
└── {{tests/ or e2e/ …}}
```

| Service | Directory | Run locally | Port | Health check |
| --- | --- | --- | --- | --- |
| {{backend}} | {{backend/}} | {{npm run dev}} | {{8080}} | {{GET /healthz}} |

## Interfaces

<!-- guidance: signatures and contracts only. Details go in contracts/*.md. -->

| Interface | Kind | Contract file | Consumers |
| --- | --- | --- | --- |
| {{}} | {{HTTP / queue / library}} | `contracts/{{name}}.md` | {{}} |

## Presentation

<!-- guidance: MANDATORY when a person looks at this feature. When nobody does, the whole section
is `**Applies:** n/a — no user interface` and you are done.

Every other section decides what the software does. This one decides what it *is* to the person
using it, and it is the section that gets skipped, because skipping it breaks nothing: the tests
pass, the build goes green, the contracts are honoured, and what ships is a column of unstyled
form controls on a white page. A feature nobody can bear to look at is not a feature that works.

Name tokens, not adjectives. "Clean and modern" cannot be implemented or reviewed; a type scale, a
spacing step and a palette can. The executor styles from this table, so an empty cell does not
become a sensible default — it becomes whatever CSS the framework's scaffold happened to ship
with, aimed at class names nothing renders.

If `spar/design/` holds exported design screens, this section **adopts** them: cite the
screen and carry its tokens across verbatim. Never invent a second set beside a design that
already exists. Where no design exists you are choosing the house default, and that is a decision
to record here, not a gap to leave for whoever writes the markup. -->

**Applies:** {{yes / n/a — no user interface}}

**Design source:** {{`spar/design/{{screen}}` (exported {{date}}) / none — tokens chosen here}}

| Token group | Decision |
| --- | --- |
| Colour | {{surface, text, accent, border, and the semantic pairs for success/warning/danger — with dark-mode values, or a note that dark mode is out of scope}} |
| Type | {{family stack, base size, scale ratio, heading sizes, line height}} |
| Spacing and radius | {{the step scale, e.g. 4/8/12/16/24/32, and the corner radii}} |
| Elevation and border | {{shadow levels and border treatment}} |
| Breakpoints | {{the widths at which the layout changes, and what changes at each}} |

**Token home.** {{the exact file the tokens live in — e.g. `web/src/styles/tokens.css` as custom properties}}

**Styling approach.** {{plain CSS with custom properties / CSS modules / Tailwind / a named component
library — and, if a library, the platform table row that sourced it}}

<!-- guidance: one row per thing a person sees. "States" is the column people leave thin, and it is
the one that separates a demo from a product: an empty result list, a failed payment and a slow
network are all things the user will meet on day one. -->

| Screen or component | Purpose | States it must render |
| --- | --- | --- |
| {{}} | {{}} | {{loading / empty / error / success / disabled — every state the story can actually reach}} |

**Accessibility.** {{contrast ratio target, the visible focus treatment, keyboard order, reduced-motion
behaviour, and the minimum touch target}}

## Data

{{Summary only — the detail lives in data-model.md, including classification per field.}}

## Dependencies

| Dependency | Purpose | Timeout | Retry | Fallback when unavailable |
| --- | --- | --- | --- | --- |
| {{}} | {{}} | {{}} | {{}} | {{}} |

## Non-functional design

| NFR | How this design satisfies it |
| --- | --- |
| NFR-S1 | {{}} |
| NFR-P1 | {{}} |

## Tenets gate compliance

<!-- guidance: MANDATORY. One row per tenet, no exceptions, no blanks. "Not applicable" needs a
reason. A vague entry is treated as non-compliance and BLOCKS. -->

| Tenet | Compliant | Evidence in this plan |
| --- | --- | --- |
| T-001 | {{yes / no / n-a}} | {{specific section or component, not "the design handles it"}} |
| T-002 | | |

## Standards coverage

<!-- guidance: MANDATORY. Every applicable standards.md row needs a planned task id. Missing
scaffolding is the most common BLOCK. -->

| Standard | Applies | Planned task | Notes |
| --- | --- | --- | --- |
| S-01 | {{yes/no}} | {{T0NN}} | {{}} |

## Migration and rollout

- **Rollout.** {{how this reaches production safely}}
- **Rollback.** {{the exact way to undo it}}
- **Data migration.** {{forwards and backwards, or "none"}}

## Rejected alternatives

| Alternative | Why rejected |
| --- | --- |
| {{}} | {{}} |
