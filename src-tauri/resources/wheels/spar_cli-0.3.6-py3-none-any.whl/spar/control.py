"""The MCP control plane.

An administrator's surface for the organisation tier: browse the connector catalog,
connect and enable systems, set gateway policy, and read the audit and telemetry the
gateway produces. Developers never see this; they see only what has been enabled.

Serves on loopback only, from the standard library alone. It writes exactly two files
-- the org registry and the gateway policy -- and treats everything else as read-only.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import socket
import urllib.parse
from pathlib import Path

from . import __version__
from .cli import (
    _confined,
    connector_endpoint,
    find_spar_root,
    host_config_dir,
    load_catalog,
    load_gateway_policy,
    load_project_selection,
    load_registry,
    missing_config,
    now_iso,
    org_enabled,
    read_decisions,
    read_gateway_log,
    registry_search_paths,
    resolve_connectors,
    verify_chain,
)
from . import access, vault

# --------------------------------------------------------------------------- #
# The control plane's own shape
#
# MCP Gateway is the module that exists today. The others are declared here so
# the portal tells the truth about what is and is not built, rather than
# implying a completeness it does not have.
# --------------------------------------------------------------------------- #

MODULES = [
    {
        "id": "gateway",
        "name": "MCP Gateway",
        "blurb": "Every connection an agent may make, and the policy on each call.",
        "state": "live",
        "views": ["catalog", "connections", "policy", "activity"],
    },
    {"id": "ledger", "name": "Decision ledger", "blurb": "Hash-chained record of every approval.", "state": "live"},
    {"id": "agents", "name": "Agent registry", "blurb": "Which agents exist, what each may touch.", "state": "planned"},
    {"id": "models", "name": "Model routing", "blurb": "Providers, fallbacks, per-team limits.", "state": "planned"},
    {"id": "identity", "name": "Identity & access", "blurb": "Who administers what, mapped to your IdP.", "state": "planned"},
    {"id": "cost", "name": "Cost & quota", "blurb": "Spend per team, per model, per connector.", "state": "planned"},
    {"id": "data", "name": "Data boundaries", "blurb": "Residency, retention, redaction at rest.", "state": "planned"},
    {"id": "evidence", "name": "Compliance evidence", "blurb": "Control mappings and export packs.", "state": "planned"},
]

# A credential env var name is a configuration value, not a secret. Knowing
# whether it is *set* on this host turns "point your connection details" into a
# one-glance check; the value itself is never read, logged or returned.
ENV_KEYS = ("token_env", "dsn_env", "key_env", "secret_env", "password_env")

# --------------------------------------------------------------------------- #
# Registry persistence
# --------------------------------------------------------------------------- #

REGISTRY_HEADER = """\
# Organisation MCP registry -- managed by the control plane.
#
# Written by `spar control`. Values marked *_env are the NAMES of environment
# variables; credential values are never stored here and never leave the host
# they are read on.
"""


def registry_target(explicit: str | None) -> Path:
    """Where the control plane writes. Prefers an existing file, else the project."""
    for p in registry_search_paths(explicit):
        if p.is_file():
            return p
    root = find_spar_root()
    if root:
        return root / "org-registry.yaml"
    return host_config_dir() / "org-registry.yaml"


def dump_registry(reg: dict) -> str:
    """Emit the small YAML subset the loader reads back. Deliberately not a general
    serialiser -- it only has to round-trip what the control plane writes."""
    lines = [REGISTRY_HEADER, f"# last updated {now_iso()}", ""]
    if reg.get("scope"):
        lines.append(f"scope: {reg['scope']}")
    if reg.get("bridge"):
        lines.append(f"bridge: {reg['bridge']}")
    lines.append("")
    lines.append("connectors:")
    for c in reg.get("connectors", []):
        first = True
        for key in ["use"] + sorted(k for k in c if k != "use"):
            if key not in c:
                continue
            val = c[key]
            if isinstance(val, bool):
                val = "true" if val else "false"
            prefix = "  - " if first else "    "
            lines.append(f"{prefix}{key}: {val}")
            first = False
    lines.append("")
    return "\n".join(lines)


def write_registry(path: Path, reg: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(dump_registry(reg), encoding="utf-8")


# --------------------------------------------------------------------------- #
# State assembled for the UI
# --------------------------------------------------------------------------- #


def credential_state(spec: dict, values: dict) -> dict:
    """Which env vars this connector expects, and whether they are set here.

    Only names and presence -- never a value. ``configured`` is the name the
    registry gives; ``example`` is the shipped suggestion used until then.
    """
    out = []
    for f in spec.get("config", []):
        if f["key"] not in ENV_KEYS:
            continue
        name = values.get(f["key"]) or str(f.get("example", ""))
        st = vault.state(spec["id"], name) if name else {"source": "", "present": False}
        out.append(
            {
                "key": f["key"],
                "name": name,
                "configured": bool(values.get(f["key"])),
                "present": bool(st.get("present")),
                "source": st.get("source", ""),
                "command": st.get("command", ""),
            }
        )
    return {"vars": out, "all_present": bool(out) and all(v["present"] for v in out)}



def _host_of(url: str) -> str:
    """`host[:port]` from a URL template, or "" when there is none to reach."""
    if not url:
        return ""
    parsed = urllib.parse.urlparse(url if "://" in url else "https://" + url)
    return parsed.netloc


def probe(spec: dict, entry: dict) -> dict:
    """Test a connection without calling a tool. Every check is a fact we can
    establish locally: required values filled, credential set, command present,
    host resolvable and accepting TCP. Nothing here proves the upstream speaks
    MCP -- the first real call does that, and the result says so."""
    values = {k: v for k, v in entry.items() if k not in ("use", "enabled")}
    merged = dict(spec)
    merged["config_values"] = values
    checks = []

    miss = missing_config(merged)
    checks.append(
        {
            "name": "required settings",
            "ok": not miss,
            "detail": "all present" if not miss else "missing " + ", ".join(miss),
        }
    )

    creds = credential_state(spec, values)
    for v in creds["vars"]:
        checks.append(
            {
                "name": f"credential ${v['name']}",
                "ok": v["present"],
                "detail": "set in this environment" if v["present"] else "not set on this host",
            }
        )

    transport = spec.get("transport", "http")
    if transport == "stdio":
        cmd = (spec.get("command") or [""])[0]
        found = shutil.which(cmd) if cmd else None
        checks.append(
            {
                "name": f"command {cmd or '?'}",
                "ok": bool(found),
                "detail": found or "not on PATH -- install it on the gateway host",
            }
        )
    else:
        # A remote server with a fixed endpoint (GitHub's, for one) has no `host`
        # setting to configure; the catalog entry's own URL is the host to reach.
        host = values.get("host") or _host_of(spec.get("url_template") or "")
        if not host:
            checks.append({"name": "host", "ok": False, "detail": "no host configured"})
        else:
            hostname = host.split("/")[0].split(":")[0]
            port = 443
            if ":" in host.split("/")[0]:
                tail = host.split("/")[0].rsplit(":", 1)[1]
                port = int(tail) if tail.isdigit() else 443
            try:
                addr = socket.gethostbyname(hostname)
                checks.append({"name": f"resolve {hostname}", "ok": True, "detail": addr})
            except OSError as exc:
                checks.append({"name": f"resolve {hostname}", "ok": False, "detail": str(exc)})
                addr = None
            if addr:
                s = socket.socket()
                s.settimeout(3.0)
                try:
                    s.connect((addr, port))
                    checks.append({"name": f"connect {hostname}:{port}", "ok": True, "detail": "accepted"})
                except OSError as exc:
                    checks.append(
                        {"name": f"connect {hostname}:{port}", "ok": False, "detail": str(exc)}
                    )
                finally:
                    s.close()

    ok = all(c["ok"] for c in checks)
    return {
        "ok": ok,
        "checks": checks,
        "summary": (
            "reachable and configured"
            if ok
            else "; ".join(c["detail"] for c in checks if not c["ok"])
        ),
    }


def build_state(explicit_registry: str | None) -> dict:
    catalog = load_catalog()
    registry, rpath, tried = load_registry(explicit_registry)
    spar_root = find_spar_root()
    selection = load_project_selection(spar_root)
    everything = resolve_connectors(registry, selection=selection, include_disabled=True)
    by_id = {(c.get("alias") or c["id"]): c for c in everything}

    connected = []
    for c in everything:
        label = c.get("alias") or c["id"]
        transport, endpoint = connector_endpoint(c)
        connected.append(
            {
                "id": c["id"],
                "label": label,
                "name": c.get("name", c["id"]),
                "category": c.get("category", ""),
                "role": c.get("role", ""),
                "readonly": bool(c.get("readonly", True)),
                "enabled": c.get("availability") != "not-enabled-by-org",
                "availability": c.get("availability"),
                "missing": missing_config(c),
                "config_values": {
                    k: v for k, v in (c.get("config_values") or {}).items() if k != "enabled"
                },
                "endpoint": endpoint if isinstance(endpoint, str) else " ".join(endpoint or []),
                "transport": transport,
                "unresolved": "{" in str(endpoint),
            }
        )

    log = read_gateway_log(spar_root) if spar_root else []
    per: dict[str, dict[str, int]] = {}
    for e in log:
        d = per.setdefault(e.get("connector", "?"), {})
        v = e.get("verdict", "?")
        d[v] = d.get(v, 0) + 1
    denials = [e for e in log if e.get("verdict") == "blocked"][-12:]

    decisions = read_decisions(spar_root) if spar_root else []
    chain_ok, chain_msg = verify_chain(spar_root) if spar_root else (True, "no project")

    connected_ids = {c["id"] for c in everything}
    enabled_ids = {c["id"] for c in everything if c.get("availability") != "not-enabled-by-org"}
    cat = []
    for s in catalog.values():
        entry = by_id.get(s["id"]) or {}
        values = entry.get("config_values") or {}
        cat.append(
            {
                "id": s["id"],
                "name": s.get("name", s["id"]),
                "category": s.get("category", ""),
                "role": s.get("role", ""),
                "summary": s.get("summary", ""),
                "readonly": bool(s.get("readonly", True)),
                "status": s.get("status", "template"),
                "transport": s.get("transport", "http"),
                "auth": s.get("auth", "pat"),
                "url_template": s.get("url_template", ""),
                "command": s.get("command", []),
                "config": [
                    {
                        "key": f["key"],
                        "desc": f.get("desc", ""),
                        "required": f.get("required", True),
                        "example": str(f.get("example", "")),
                        "secret_ref": f["key"] in ENV_KEYS,
                        "value": values.get(f["key"], ""),
                    }
                    for f in s.get("config", [])
                ],
                "tools": s.get("tools", []),
                "grants": s.get("grants", []),
                "notes": s.get("notes", ""),
                "connected": s["id"] in connected_ids,
                "enabled": s["id"] in enabled_ids,
                "credentials": credential_state(s, values),
                "calls": sum(per.get(s["id"], {}).values()),
            }
        )
    cat.sort(key=lambda x: (x["category"], x["name"].lower()))

    categories: dict[str, dict] = {}
    for c in cat:
        d = categories.setdefault(c["category"], {"total": 0, "connected": 0, "enabled": 0})
        d["total"] += 1
        d["connected"] += int(c["connected"])
        d["enabled"] += int(c["enabled"])

    policy = load_gateway_policy(spar_root)
    return {
        "version": __version__,
        "generated_at": now_iso(),
        "project": spar_root.parent.name if spar_root else None,
        "spar_root": str(spar_root) if spar_root else None,
        "registry_path": str(rpath) if rpath else None,
        "registry_target": str(registry_target(explicit_registry)),
        "searched": [str(p) for p in tried],
        "modules": MODULES,
        "catalog": cat,
        "catalog_count": len(catalog),
        "categories": categories,
        "connected": connected,
        "project_selection": sorted(selection) if selection is not None else None,
        "telemetry": {
            "calls": len(log),
            "per_connector": per,
            "denials": denials,
            "cache_hits": sum(1 for e in log if e.get("verdict") == "cache-hit"),
            "redacted": sum(int(e.get("redacted") or 0) for e in log),
        },
        "audit": {
            "count": len(decisions),
            "chain_ok": chain_ok,
            "chain_msg": chain_msg,
            "recent": [
                {
                    "seq": d.get("seq"),
                    "at": d.get("at"),
                    "subject": (d.get("subject") or {}).get("id"),
                    "action": (d.get("action") or {}).get("name"),
                    "verdict": d.get("verdict"),
                    "explanation": (d.get("explanation") or "")[:160],
                }
                for d in decisions[-14:]
            ],
        },
        "policy": {k: v for k, v in policy.items() if k != "_source"},
        "policy_source": policy.get("_source"),
        "access": {
            "enrollment": access.enrollment_state(),
            "subjects": access.subjects(),
            "gateway_url": read_gateway_url(),
            "host_config": str(host_config_dir()),
            "identity": access.get_config(),
            "oidc": access.oidc_enabled(),
            "group_scopes": access.group_scopes(),
        },
    }


AEGIS_FILE = "aegis.json"


def read_gateway_url() -> str:
    """The URL developers are told to log in to. Stored only so the portal can
    print an exact command; the gateway itself does not need it."""
    p = host_config_dir() / AEGIS_FILE
    if not p.is_file():
        return ""
    try:
        return str((json.loads(p.read_text(encoding="utf-8")) or {}).get("gateway_url") or "")
    except (OSError, ValueError):
        return ""


def write_gateway_url(url: str) -> None:
    p = host_config_dir() / AEGIS_FILE
    p.parent.mkdir(parents=True, exist_ok=True)
    data = {}
    if p.is_file():
        try:
            data = json.loads(p.read_text(encoding="utf-8")) or {}
        except (OSError, ValueError):
            data = {}
    data["gateway_url"] = url
    p.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


# --------------------------------------------------------------------------- #
# Mutations
# --------------------------------------------------------------------------- #

SAFE_VALUE = re.compile(r"^[A-Za-z0-9_./:@{}<>-]{0,200}$")


def apply_action(explicit_registry: str | None, action: dict) -> dict:
    """Handle a control-plane mutation. Returns {ok, message} or {error}."""
    kind = action.get("action")
    reg, rpath, _ = load_registry(explicit_registry)
    reg = reg or {"scope": "user", "connectors": []}
    reg.setdefault("connectors", [])
    target = registry_target(explicit_registry)
    catalog = load_catalog()

    def find(label: str):
        for entry in reg["connectors"]:
            lbl = entry.get("name") or entry.get("use") or entry.get("connector")
            if lbl == label or entry.get("use") == label:
                return entry
        return None

    if kind == "connect":
        cid = action.get("id")
        if cid not in catalog:
            return {"error": f"unknown connector: {cid}"}
        if find(cid):
            return {"error": f"{cid} is already connected"}
        entry = {"use": cid, "enabled": False}
        for k, v in (action.get("values") or {}).items():
            if not isinstance(v, str) or not SAFE_VALUE.match(v):
                return {"error": f"invalid value for {k}"}
            if v:
                entry[k] = v
        reg["connectors"].append(entry)
        write_registry(target, reg)
        return {"ok": True, "message": f"{cid} connected, staged as disabled"}

    if kind in ("enable", "disable"):
        entry = find(action.get("id", ""))
        if not entry:
            return {"error": "connector is not connected"}
        if kind == "enable":
            spec = catalog.get(entry.get("use"), {})
            merged = dict(spec)
            merged["config_values"] = {k: v for k, v in entry.items() if k not in ("use", "enabled")}
            miss = missing_config(merged)
            if miss:
                return {"error": "cannot enable: missing " + ", ".join(miss)}
            entry["enabled"] = True
        else:
            entry["enabled"] = False
        write_registry(target, reg)
        return {"ok": True, "message": f"{action['id']} {kind}d"}

    if kind == "configure":
        entry = find(action.get("id", ""))
        if not entry:
            return {"error": "connector is not connected"}
        for k, v in (action.get("values") or {}).items():
            if not isinstance(v, str) or not SAFE_VALUE.match(v):
                return {"error": f"invalid value for {k}"}
            if v:
                entry[k] = v
            else:
                entry.pop(k, None)
        write_registry(target, reg)
        return {"ok": True, "message": f"{action['id']} updated"}

    # ---- credentials: write-only, on this host ---------------------------- #
    if kind in ("secret-set", "secret-command", "secret-clear"):
        cid = action.get("id", "")
        spec = catalog.get(cid)
        if not spec:
            return {"error": f"unknown connector: {cid}"}
        var = str(action.get("var") or "").strip()
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,80}", var):
            return {"error": "a credential variable name must look like AN_ENV_VAR"}
        if kind == "secret-clear":
            if vault.clear_secret(cid, var):
                return {"ok": True, "message": f"${var} removed from this host"}
            return {"error": f"${var} was not stored here"}
        if kind == "secret-command":
            argv = action.get("argv")
            if not isinstance(argv, list) or not argv:
                return {"error": "give the secret-manager command as a list of arguments"}
            try:
                vault.set_command(cid, var, [str(a) for a in argv])
            except ValueError as exc:
                return {"error": str(exc)}
            got = vault.state(cid, var)
            return {
                "ok": True,
                "message": (
                    f"${var} will be fetched by command"
                    + ("" if got["present"] else " -- but the command returned nothing just now")
                ),
            }
        value = action.get("value")
        # A credential is not a registry value, so it is not held to SAFE_VALUE;
        # it must simply be printable and bounded. It is never echoed back.
        if not isinstance(value, str) or not value:
            return {"error": "no value given"}
        if len(value) > 4096 or any(ord(c) < 32 or ord(c) == 127 for c in value):
            return {"error": "that does not look like a credential (control characters, or too long)"}
        vault.set_secret(cid, var, value)
        return {"ok": True, "message": f"${var} stored on this host for {cid}"}

    # ---- access: who may use the gateway ---------------------------------- #
    if kind == "enrollment-rotate":
        token = access.rotate_enrollment()
        # The one and only time this is readable. It is not stored in the state
        # the portal polls, so a reload will not show it again.
        return {
            "ok": True,
            "message": "new enrollment token issued -- copy it now, it is not shown again",
            "token": token,
        }

    if kind == "enrollment-close":
        if access.clear_enrollment():
            return {"ok": True, "message": "enrollment closed; enrolled developers are unaffected"}
        return {"error": "enrollment was already closed"}

    if kind == "identity":
        # OIDC only engages once a proxy is named. Until then it is key-only, and
        # an identity header from anywhere is ignored rather than believed.
        patch = {}
        if "proxy_peers" in action:
            peers = action.get("proxy_peers")
            if isinstance(peers, str):
                peers = [x.strip() for x in peers.replace(";", ",").split(",") if x.strip()]
            if not isinstance(peers, list):
                return {"error": "give the trusted proxy addresses as a list"}
            for peer in peers:
                if not re.fullmatch(r"[A-Za-z0-9_.:*\[\]-]{1,64}", str(peer)):
                    return {"error": f"not an address: {peer}"}
            patch["proxy_peers"] = peers
        for key in ("proxy_user_header", "proxy_groups_header"):
            if key in action:
                val = str(action[key] or "").strip()
                if val and not re.fullmatch(r"[A-Za-z0-9-]{1,64}", val):
                    return {"error": f"not a header name: {val}"}
                if val:
                    patch[key] = val
        if "token_ttl_days" in action:
            try:
                ttl = int(action["token_ttl_days"])
            except (TypeError, ValueError):
                return {"error": "token lifetime must be a number of days"}
            if ttl < 0 or ttl > 3650:
                return {"error": "token lifetime must be between 0 and 3650 days"}
            patch["token_ttl_days"] = ttl
        if not patch:
            return {"error": "nothing to change"}
        try:
            cfg = access.set_config(**patch)
        except ValueError as exc:
            return {"error": str(exc)}
        mode = "your identity provider, via the trusted proxy" if cfg["proxy_peers"] else "machine keys only"
        return {"ok": True, "message": f"identity: {mode}"}

    if kind == "subject-scope":
        sid = str(action.get("subject") or "")
        conns = action.get("connectors")
        if not isinstance(conns, list):
            return {"error": "give the connectors as a list"}
        unknown = [c for c in conns if c not in catalog]
        if unknown:
            return {"error": "not in the catalog: " + ", ".join(unknown[:4])}
        if not access.set_subject_scope(sid, [str(c) for c in conns]):
            return {"error": "no such developer"}
        return {
            "ok": True,
            "message": (
                f"limited to {len(conns)} connector(s)" if conns
                else "unrestricted: everything the organisation enabled"
            ),
        }

    if kind == "group-scope":
        group = str(action.get("group") or "").strip()
        conns = action.get("connectors")
        if not group:
            return {"error": "name the group as your identity provider spells it"}
        if not isinstance(conns, list):
            return {"error": "give the connectors as a list"}
        unknown = [c for c in conns if c not in catalog]
        if unknown:
            return {"error": "not in the catalog: " + ", ".join(unknown[:4])}
        access.set_group_scope(group, [str(c) for c in conns])
        return {
            "ok": True,
            "message": (
                f"{group}: {len(conns)} connector(s)" if conns else f"{group}: scope cleared"
            ),
        }

    if kind == "subject-revoke":
        sid = str(action.get("subject") or "")
        if access.revoke(sid):
            return {"ok": True, "message": f"{sid} revoked"}
        return {"error": "no such developer, or already revoked"}

    if kind == "gateway-url":
        url = str(action.get("url") or "").strip()
        if url and not re.match(r"^https?://[A-Za-z0-9._:\[\]-]+(/.*)?$", url):
            return {"error": "that is not an http(s) URL"}
        write_gateway_url(url)
        return {"ok": True, "message": "gateway URL saved" if url else "gateway URL cleared"}

    if kind == "test":
        cid = action.get("id", "")
        entry = find(cid) or {}
        spec = catalog.get(entry.get("use") or cid)
        if not spec:
            return {"error": f"unknown connector: {cid}"}
        result = probe(spec, entry)
        return {"ok": result["ok"], "message": result["summary"], "test": result}

    if kind == "policy":
        spar_root = find_spar_root()
        current = load_gateway_policy(spar_root)
        current.pop("_source", None)
        patch = action.get("policy") or {}
        allowed = {"default", "roles", "deny_tools", "redact_patterns"}
        unknown = set(patch) - allowed
        if unknown:
            return {"error": "not a policy key: " + ", ".join(sorted(unknown))}
        for k, v in patch.items():
            if k in ("deny_tools", "redact_patterns"):
                if not isinstance(v, list) or any(not isinstance(x, str) for x in v):
                    return {"error": f"{k} must be a list of strings"}
                if k == "redact_patterns":
                    for pat in v:
                        try:
                            re.compile(pat)
                        except re.error as exc:
                            return {"error": f"not a valid pattern: {pat} ({exc})"}
                current[k] = v
            elif isinstance(v, dict):
                current.setdefault(k, {})
                current[k].update(v)
            else:
                return {"error": f"{k} must be an object"}
        # Same scoping rule as the registry: inside a project it is the
        # project's policy, outside one it is the organisation's.
        base = spar_root or host_config_dir()
        base.mkdir(parents=True, exist_ok=True)
        path = base / "gateway-policy.json"
        path.write_text(json.dumps(current, indent=2) + "\n", encoding="utf-8")
        scope = "project" if spar_root else "organisation"
        return {"ok": True, "message": f"{scope} policy written to {path}"}

    if kind == "remove":
        before = len(reg["connectors"])
        reg["connectors"] = [
            e
            for e in reg["connectors"]
            if (e.get("name") or e.get("use")) != action.get("id") and e.get("use") != action.get("id")
        ]
        if len(reg["connectors"]) == before:
            return {"error": "connector is not connected"}
        write_registry(target, reg)
        return {"ok": True, "message": f"{action['id']} removed"}

    return {"error": f"unknown action: {kind}"}


# --------------------------------------------------------------------------- #
# Server
# --------------------------------------------------------------------------- #


def serve_control(port: int, open_browser: bool, explicit_registry: str | None, verbose: bool) -> int:
    import http.server
    import signal
    import sys
    import threading

    from .cli import bad, dim, info, ok

    here = Path(__file__).resolve().parent / "web"
    index = here / "control.html"
    if not index.is_file():
        bad(f"control UI missing at {index}")
        return 1

    class Handler(http.server.BaseHTTPRequestHandler):
        server_version = f"spar-control/{__version__}"

        def log_message(self, fmt, *a):
            if verbose:
                sys.stdout.write(f"  {dim(fmt % a)}\n")
                sys.stdout.flush()

        def _send(self, code, body: bytes, ctype: str):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            try:
                self.wfile.write(body)
            except BrokenPipeError:
                pass

        def _json(self, obj, code=200):
            self._send(code, json.dumps(obj).encode("utf-8"), "application/json; charset=utf-8")

        def do_GET(self):  # noqa: N802
            path = urllib.parse.urlparse(self.path).path
            if path in ("/", "/index.html"):
                return self._send(200, index.read_bytes(), "text/html; charset=utf-8")
            if path == "/api/state":
                return self._json(build_state(explicit_registry))
            return self._send(404, b"not found", "text/plain; charset=utf-8")

        def do_POST(self):  # noqa: N802
            path = urllib.parse.urlparse(self.path).path
            if path != "/api/action":
                return self._send(404, b"not found", "text/plain; charset=utf-8")
            try:
                n = int(self.headers.get("Content-Length") or 0)
                if n > 64_000:
                    return self._json({"error": "payload too large"}, 413)
                body = json.loads(self.rfile.read(n) or b"{}")
            except (ValueError, json.JSONDecodeError):
                return self._json({"error": "invalid JSON"}, 400)
            try:
                res = apply_action(explicit_registry, body)
            except Exception as exc:  # never 500 without a reason the admin can read
                res = {"error": f"{type(exc).__name__}: {exc}"}
            return self._json(res, 200 if res.get("ok") else 400)

    httpd = None
    for _ in range(6):
        try:
            httpd = http.server.ThreadingHTTPServer(("127.0.0.1", port), Handler)
            break
        except OSError:
            info(f"port {port} busy, trying {port + 1}")
            port += 1
    if httpd is None:
        bad("could not bind a port on 127.0.0.1")
        return 1

    url = f"http://127.0.0.1:{port}/"
    ok(f"MCP control plane on {url}  {dim('(loopback only)')}")
    info(f"registry: {registry_target(explicit_registry)}")
    print(f"  {dim('Ctrl-C to stop')}")
    sys.stdout.flush()

    if open_browser:
        try:
            import webbrowser

            webbrowser.open(url)
        except Exception:
            pass

    stopping = threading.Event()

    def _stop(_s, _f):
        if not stopping.is_set():
            stopping.set()
            threading.Thread(target=httpd.shutdown, daemon=True).start()

    prev = {}
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            prev[sig] = signal.signal(sig, _stop)
        except (ValueError, OSError):
            pass
    try:
        httpd.serve_forever(poll_interval=0.3)
    except KeyboardInterrupt:
        pass
    finally:
        for sig, h in prev.items():
            try:
                signal.signal(sig, h)
            except (ValueError, OSError):
                pass
        httpd.server_close()
    print()
    ok("control plane stopped")
    sys.stdout.flush()
    return 0
