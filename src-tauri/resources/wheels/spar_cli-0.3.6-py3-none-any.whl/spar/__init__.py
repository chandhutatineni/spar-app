"""SPAR — a governed, end-to-end AI software-delivery pipeline.

Specify -> Plan -> Approve -> Release, with a human gate at every phase
boundary and every artifact persisted under ``spar/`` in the target project.

SPAR is pure prompts plus a thin installer: the agents, slash commands and
templates under ``spar/data/`` are Markdown, and this package ships only a
zero-dependency CLI and MCP server.
"""

__version__ = "0.3.6"
__all__ = ["__version__"]
